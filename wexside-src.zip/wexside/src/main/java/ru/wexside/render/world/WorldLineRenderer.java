package ru.wexside.render.world;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class WorldLineRenderer {
   private WorldLineRenderer() {
   }

   public static void draw(List<WorldLineRenderer.Segment> segments) {
      draw(null, segments);
   }

   public static void draw(Matrix4f matrix, List<WorldLineRenderer.Segment> segments) {
      if (segments != null && !segments.isEmpty()) {
         MinecraftClient client = MinecraftClient.getInstance();
         if (client.world != null) {
            Camera camera = client.gameRenderer.getCamera();
            Vec3d cameraPosition = camera.getCameraPos();
            Matrix4f actualMatrix = matrix != null ? matrix : new Matrix4f();
            Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
            RenderLayer lineLayer = RenderLayers.lines();
            VertexConsumer buffer = consumers.getBuffer(lineLayer);

            for (WorldLineRenderer.Segment segment : segments) {
               Vec3d start = segment.start();
               Vec3d end = segment.end();
               double dx = end.x - start.x;
               double dy = end.y - start.y;
               double dz = end.z - start.z;
               double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
               float nx = 0.0F;
               float ny = 1.0F;
               float nz = 0.0F;
               if (len > 1.0E-5) {
                  nx = (float)(dx / len);
                  ny = (float)(dy / len);
                  nz = (float)(dz / len);
               }

               Vector3f normal = actualMatrix.transformDirection(new Vector3f(nx, ny, nz)).normalize();
               vertex(buffer, actualMatrix, cameraPosition, start, segment.startColor(), normal.x, normal.y, normal.z);
               vertex(buffer, actualMatrix, cameraPosition, end, segment.endColor(), normal.x, normal.y, normal.z);
            }

            consumers.draw(lineLayer);
         }
      }
   }

   public static void drawEntityBox(Entity entity, int color) {
      drawEntityBox(null, entity, color);
   }

   public static void drawEntityBox(Matrix4f matrix, Entity entity, int color) {
      if (entity != null) {
         MinecraftClient client = MinecraftClient.getInstance();
         float tickDelta = client.getRenderTickCounter() != null ? client.getRenderTickCounter().getTickProgress(false) : 1.0F;
         Vec3d lerpedPos = entity.getLerpedPos(tickDelta);
         Box box = entity.getBoundingBox().offset(lerpedPos.x - entity.getX(), lerpedPos.y - entity.getY(), lerpedPos.z - entity.getZ()).expand(0.025);
         Vec3d p000 = new Vec3d(box.minX, box.minY, box.minZ);
         Vec3d p001 = new Vec3d(box.minX, box.minY, box.maxZ);
         Vec3d p010 = new Vec3d(box.minX, box.maxY, box.minZ);
         Vec3d p011 = new Vec3d(box.minX, box.maxY, box.maxZ);
         Vec3d p100 = new Vec3d(box.maxX, box.minY, box.minZ);
         Vec3d p101 = new Vec3d(box.maxX, box.minY, box.maxZ);
         Vec3d p110 = new Vec3d(box.maxX, box.maxY, box.minZ);
         Vec3d p111 = new Vec3d(box.maxX, box.maxY, box.maxZ);
         ArrayList<WorldLineRenderer.Segment> lines = new ArrayList<>(12);
         add(lines, p000, p001, color);
         add(lines, p001, p101, color);
         add(lines, p101, p100, color);
         add(lines, p100, p000, color);
         add(lines, p010, p011, color);
         add(lines, p011, p111, color);
         add(lines, p111, p110, color);
         add(lines, p110, p010, color);
         add(lines, p000, p010, color);
         add(lines, p001, p011, color);
         add(lines, p100, p110, color);
         add(lines, p101, p111, color);
         draw(matrix, lines);
      }
   }

   private static void add(List<WorldLineRenderer.Segment> lines, Vec3d start, Vec3d end, int color) {
      lines.add(new WorldLineRenderer.Segment(start, end, color, color));
   }

   private static void vertex(VertexConsumer buffer, Matrix4f matrix, Vec3d camera, Vec3d point, int color, float nx, float ny, float nz) {
      buffer.vertex(matrix, (float)(point.x - camera.x), (float)(point.y - camera.y), (float)(point.z - camera.z))
         .color(color)
         .normal(nx, ny, nz)
         .lineWidth(1.0F);
   }

   public record Segment(Vec3d start, Vec3d end, int startColor, int endColor) {
   }
}
