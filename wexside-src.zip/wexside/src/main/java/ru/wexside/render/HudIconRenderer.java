package ru.wexside.render;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.item.ItemStack;
import org.joml.Matrix3x2fStack;

public final class HudIconRenderer {
   private static final float VANILLA_ITEM_SIZE = 16.0F;

   private HudIconRenderer() {
   }

   public static void drawItem(DrawContext context, ItemStack stack, int x, int y, int size) {
      if (context != null && stack != null && !stack.isEmpty() && size > 0) {
         Matrix3x2fStack matrices = context.getMatrices();
         matrices.pushMatrix();
         matrices.translate(x, y);
         float scale = size / 16.0F;
         matrices.scale(scale, scale);
         context.drawItem(stack, 0, 0);
         matrices.popMatrix();
      }
   }

   public static void drawPlayerHead(DrawContext context, SkinTextures skin, int x, int y, int size) {
      if (context != null && skin != null && skin.body() != null && size > 0) {
         context.drawTexture(RenderPipelines.GUI_TEXTURED, skin.body().texturePath(), x, y, 8.0F, 8.0F, size, size, 8, 8, 64, 64);
         context.drawTexture(RenderPipelines.GUI_TEXTURED, skin.body().texturePath(), x, y, 40.0F, 8.0F, size, size, 8, 8, 64, 64);
      }
   }
}
