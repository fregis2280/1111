package ru.wexside.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.ShapeIndexBuffer;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;

class OverlaySampler {
   private GpuBuffer gpuBuffer;

   private GpuBuffer getOrCreateQuadBuffer() {
      if (this.gpuBuffer != null) {
         return this.gpuBuffer;
      }

      ByteBuffer byteBuffer = ByteBuffer.allocateDirect(48).order(ByteOrder.nativeOrder());
      byteBuffer.putFloat(-1.0F).putFloat(-1.0F).putFloat(0.0F);
      byteBuffer.putFloat(1.0F).putFloat(-1.0F).putFloat(0.0F);
      byteBuffer.putFloat(1.0F).putFloat(1.0F).putFloat(0.0F);
      byteBuffer.putFloat(-1.0F).putFloat(1.0F).putFloat(0.0F);
      byteBuffer.flip();
      this.gpuBuffer = RenderSystem.getDevice().createBuffer(() -> "wex/overlay-present-quad", 32, byteBuffer);
      return this.gpuBuffer;
   }

   void present(GpuTextureView overlayTexture) {
      if (overlayTexture != null) {
         Framebuffer framebuffer = MinecraftClient.getInstance().getFramebuffer();
         GpuTextureView targetView = framebuffer.getColorAttachmentView();
         if (targetView != null) {
            GpuBuffer quadBuffer = this.getOrCreateQuadBuffer();
            ShapeIndexBuffer indexBuffer = RenderSystem.getSequentialBuffer(DrawMode.QUADS);
            GpuBuffer indices = indexBuffer.getIndexBuffer(6);
            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();

            try (RenderPass renderPass = encoder.createRenderPass(() -> "wex/overlay-present", targetView, OptionalInt.empty())) {
               renderPass.setPipeline(ClientRenderPipelines.OVERLAY_PRESENT);
               RenderSystem.bindDefaultUniforms(renderPass);
               renderPass.setVertexBuffer(0, quadBuffer);
               renderPass.setIndexBuffer(indices, indexBuffer.getIndexType());
               renderPass.bindTexture("OverlaySampler", overlayTexture, RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
               renderPass.drawIndexed(0, 0, 6, 1);
            }
         }
      }
   }

   void close() {
      if (this.gpuBuffer != null) {
         this.gpuBuffer.close();
         this.gpuBuffer = null;
      }
   }
}
