package ru.wexside.render;

import net.minecraft.item.ItemStack;
import ru.wexside.misc.BakedIconEntry;

public final class BakedItemIcon {
   private final IconAtlasEntry texture;
   private ItemStack stack = ItemStack.EMPTY;
   private int frame;
   private long lastUsedNanos;

   public BakedItemIcon(IconAtlas atlas) {
      this.texture = new IconAtlasEntry(atlas);
   }

   public IconAtlasEntry texture() {
      return this.texture;
   }

   public int frame() {
      return this.frame;
   }

   public void setFrame(int frame) {
      this.frame = frame;
   }

   public long lastUsedNanos() {
      return this.lastUsedNanos;
   }

   public void markUsed(long nowNanos) {
      this.lastUsedNanos = nowNanos;
   }

   public void setStack(ItemStack stack) {
      ItemStack safeStack = stack == null ? ItemStack.EMPTY : stack;
      if (!ItemStack.areEqual(this.stack, safeStack)) {
         this.stack = safeStack.isEmpty() ? ItemStack.EMPTY : safeStack.copy();
         this.texture.update();
      }
   }

   public BakedIconEntry createBakeEntry(float scale) {
      if (!this.stack.isEmpty() && this.texture.process(scale)) {
         ItemStack renderedStack = this.stack.copy();
         return new BakedIconEntry(this.texture, (context, x, y, size) -> HudIconRenderer.drawItem(context, renderedStack, x, y, size));
      } else {
         return null;
      }
   }

   public void close() {
      this.texture.update2();
   }
}
