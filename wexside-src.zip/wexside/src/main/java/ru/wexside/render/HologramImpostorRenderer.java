package ru.wexside.render;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.systems.ProjectionType;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.ProjectionMatrix2;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.TextDisplayEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity;
import net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.Data;
import net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.TextAlignment;
import net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.TextLine;
import net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.TextLines;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.wexside.module.misc.HologramOptimizerModule;

public final class HologramImpostorRenderer {
   private static final Logger LOGGER = LoggerFactory.getLogger(HologramImpostorRenderer.class);
   private static final Identifier CACHE_TEXTURE_ID = Identifier.of("wexside", "hologram_impostor");
   private static final int MAX_CACHE_ENTRIES = 256;
   private static final int MAX_TEXTURE_SIZE = 2048;
   private static final int FULL_BRIGHT_LIGHT = 15728880;
   private static final Matrix4f DRAW_MATRIX = new Matrix4f();
   private static final Map<HologramImpostorRenderer.CacheKey, HologramImpostorRenderer.CachedImpostor> CACHE = new HashMap<>();
   private static final List<HologramImpostorRenderer.RenderRequest> REQUESTS = new ArrayList<>();
   private static final FramebufferTextureAdapter CACHE_TEXTURE = new FramebufferTextureAdapter();
   private static ProjectionMatrix2 projection;
   private static Immediate offscreenConsumers;
   private static boolean textureRegistered;
   private static boolean failed;

   private HologramImpostorRenderer() {
   }

   public static boolean captureEntityLabel(EntityRenderState state, MatrixStack matrices, CameraRenderState camera) {
      if (canCapture() && state != null && matrices != null && camera != null) {
         Text text = state.displayName;
         Vec3d labelPosition = state.nameLabelPos;
         if (text != null && labelPosition != null && isHologramEntity(state.entityType)) {
            if (state.squaredDistanceToCamera > HologramOptimizerModule.maxDistanceSquared()) {
               return true;
            }

            TextRenderer textRenderer = MinecraftClient.getInstance().textRenderer;
            int width = Math.max(1, textRenderer.getWidth(text));
            int height = 10;
            int background = defaultBackgroundColor();
            Matrix4f transform = new Matrix4f(matrices.peek().getPositionMatrix())
               .translate((float)labelPosition.x, (float)labelPosition.y + 0.5F, (float)labelPosition.z)
               .rotate(camera.orientation)
               .scale(0.025F, -0.025F, 0.025F)
               .translate(-width / 2.0F, 0.0F, 0.0F);
            HologramImpostorRenderer.TextDrawer drawer = (renderer, consumers) -> renderer.draw(
               text, 0.0F, 0.0F, -1, false, DRAW_MATRIX, consumers, TextLayerType.NORMAL, 0, 15728880
            );
            REQUESTS.add(
               new HologramImpostorRenderer.RenderRequest(
                  transform, new HologramImpostorRenderer.CacheKey(text, background, 0), width, height, background, 255, true, drawer
               )
            );
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean captureTextDisplay(TextDisplayEntityRenderState state, MatrixStack matrices, float tickProgress) {
      if (canCapture() && state != null && matrices != null) {
         TextLines textLines = state.textLines;
         Data data = state.data;
         if (textLines != null && !textLines.lines().isEmpty() && data != null) {
            if (state.squaredDistanceToCamera > HologramOptimizerModule.maxDistanceSquared()) {
               return true;
            }

            int opacity = data.textOpacity().lerp(tickProgress) & 0xFF;
            if (opacity == 0) {
               return true;
            }

            byte flags = data.flags();
            int background = (flags & 4) != 0 ? defaultBackgroundColor() : data.backgroundColor().lerp(tickProgress);
            int width = Math.max(1, textLines.width());
            int height = Math.max(1, textLines.lines().size() * 10);
            Matrix4f transform = new Matrix4f(matrices.peek().getPositionMatrix())
               .rotate((float) Math.PI, 0.0F, 1.0F, 0.0F)
               .scale(-0.025F)
               .translate(1.0F - width / 2.0F, -(height - 1.0F), 0.0F);
            TextAlignment alignment = TextDisplayEntity.getAlignment(flags);
            boolean shadow = (flags & 1) != 0;
            List<TextLine> lines = List.copyOf(textLines.lines());
            HologramImpostorRenderer.TextDrawer drawer = (renderer, consumers) -> {
               float y = 0.0F;

               for (TextLine line : lines) {
                  float x = alignedX(alignment, width, line.width());
                  renderer.draw(line.contents(), x, y, -1, shadow, DRAW_MATRIX, consumers, TextLayerType.NORMAL, 0, 15728880);
                  y += 10.0F;
               }
            };
            boolean seeThrough = (flags & 2) != 0;
            REQUESTS.add(
               new HologramImpostorRenderer.RenderRequest(
                  transform, new HologramImpostorRenderer.CacheKey(textLines, background, flags), width, height, background, opacity, seeThrough, drawer
               )
            );
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static void flush() {
      if (failed || !HologramOptimizerModule.isEnabled()) {
         clear();
      } else if (!REQUESTS.isEmpty()) {
         try {
            registerTexture();

            for (HologramImpostorRenderer.RenderRequest request : REQUESTS) {
               CACHE.computeIfAbsent(request.key(), ignored -> createImpostor(request));
            }

            Immediate consumers = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();

            for (HologramImpostorRenderer.RenderRequest request : REQUESTS) {
               HologramImpostorRenderer.CachedImpostor cached = CACHE.get(request.key());
               if (cached != null) {
                  drawCached(consumers, request, cached);
               }
            }

            evictUnusedEntries();
         } catch (Throwable throwable) {
            failed = true;
            LOGGER.warn("Hologram impostor renderer disabled after a rendering failure", throwable);
            clear();
         } finally {
            REQUESTS.clear();
         }
      }
   }

   public static void clear() {
      for (HologramImpostorRenderer.CachedImpostor cached : CACHE.values()) {
         cached.framebuffer().delete();
      }

      CACHE.clear();
      REQUESTS.clear();
      failed = false;
   }

   private static boolean canCapture() {
      return !failed && HologramOptimizerModule.isEnabled() && RenderSystem.tryGetDevice() != null;
   }

   private static boolean isHologramEntity(EntityType<?> type) {
      return type == EntityType.ARMOR_STAND || type == EntityType.ITEM || type == EntityType.ITEM_DISPLAY;
   }

   private static void registerTexture() {
      if (!textureRegistered) {
         MinecraftClient.getInstance().getTextureManager().registerTexture(CACHE_TEXTURE_ID, CACHE_TEXTURE);
         textureRegistered = true;
      }
   }

   private static HologramImpostorRenderer.CachedImpostor createImpostor(HologramImpostorRenderer.RenderRequest request) {
      int quality = HologramOptimizerModule.qualityScale();

      while (quality > 1 && ((long)request.width() * quality > 2048L || (long)request.height() * quality > 2048L)) {
         quality--;
      }

      SimpleFramebuffer framebuffer = new SimpleFramebuffer("wexside_hologram_impostor", request.width() * quality, request.height() * quality, true);
      boolean complete = false;

      try {
         RenderSystem.getDevice().createCommandEncoder().clearColorAndDepthTextures(framebuffer.getColorAttachment(), 0, framebuffer.getDepthAttachment(), 1.0);
         Immediate consumers = offscreenConsumers();
         GpuBufferSlice projectionSlice = projection().set(request.width(), request.height());
         RenderSystem.backupProjectionMatrix();

         try {
            RenderSystem.setProjectionMatrix(projectionSlice, ProjectionType.ORTHOGRAPHIC);
            Matrix4fStack modelView = RenderSystem.getModelViewStack();
            modelView.pushMatrix();

            try {
               modelView.identity();
               GpuTextureView previousColor = RenderSystem.outputColorTextureOverride;
               GpuTextureView previousDepth = RenderSystem.outputDepthTextureOverride;
               RenderSystem.outputColorTextureOverride = framebuffer.getColorAttachmentView();
               RenderSystem.outputDepthTextureOverride = framebuffer.getDepthAttachmentView();

               try {
                  drawBackground(consumers, request.width(), request.height(), request.backgroundColor());
                  request.drawer().draw(MinecraftClient.getInstance().textRenderer, consumers);
                  consumers.draw();
               } finally {
                  RenderSystem.outputColorTextureOverride = previousColor;
                  RenderSystem.outputDepthTextureOverride = previousDepth;
               }
            } finally {
               modelView.popMatrix();
            }
         } finally {
            RenderSystem.restoreProjectionMatrix();
         }

         complete = true;
         return new HologramImpostorRenderer.CachedImpostor(framebuffer, request.width(), request.height());
      } finally {
         if (!complete) {
            framebuffer.delete();
         }
      }
   }

   private static void drawBackground(Immediate consumers, int width, int height, int color) {
      if (color >>> 24 != 0) {
         RenderLayer layer = RenderLayers.debugQuads();
         VertexConsumer vertices = consumers.getBuffer(layer);
         vertices.vertex(DRAW_MATRIX, 0.0F, 0.0F, 0.01F).color(color);
         vertices.vertex(DRAW_MATRIX, 0.0F, height, 0.01F).color(color);
         vertices.vertex(DRAW_MATRIX, width, height, 0.01F).color(color);
         vertices.vertex(DRAW_MATRIX, width, 0.0F, 0.01F).color(color);
         consumers.draw(layer);
      }
   }

   private static void drawCached(Immediate consumers, HologramImpostorRenderer.RenderRequest request, HologramImpostorRenderer.CachedImpostor cached) {
      CACHE_TEXTURE.bind(cached.framebuffer());
      RenderLayer layer = request.seeThrough() ? RenderLayers.entityTranslucent(CACHE_TEXTURE_ID) : RenderLayers.entityCutoutNoCull(CACHE_TEXTURE_ID);
      VertexConsumer vertices = consumers.getBuffer(layer);
      Matrix4f transform = request.transform();
      int color = request.alpha() << 24 | 16777215;
      float width = cached.width();
      float height = cached.height();
      vertex(vertices, transform, 0.0F, 0.0F, 0.0F, 1.0F, color);
      vertex(vertices, transform, width, 0.0F, 1.0F, 1.0F, color);
      vertex(vertices, transform, width, height, 1.0F, 0.0F, color);
      vertex(vertices, transform, 0.0F, 0.0F, 0.0F, 1.0F, color);
      vertex(vertices, transform, width, height, 1.0F, 0.0F, color);
      vertex(vertices, transform, 0.0F, height, 0.0F, 0.0F, color);
      consumers.draw(layer);
   }

   private static void vertex(VertexConsumer vertices, Matrix4f matrix, float x, float y, float u, float v, int color) {
      vertices.vertex(matrix, x, y, 0.0F).color(color).texture(u, v).overlay(OverlayTexture.DEFAULT_UV).light(15728880).normal(0.0F, 1.0F, 0.0F);
   }

   private static void evictUnusedEntries() {
      if (CACHE.size() > 256) {
         HashSet<HologramImpostorRenderer.CacheKey> active = new HashSet<>();

         for (HologramImpostorRenderer.RenderRequest request : REQUESTS) {
            active.add(request.key());
         }

         Iterator<Entry<HologramImpostorRenderer.CacheKey, HologramImpostorRenderer.CachedImpostor>> iterator = CACHE.entrySet().iterator();

         while (CACHE.size() > 256 && iterator.hasNext()) {
            Entry<HologramImpostorRenderer.CacheKey, HologramImpostorRenderer.CachedImpostor> entry = iterator.next();
            if (!active.contains(entry.getKey())) {
               entry.getValue().framebuffer().delete();
               iterator.remove();
            }
         }
      }
   }

   private static ProjectionMatrix2 projection() {
      if (projection == null) {
         projection = new ProjectionMatrix2("wexside_hologram_projection", -1000.0F, 1000.0F, true);
      }

      return projection;
   }

   private static Immediate offscreenConsumers() {
      if (offscreenConsumers == null) {
         offscreenConsumers = VertexConsumerProvider.immediate(new BufferAllocator(1048576));
      }

      return offscreenConsumers;
   }

   private static int defaultBackgroundColor() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client.options == null ? 0 : (int)(client.options.getTextBackgroundOpacity(0.25F) * 255.0F) << 24;
   }

   private static float alignedX(TextAlignment alignment, int lineWidth, int textWidth) {
      return switch (alignment) {
         case LEFT -> 0.0F;
         case RIGHT -> lineWidth - textWidth;
         case CENTER -> (lineWidth - textWidth) / 2.0F;
      };
   }

   private record CacheKey(Object content, int backgroundColor, int flags) {
   }

   private record CachedImpostor(Framebuffer framebuffer, float width, float height) {
   }

   private record RenderRequest(
      Matrix4f transform,
      HologramImpostorRenderer.CacheKey key,
      int width,
      int height,
      int backgroundColor,
      int alpha,
      boolean seeThrough,
      HologramImpostorRenderer.TextDrawer drawer
   ) {
   }

   @FunctionalInterface
   private interface TextDrawer {
      void draw(TextRenderer var1, VertexConsumerProvider var2);
   }
}
