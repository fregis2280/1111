package ru.wexside.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector4f;

public final class RenderProjection {
   private static final MinecraftClient CLIENT = MinecraftClient.getInstance();

   private RenderProjection() {
   }

   public static Matrix4f viewProjectionMatrix() {
      return new Matrix4f(RenderFrameState.projectionMatrix).mul(RenderFrameState.viewMatrix);
   }

   public static Frustum frustum() {
      Frustum frustum = new Frustum(RenderFrameState.viewMatrix, RenderFrameState.projectionMatrix);
      Vec3d camera = cameraPosition();
      frustum.setPosition(camera.x, camera.y, camera.z);
      return frustum;
   }

   public static boolean isVisible(Entity entity, Frustum frustum) {
      if (frustum == null) {
         return true;
      }

      float tickDelta = tickProgress();
      Vec3d lerpedPos = entity.getLerpedPos(tickDelta);
      Box box = entity.getBoundingBox().offset(lerpedPos.x - entity.getX(), lerpedPos.y - entity.getY(), lerpedPos.z - entity.getZ());
      return frustum.isVisible(box);
   }

   public static Vector2f projectEntityLabel(Entity entity, Matrix4f viewProjection) {
      float tickDelta = tickProgress();
      Vec3d lerpedPos = entity.getLerpedPos(tickDelta);
      Box box = entity.getBoundingBox().offset(lerpedPos.x - entity.getX(), lerpedPos.y - entity.getY(), lerpedPos.z - entity.getZ());
      return project((box.minX + box.maxX) * 0.5, box.maxY + 0.25, (box.minZ + box.maxZ) * 0.5, viewProjection);
   }

   public static Vector2f projectEntityCenter(Entity entity, Matrix4f viewProjection) {
      float tickDelta = tickProgress();
      Vec3d lerpedPos = entity.getLerpedPos(tickDelta);
      Box box = entity.getBoundingBox().offset(lerpedPos.x - entity.getX(), lerpedPos.y - entity.getY(), lerpedPos.z - entity.getZ());
      return project((box.minX + box.maxX) * 0.5, (box.minY + box.maxY) * 0.5, (box.minZ + box.maxZ) * 0.5, viewProjection);
   }

   public static Vector2f project(Vec3d position) {
      return project(position.x, position.y, position.z, viewProjectionMatrix());
   }

   public static Vector2f project(double x, double y, double z, Matrix4f viewProjection) {
      Vec3d camera = cameraPosition();
      Vector4f clip = new Vector4f((float)(x - camera.x), (float)(y - camera.y), (float)(z - camera.z), 1.0F);
      viewProjection.transform(clip);
      if (clip.w <= 0.001F) {
         return null;
      }

      float normalizedX = clip.x / clip.w;
      float normalizedY = clip.y / clip.w;
      float width = CLIENT.getWindow().getScaledWidth();
      float height = CLIENT.getWindow().getScaledHeight();
      return new Vector2f((normalizedX * 0.5F + 0.5F) * width, (0.5F - normalizedY * 0.5F) * height);
   }

   public static float tickProgress() {
      return CLIENT.getRenderTickCounter().getTickProgress(false);
   }

   private static Vec3d cameraPosition() {
      Vec3d captured = RenderFrameState.cameraPosition;
      return captured != null ? captured : CLIENT.gameRenderer.getCamera().getCameraPos();
   }
}
