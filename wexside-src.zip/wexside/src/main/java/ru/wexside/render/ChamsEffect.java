package ru.wexside.render;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.BufferBuilderStorage;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.OutlineVertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl;
import net.minecraft.client.render.command.RenderDispatcher;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryStack;

public final class ChamsEffect {
   private int framebufferWidth;
   private BufferBuilderStorage bufferBuilders;
   private Immediate primaryVertexConsumers;
   private GpuTextureView sceneDepthView;
   private boolean effectRendered;
   private final MinecraftClient client = MinecraftClient.getInstance();
   private int framebufferHeight;
   private final ChamsCompositor compositor = new ChamsCompositor();
   private GpuTextureView maskDepthView;
   private float elapsedTime;
   private EntityRenderManager entityRenderer;
   private boolean framePrepared;
   private boolean framebuffersCleared;
   private OutlineVertexConsumerProvider outlineVertexConsumers;
   private SimpleFramebuffer effectFramebuffer;
   private final long startedAtMillis = System.currentTimeMillis();
   private GpuTextureView effectView;
   private Framebuffer mainFramebuffer;
   private final Matrix4f viewProjectionMatrix = new Matrix4f();
   private Immediate secondaryVertexConsumers;
   private SimpleFramebuffer maskFramebuffer;
   private RenderDispatcher renderDispatcher;
   private GpuTextureView maskColorView;
   private final CameraRenderState cameraRenderState;
   private final Vector4f clipSpacePosition = new Vector4f();
   private GpuTextureView sceneColorView;
   private Vec3d cameraPosition;
   private OrderedRenderCommandQueueImpl renderQueue;

   public ChamsEffect() {
      this.cameraRenderState = new CameraRenderState();
      this.cameraPosition = Vec3d.ZERO;
   }

   private boolean renderEntityToMask(MatrixStack matrices2, Entity entity2, float f) {
      if (this.entityRenderer == null) {
         return false;
      }

      EntityRenderState renderState = this.entityRenderer.getAndUpdateRenderState(entity2, f);
      if (renderState == null) {
         return false;
      }

      this.prepareRenderState(renderState);
      boolean rendered = false;

      try {
         matrices2.push();

         try {
            this.entityRenderer
               .render(
                  renderState,
                  this.cameraRenderState,
                  renderState.x - this.cameraPosition.x,
                  renderState.y - this.cameraPosition.y,
                  renderState.z - this.cameraPosition.z,
                  matrices2,
                  this.renderQueue
               );
         } finally {
            matrices2.pop();
         }

         this.renderDispatcher.render();
         this.renderDispatcher.endLayeredCustoms();
         this.primaryVertexConsumers.draw();
         this.secondaryVertexConsumers.draw();
         this.outlineVertexConsumers.draw();
         this.renderQueue.onNextFrame();
         rendered = true;
      } catch (Throwable ignored) {
         this.resetRenderDispatcher();
      } finally {
         if (!rendered && this.renderQueue != null) {
            try {
               this.renderQueue.clear();
            } catch (Throwable var19) {
            }
         }
      }

      return rendered;
   }

   private void prepareRenderState(EntityRenderState renderState) {
      renderState.positionOffset = null;
      renderState.displayName = null;
      renderState.nameLabelPos = null;
      renderState.onFire = false;
      renderState.outlineColor = 0;
      renderState.invisible = false;
      renderState.shadowRadius = 0.0F;
      renderState.shadowPieces.clear();
   }

   private void updateCameraState(Camera camera2) {
      this.cameraRenderState.initialized = true;
      this.cameraRenderState.pos = camera2.getCameraPos();
      this.cameraRenderState.blockPos = camera2.getBlockPos();
      this.cameraRenderState.entityPos = this.cameraRenderState.pos;
      this.cameraRenderState.orientation = camera2.getRotation();
   }

   public void resetFrameState() {
      this.clearFrameState();
   }

   public void present() {
      if (!this.effectRendered) {
         this.clearFrameState();
      } else if (this.mainFramebuffer != null && this.sceneColorView != null && this.effectView != null) {
         this.compositor.present(this.sceneColorView, this.effectView, this.framebufferWidth, this.framebufferHeight);
         this.clearFrameState();
      } else {
         this.clearFrameState();
      }
   }

   private void ensureRenderDispatcher() {
      if (this.renderDispatcher == null) {
         this.bufferBuilders = new BufferBuilderStorage(1);
         this.primaryVertexConsumers = this.bufferBuilders.getEntityVertexConsumers();
         this.secondaryVertexConsumers = this.bufferBuilders.getEffectVertexConsumers();
         this.outlineVertexConsumers = this.bufferBuilders.getOutlineVertexConsumers();
         this.renderQueue = new OrderedRenderCommandQueueImpl();
         this.renderDispatcher = new RenderDispatcher(
            this.renderQueue,
            this.client.getBlockRenderManager(),
            this.primaryVertexConsumers,
            this.client.getAtlasManager(),
            this.outlineVertexConsumers,
            this.secondaryVertexConsumers,
            this.client.textRenderer
         );
      }
   }

   private void resetRenderDispatcher() {
      if (this.renderDispatcher != null) {
         try {
            this.renderDispatcher.close();
         } catch (Throwable var2) {
         }

         this.renderDispatcher = null;
      }

      this.bufferBuilders = null;
      this.primaryVertexConsumers = null;
      this.secondaryVertexConsumers = null;
      this.outlineVertexConsumers = null;
      this.renderQueue = null;
   }

   public void releaseFramebuffers() {
      this.clearFrameState();
      if (this.maskFramebuffer != null) {
         this.maskFramebuffer.delete();
         this.maskFramebuffer = null;
      }

      if (this.effectFramebuffer != null) {
         this.effectFramebuffer.delete();
         this.effectFramebuffer = null;
      }
   }

   public void close() {
      this.releaseFramebuffers();
      this.resetRenderDispatcher();
      this.compositor.close();
   }

   private void clearFrameState() {
      this.framePrepared = false;
      this.framebuffersCleared = false;
      this.effectRendered = false;
      this.mainFramebuffer = null;
      this.sceneColorView = null;
      this.sceneDepthView = null;
      this.maskColorView = null;
      this.maskDepthView = null;
      this.effectView = null;
      this.entityRenderer = null;
      this.cameraPosition = Vec3d.ZERO;
      this.framebufferWidth = 0;
      this.framebufferHeight = 0;
      this.elapsedTime = 0.0F;
   }

   private ScreenRegion calculateScreenRegion(Entity entity2, float f) {
      if (this.framebufferWidth > 0 && this.framebufferHeight > 0) {
         Box box = entity2.getBoundingBox().expand(0.65, 0.4, 0.65).offset(entity2.getLerpedPos(f).subtract(entity2.getX(), entity2.getY(), entity2.getZ()));
         double d2 = Double.POSITIVE_INFINITY;
         double d3 = Double.POSITIVE_INFINITY;
         double d4 = Double.NEGATIVE_INFINITY;
         double d5 = Double.NEGATIVE_INFINITY;
         boolean bl = false;
         boolean hasBehindPlane = false;

         for (int i = 0; i < 2; i++) {
            double d6 = i == 0 ? box.minX : box.maxX;

            for (int j = 0; j < 2; j++) {
               double d = j == 0 ? box.minY : box.maxY;

               for (int k = 0; k < 2; k++) {
                  double d7 = k == 0 ? box.minZ : box.maxZ;
                  this.clipSpacePosition
                     .set((float)(d6 - this.cameraPosition.x), (float)(d - this.cameraPosition.y), (float)(d7 - this.cameraPosition.z), 1.0F);
                  this.viewProjectionMatrix.transform(this.clipSpacePosition);
                  if (this.clipSpacePosition.w() <= 0.0F) {
                     hasBehindPlane = true;
                  } else {
                     float f2 = this.clipSpacePosition.x() / this.clipSpacePosition.w();
                     float f3 = this.clipSpacePosition.y() / this.clipSpacePosition.w();
                     if (Float.isFinite(f2) && Float.isFinite(f3)) {
                        double d8 = (f2 * 0.5 + 0.5) * this.framebufferWidth;
                        double d9 = (1.0 - (f3 * 0.5 + 0.5)) * this.framebufferHeight;
                        d2 = Math.min(d2, d8);
                        d3 = Math.min(d3, d9);
                        d4 = Math.max(d4, d8);
                        d5 = Math.max(d5, d9);
                        bl = true;
                     }
                  }
               }
            }
         }

         if (hasBehindPlane) {
            return new ScreenRegion(0.0F, 0.0F, this.framebufferWidth, this.framebufferHeight);
         }

         if (bl) {
            double d10 = d4 - d2;
            double d11 = d5 - d3;
            if (!(d10 < 1.0) && !(d11 < 1.0)) {
               double d = Math.max(20.0, d10 * 0.28);
               double d12 = Math.max(14.0, d11 * 0.18);
               d2 = Math.max(0.0, d2 - d);
               d3 = Math.max(0.0, d3 - d12);
               d4 = Math.min(this.framebufferWidth, d4 + d);
               d5 = Math.min(this.framebufferHeight, d5 + d12);
               d10 = d4 - d2;
               d11 = d5 - d3;
               return !(d10 < 1.0) && !(d11 < 1.0) ? new ScreenRegion((float)d2, (float)(this.framebufferHeight - d5), (float)d10, (float)d11) : null;
            } else {
               return null;
            }
         } else {
            return this.cameraPosition.squaredDistanceTo(entity2.getLerpedPos(f)) < 256.0
               ? new ScreenRegion(0.0F, 0.0F, this.framebufferWidth, this.framebufferHeight)
               : null;
         }
      } else {
         return null;
      }
   }

   private float getElapsedTime() {
      return (float)(System.currentTimeMillis() - this.startedAtMillis) / 700.0F;
   }

   public void prepareFrame() {
      this.effectRendered = false;
      this.framePrepared = false;
      this.framebuffersCleared = false;
      this.mainFramebuffer = this.client.getFramebuffer();
      if (this.mainFramebuffer != null && this.mainFramebuffer.getColorAttachmentView() != null) {
         this.ensureRenderDispatcher();
         this.framebufferWidth = this.mainFramebuffer.textureWidth;
         this.framebufferHeight = this.mainFramebuffer.textureHeight;
         this.ensureFramebuffers(this.framebufferWidth, this.framebufferHeight);
         Camera camera2 = this.client.gameRenderer.getCamera();
         this.entityRenderer = this.client.getEntityRenderDispatcher();
         if (camera2 != null && this.entityRenderer != null && this.maskFramebuffer != null && this.effectFramebuffer != null) {
            this.sceneColorView = this.mainFramebuffer.getColorAttachmentView();
            this.sceneDepthView = this.mainFramebuffer.getDepthAttachmentView();
            this.maskColorView = this.maskFramebuffer.getColorAttachmentView();
            this.maskDepthView = this.maskFramebuffer.getDepthAttachmentView();
            this.effectView = this.effectFramebuffer.getColorAttachmentView();
            if (this.sceneColorView != null
               && this.sceneDepthView != null
               && this.maskColorView != null
               && this.maskDepthView != null
               && this.effectView != null) {
               this.entityRenderer.configure(camera2, this.client.getCameraEntity());
               this.updateCameraState(camera2);
               this.cameraPosition = camera2.getCameraPos();
               this.viewProjectionMatrix.set(RenderFrameState.projectionMatrix).mul(RenderFrameState.viewMatrix);
               this.elapsedTime = this.getElapsedTime();
               this.framePrepared = true;
            } else {
               this.clearFrameState();
            }
         } else {
            this.clearFrameState();
         }
      }
   }

   public void renderEntity(MatrixStack matrices2, Entity entity2, float f, int n, int n2, boolean bl, boolean bl2, int n3) {
      if (matrices2 != null && entity2 != null && entity2.isAlive() && this.client.world != null) {
         if (bl || bl2) {
            if (!this.framePrepared) {
               this.prepareFrame();
            }

            if (this.framePrepared
               && this.mainFramebuffer != null
               && this.sceneColorView != null
               && this.sceneDepthView != null
               && this.maskColorView != null
               && this.maskDepthView != null
               && this.effectView != null) {
               ScreenRegion screenRegion = this.expandRegion(this.calculateScreenRegion(entity2, f));
               if (screenRegion != null) {
                  this.prepareEffectFramebuffer();
                  if (this.framebuffersCleared) {
                     this.clearFramebuffer(this.maskFramebuffer);
                     boolean rendered = false;
                     MemoryStack memoryStack = MemoryStack.stackPush();

                     try (RenderTargetOverrideScope ignored = RenderTargetOverrideScope.use(this.maskColorView, this.maskDepthView)) {
                        rendered = this.renderEntityToMask(matrices2, entity2, f);
                     } catch (Throwable var18) {
                        if (memoryStack != null) {
                           try {
                              memoryStack.close();
                           } catch (Throwable var15) {
                              var18.addSuppressed(var15);
                           }
                        }

                        throw var18;
                     }

                     if (memoryStack != null) {
                        memoryStack.close();
                     }

                     if (rendered) {
                        this.compositor
                           .composite(
                              this.effectView,
                              this.maskColorView,
                              this.maskDepthView,
                              this.sceneColorView,
                              this.sceneDepthView,
                              this.framebufferWidth,
                              this.framebufferHeight,
                              n,
                              n2,
                              bl,
                              bl2,
                              n3,
                              screenRegion.x(),
                              screenRegion.y(),
                              screenRegion.width(),
                              screenRegion.height(),
                              this.elapsedTime
                           );
                        this.effectRendered = true;
                     }
                  }
               }
            }
         }
      }
   }

   private void prepareEffectFramebuffer() {
      if (!this.framebuffersCleared) {
         MemoryStack memoryStack = MemoryStack.stackPush();

         try {
            this.clearFramebuffer(this.effectFramebuffer);
            this.framebuffersCleared = true;
         } catch (Throwable var5) {
            if (memoryStack != null) {
               try {
                  memoryStack.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (memoryStack != null) {
            memoryStack.close();
         }
      }
   }

   private void ensureFramebuffers(int n, int n2) {
      int n3 = Math.max(n, 1);
      int n4 = Math.max(n2, 1);
      if (this.maskFramebuffer == null) {
         this.maskFramebuffer = new SimpleFramebuffer("wexside_chams_mask", n3, n4, true);
      } else if (this.maskFramebuffer.textureWidth != n || this.maskFramebuffer.textureHeight != n2) {
         this.maskFramebuffer.resize(n3, n4);
      }

      if (this.effectFramebuffer == null) {
         this.effectFramebuffer = new SimpleFramebuffer("wexside_chams_effect", n3, n4, true);
      } else if (this.effectFramebuffer.textureWidth != n || this.effectFramebuffer.textureHeight != n2) {
         this.effectFramebuffer.resize(n3, n4);
      }
   }

   private ScreenRegion expandRegion(ScreenRegion screenRegion) {
      if (screenRegion != null && this.framebufferWidth > 0 && this.framebufferHeight > 0) {
         float f = screenRegion.x();
         float f2 = screenRegion.y();
         float f3 = f + screenRegion.width();
         float f4 = f2 + screenRegion.height();
         boolean bl = f <= 52.0F || f3 >= this.framebufferWidth - 52.0F;
         boolean bl2 = f2 <= 38.0F || f4 >= this.framebufferHeight - 38.0F;
         float f5 = Math.max(52.0F, screenRegion.width() * 0.08F);
         float f6 = Math.max(38.0F, screenRegion.height() * 0.08F);
         if (bl) {
            f5 *= 1.75F;
         }

         if (bl2) {
            f6 *= 1.75F;
         }

         f = Math.max(0.0F, f - f5);
         f2 = Math.max(0.0F, f2 - f6);
         f3 = Math.min(this.framebufferWidth, f3 + f5);
         f4 = Math.min(this.framebufferHeight, f4 + f6);
         float f7 = f3 - f;
         float f8 = f4 - f2;
         return !(f7 < 1.0F) && !(f8 < 1.0F) ? new ScreenRegion(f, f2, f7, f8) : screenRegion;
      } else {
         return screenRegion;
      }
   }

   private void clearFramebuffer(SimpleFramebuffer framebuffer5) {
      if (framebuffer5 != null) {
         GpuTexture gpuTexture = framebuffer5.getColorAttachment();
         if (gpuTexture != null) {
            CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
            GpuTexture gpuTexture2 = framebuffer5.getDepthAttachment();
            if (gpuTexture2 != null) {
               commandEncoder.clearColorAndDepthTextures(gpuTexture, 0, gpuTexture2, 1.0);
            } else {
               commandEncoder.clearColorTexture(gpuTexture, 0);
            }
         }
      }
   }
}
