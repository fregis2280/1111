package ru.wexside.render.world;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import ru.wexside.render.BoxEspRenderer;
import ru.wexside.util.ColorUtils;

public final class ConsumableAreaRenderer {
   private static final int CYLINDER_SEGMENTS = 64;

   private ConsumableAreaRenderer() {
   }

   public static void renderBox(Box box, int fillStart, int fillEnd, int outlineStart, int outlineEnd, long timeMillis) {
      renderBox(null, null, box, fillStart, fillEnd, outlineStart, outlineEnd, timeMillis);
   }

   public static void renderBox(Matrix4f matrix, Vec3d cameraPos, Box box, int fillStart, int fillEnd, int outlineStart, int outlineEnd, long timeMillis) {
      ConsumableAreaRenderer.RenderFrame frame = beginFrame(matrix, cameraPos);
      if (frame != null) {
         int fillColor = animatedColor(fillStart, fillEnd, timeMillis);
         int outlineColor = animatedColor(outlineStart, outlineEnd, timeMillis);
         MinecraftClient client = MinecraftClient.getInstance();
         Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
         RenderLayer fillLayer = RenderLayers.debugQuads();
         RenderLayer lineLayer = RenderLayers.lines();
         VertexConsumer fill = consumers.getBuffer(fillLayer);
         BoxEspRenderer.fill(fill, frame.matrix(), frame.cameraPosition(), box, fillColor);
         consumers.draw(fillLayer);
         VertexConsumer lines = consumers.getBuffer(lineLayer);
         BoxEspRenderer.outline(lines, frame.matrix(), frame.cameraPosition(), box, outlineColor);
         consumers.draw(lineLayer);
      }
   }

   public static void renderCylinder(
      double x, double y, double z, double radius, double height, int fillStart, int fillEnd, int outlineStart, int outlineEnd, long timeMillis
   ) {
      renderCylinder(null, null, x, y, z, radius, height, fillStart, fillEnd, outlineStart, outlineEnd, timeMillis);
   }

   public static void renderCylinder(
      Matrix4f matrix,
      Vec3d cameraPos,
      double x,
      double y,
      double z,
      double radius,
      double height,
      int fillStart,
      int fillEnd,
      int outlineStart,
      int outlineEnd,
      long timeMillis
   ) {
      ConsumableAreaRenderer.RenderFrame frame = beginFrame(matrix, cameraPos);
      if (frame != null) {
         int fillColor = animatedColor(fillStart, fillEnd, timeMillis);
         int outlineColor = animatedColor(outlineStart, outlineEnd, timeMillis);
         MinecraftClient client = MinecraftClient.getInstance();
         Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
         RenderLayer fillLayer = RenderLayers.debugQuads();
         RenderLayer lineLayer = RenderLayers.lines();
         VertexConsumer fill = consumers.getBuffer(fillLayer);

         for (int segment = 0; segment < 64; segment++) {
            double a = (Math.PI * 2) * segment / 64.0;
            double b = (Math.PI * 2) * (segment + 1) / 64.0;
            double x1 = x + Math.cos(a) * radius;
            double z1 = z + Math.sin(a) * radius;
            double x2 = x + Math.cos(b) * radius;
            double z2 = z + Math.sin(b) * radius;
            quad(fill, frame, x, y, z, x1, y, z1, x2, y, z2, x, y, z, fillColor);
            quad(fill, frame, x, y + height, z, x, y + height, z, x2, y + height, z2, x1, y + height, z1, fillColor);
            quad(fill, frame, x1, y, z1, x1, y + height, z1, x2, y + height, z2, x2, y, z2, fillColor);
         }

         consumers.draw(fillLayer);
         VertexConsumer lines = consumers.getBuffer(lineLayer);

         for (int segment = 0; segment < 64; segment++) {
            double a = (Math.PI * 2) * segment / 64.0;
            double b = (Math.PI * 2) * (segment + 1) / 64.0;
            double x1 = x + Math.cos(a) * radius;
            double z1 = z + Math.sin(a) * radius;
            double x2 = x + Math.cos(b) * radius;
            double z2 = z + Math.sin(b) * radius;
            line(lines, frame, x1, y, z1, x2, y, z2, outlineColor);
            line(lines, frame, x1, y + height, z1, x2, y + height, z2, outlineColor);
            if ((segment & 7) == 0) {
               line(lines, frame, x1, y, z1, x1, y + height, z1, outlineColor);
            }
         }

         consumers.draw(lineLayer);
      }
   }

   private static ConsumableAreaRenderer.RenderFrame beginFrame(Matrix4f matrix, Vec3d cameraPos) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world == null) {
         return null;
      }

      Camera camera = client.gameRenderer.getCamera();
      Vec3d actualCameraPos = cameraPos != null ? cameraPos : camera.getCameraPos();
      Matrix4f actualMatrix = matrix != null ? matrix : new Matrix4f();
      return new ConsumableAreaRenderer.RenderFrame(actualMatrix, actualCameraPos);
   }

   private static int animatedColor(int start, int end, long timeMillis) {
      float phase = (float)((Math.sin(timeMillis * 0.003) + 1.0) * 0.5);
      return ColorUtils.lerp(start, end, phase);
   }

   private static void quad(
      VertexConsumer out,
      ConsumableAreaRenderer.RenderFrame frame,
      double x1,
      double y1,
      double z1,
      double x2,
      double y2,
      double z2,
      double x3,
      double y3,
      double z3,
      double x4,
      double y4,
      double z4,
      int color
   ) {
      fillVertex(out, frame, x1, y1, z1, color);
      fillVertex(out, frame, x2, y2, z2, color);
      fillVertex(out, frame, x3, y3, z3, color);
      fillVertex(out, frame, x4, y4, z4, color);
   }

   private static void line(
      VertexConsumer out, ConsumableAreaRenderer.RenderFrame frame, double x1, double y1, double z1, double x2, double y2, double z2, int color
   ) {
      float dx = (float)(x2 - x1);
      float dy = (float)(y2 - y1);
      float dz = (float)(z2 - z1);
      float len = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (len > 0.0F) {
         dx /= len;
         dy /= len;
         dz /= len;
      }

      Vector3f normal = frame.matrix().transformDirection(new Vector3f(dx, dy, dz)).normalize();
      lineVertex(out, frame, x1, y1, z1, color, normal.x, normal.y, normal.z);
      lineVertex(out, frame, x2, y2, z2, color, normal.x, normal.y, normal.z);
   }

   private static void fillVertex(VertexConsumer out, ConsumableAreaRenderer.RenderFrame frame, double x, double y, double z, int color) {
      Vec3d camera = frame.cameraPosition();
      out.vertex(frame.matrix(), (float)(x - camera.x), (float)(y - camera.y), (float)(z - camera.z)).color(color);
   }

   private static void lineVertex(
      VertexConsumer out, ConsumableAreaRenderer.RenderFrame frame, double x, double y, double z, int color, float nx, float ny, float nz
   ) {
      Vec3d camera = frame.cameraPosition();
      out.vertex(frame.matrix(), (float)(x - camera.x), (float)(y - camera.y), (float)(z - camera.z)).color(color).normal(nx, ny, nz).lineWidth(1.0F);
   }

   private record RenderFrame(Matrix4f matrix, Vec3d cameraPosition) {
   }
}
