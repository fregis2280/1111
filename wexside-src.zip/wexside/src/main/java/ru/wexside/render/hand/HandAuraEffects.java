package ru.wexside.render.hand;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;

public final class HandAuraEffects {
   private static boolean energyEnabled;
   private static boolean materialEnabled;
   private static boolean frameTransformActive;
   private static EnergyAuraMode energyMode = EnergyAuraMode.STATIC;
   private static HandMaterialMode materialMode = HandMaterialMode.GLASS;
   private static float energyRadius = 1.0F;
   private static float materialRadius = 1.0F;
   private static int primaryEnergyColor;
   private static int secondaryEnergyColor;
   private static int primaryMaterialColor;
   private static int secondaryMaterialColor;
   private static boolean energyGradient;
   private static boolean materialGradient;
   private static boolean fillHands;

   private HandAuraEffects() {
   }

   public static EnergyAuraMode resolveEnergyMode(String setting) {
      return EnergyAuraMode.fromSetting(setting);
   }

   public static HandMaterialMode resolveMaterialMode(String setting) {
      return HandMaterialMode.fromSetting(setting);
   }

   public static void reset() {
      frameTransformActive = false;
   }

   public static void disableAll() {
      energyEnabled = false;
      materialEnabled = false;
   }

   public static void applyHandEnergy(Hand hand, MatrixStack matrices) {
      if (energyEnabled && matrices != null) {
         float side = hand == Hand.MAIN_HAND ? 1.0F : -1.0F;
         float offset = (energyRadius - 1.0F) * 0.025F;
         matrices.translate(side * offset, -offset * 0.5F, 0.0F);
         if (energyMode == EnergyAuraMode.RIBBONS) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 1.5F));
         }
      }
   }

   public static void configureEnergy(
      boolean enabled, EnergyAuraMode mode, int primaryColor, int secondaryColor, boolean gradient, float radius, boolean shouldFillHands
   ) {
      energyEnabled = enabled;
      energyMode = mode == null ? EnergyAuraMode.STATIC : mode;
      primaryEnergyColor = primaryColor;
      secondaryEnergyColor = secondaryColor;
      energyGradient = gradient;
      energyRadius = Math.max(0.5F, Math.min(2.0F, radius));
      fillHands = shouldFillHands;
   }

   public static void configureMaterial(boolean enabled, HandMaterialMode mode, float radius, int primaryColor, int secondaryColor, boolean gradient) {
      materialEnabled = enabled;
      materialMode = mode == null ? HandMaterialMode.GLASS : mode;
      materialRadius = Math.max(0.6F, Math.min(1.8F, radius));
      primaryMaterialColor = primaryColor;
      secondaryMaterialColor = secondaryColor;
      materialGradient = gradient;
   }

   public static void beforeHandRender(MatrixStack matrices, float tickDelta) {
      if ((energyEnabled || materialEnabled) && matrices != null && !frameTransformActive) {
         matrices.push();
         frameTransformActive = true;
         float radius = Math.max(energyEnabled ? energyRadius : 1.0F, materialEnabled ? materialRadius : 1.0F);
         float scale = 1.0F + (radius - 1.0F) * 0.035F;
         if (energyMode == EnergyAuraMode.HAND_AURA) {
            scale += (float)Math.sin((System.nanoTime() / 1.0E9 + tickDelta) * 4.0) * 0.006F;
         }

         if (materialMode == HandMaterialMode.CHROME) {
            scale += 0.004F;
         }

         matrices.scale(scale, scale, scale);
      }
   }

   public static void afterHandRender(MatrixStack matrices) {
      if (frameTransformActive && matrices != null) {
         matrices.pop();
         frameTransformActive = false;
      }
   }
}
