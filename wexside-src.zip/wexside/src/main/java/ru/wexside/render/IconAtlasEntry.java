package ru.wexside.render;

import java.nio.ByteBuffer;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.opengl.GL30;

public final class IconAtlasEntry {
   private int slot;
   private boolean enabled;
   private boolean enabled2;
   private int slot2;
   private int slot3 = -1;
   private int slot4 = -1;
   private IconAtlas field40;
   private int slot5;
   private float renderScale = -1.0F;

   public IconAtlasEntry() {
   }

   public IconAtlasEntry(IconAtlas renderPipeline12) {
      this.field40 = renderPipeline12;
   }

   public IconAtlasEntry(boolean bl) {
      this.enabled2 = bl;
   }

   public boolean process(float f) {
      return !this.enabled || f != this.renderScale;
   }

   public void update() {
      this.enabled = false;
      this.renderScale = -1.0F;
   }

   public boolean isActive() {
      return this.field40 != null ? this.isActive4() && this.field40.getIntType5() != 0 && this.slot2 > 0 : this.slot5 != 0 && this.slot2 > 0;
   }

   public int getIntType() {
      return this.slot2;
   }

   public int getIntType2() {
      return this.field40 != null && this.isActive4() ? this.field40.process2(this.slot4) : 0;
   }

   public int getIntType3() {
      return this.field40 != null ? this.field40.getIntType2() : this.slot2;
   }

   public void update2() {
      if (this.field40 != null) {
         if (this.isActive4()) {
            this.field40.setIntType(this.slot4);
         }

         this.slot4 = -1;
         this.slot3 = -1;
         this.slot2 = 0;
         this.enabled = false;
         this.renderScale = -1.0F;
      } else {
         MinecraftClient client = MinecraftClient.getInstance();
         if (client != null && !client.isOnThread()) {
            client.execute(this::update2);
         } else {
            if (this.slot != 0) {
               GL30.glDeleteFramebuffers(this.slot);
               this.slot = 0;
            }

            if (this.slot5 != 0) {
               GL30.glDeleteTextures(this.slot5);
               this.slot5 = 0;
            }

            this.slot2 = 0;
         }
      }
   }

   public int getIntType4() {
      return this.field40 != null ? this.field40.getIntType5() : this.slot5;
   }

   public int getIntType5() {
      return this.field40 != null && this.isActive4() ? this.field40.process(this.slot4) : 0;
   }

   public float getFloatType() {
      return this.field40 == null ? 1.0F : (float)(this.getIntType5() + this.slot2) / this.field40.getIntType2();
   }

   public boolean isActive2() {
      return this.enabled;
   }

   private void allocateAtlasRegion(int n) {
      if (n > 0) {
         this.field40.setIntType2(n);
         if (this.slot4 >= 0 && this.slot3 != this.field40.getIntType3()) {
            this.slot4 = -1;
         }

         if (this.slot4 < 0) {
            this.slot4 = this.field40.getIntType();
            if (this.slot4 < 0) {
               this.slot2 = 0;
               return;
            }

            this.slot3 = this.field40.getIntType3();
            this.enabled = false;
            this.renderScale = -1.0F;
         }

         this.slot2 = n;
      }
   }

   public boolean isActive3() {
      return this.enabled2;
   }

   public float getFloatType2() {
      return this.field40 == null ? 1.0F : (float)(this.getIntType2() + this.slot2) / this.field40.getIntType2();
   }

   public float getFloatType3() {
      return this.renderScale;
   }

   private boolean isActive4() {
      return this.slot4 >= 0 && this.slot3 == this.field40.getIntType3();
   }

   public int getIntType6() {
      return this.field40 != null ? this.field40.getIntType4() : this.slot;
   }

   public float getFloatType4() {
      return this.field40 == null ? 0.0F : (float)this.getIntType5() / this.field40.getIntType2();
   }

   public float getFloatType5() {
      return this.field40 == null ? 0.0F : (float)this.getIntType2() / this.field40.getIntType2();
   }

   public int getIntType7() {
      return this.slot3;
   }

   public int getIntType8() {
      return this.slot4;
   }

   public IconAtlas getRenderPipeline12() {
      return this.field40;
   }

   public void process2(float f, boolean bl) {
      this.renderScale = f;
      this.enabled = bl;
   }

   public void setIntType(int n) {
      if (this.field40 != null) {
         this.allocateAtlasRegion(n);
      } else if (n > 0 && (n != this.slot2 || this.slot5 == 0)) {
         this.update2();
         int n2 = GL30.glGetInteger(32873);
         int n3 = GL30.glGetInteger(36006);
         int n4 = this.enabled2 ? 9728 : 9729;
         this.slot5 = GL30.glGenTextures();
         GL30.glBindTexture(3553, this.slot5);
         GL30.glTexParameteri(3553, 10241, n4);
         GL30.glTexParameteri(3553, 10240, n4);
         GL30.glTexParameteri(3553, 10242, 33071);
         GL30.glTexParameteri(3553, 10243, 33071);
         int n5 = GL30.glGetInteger(35055);
         GL30.glBindBuffer(35052, 0);
         GL30.glTexImage2D(3553, 0, 32856, n, n, 0, 6408, 5121, (ByteBuffer)null);
         GL30.glBindBuffer(35052, n5);
         this.slot = GL30.glGenFramebuffers();
         GL30.glBindFramebuffer(36160, this.slot);
         GL30.glFramebufferTexture2D(36160, 36064, 3553, this.slot5, 0);
         int n6 = GL30.glCheckFramebufferStatus(36160);
         if (n6 != 36053) {
            int n7 = n6;
            throw new IllegalStateException("Icon framebuffer is incomplete: " + n7);
         }

         GL30.glBindFramebuffer(36160, n3);
         GL30.glBindTexture(3553, n2);
         this.slot2 = n;
      }
   }
}
