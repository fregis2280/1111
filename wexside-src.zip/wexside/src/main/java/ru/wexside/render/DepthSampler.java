package ru.wexside.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.ShapeIndexBuffer;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.OptionalInt;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryStack;
import ru.wexside.misc.ClientChat;
import ru.wexside.prediction.PotionImpactMarker;

public final class DepthSampler {
   private static final float value = 2.5F;
   private static final int slot = 8;
   private GpuBufferSlice gpuBufferSlice;
   private static final int slot2 = 336;
   private static final int slot3 = 136;
   private GpuBuffer gpuBuffer;
   private GpuBuffer gpuBuffer2;
   private static final float value2 = 0.85F;
   private static final float value3 = 0.5F;
   private final Matrix4f matrix4f = new Matrix4f();
   private static final AtomicBoolean ERROR_REPORTED = new AtomicBoolean();

   public void setList(List<PotionImpactMarker> list) {
      if (!list.isEmpty()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         Framebuffer iIllIIiilI2 = mc.getFramebuffer();
         if (iIllIIiilI2 != null && iIllIIiilI2.getColorAttachmentView() != null && iIllIIiilI2.getDepthAttachmentView() != null) {
            Vec3d vec = RenderCamera.position();
            if (vec != null) {
               int n = Math.min(list.size(), 8);
               float f = 3.0F;
               this.matrix4f.set(RenderProjection.viewProjectionMatrix()).invert();

               try {
                  this.update();
                  CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
                  MemoryStack memoryStack = MemoryStack.stackPush();

                  try {
                     Std140Builder std140Builder = Std140Builder.onStack(memoryStack, 336).putMat4f(this.matrix4f).putVec4(n, 0.5F, 0.85F, 2.5F);

                     for (int n2 = 0; n2 < 8; n2++) {
                        if (n2 < n) {
                           Vec3d vec2 = list.get(n2).position();
                           std140Builder.putVec4((float)(vec2.x - vec.x), (float)(vec2.y - vec.y), (float)(vec2.z - vec.z), f);
                        } else {
                           std140Builder.putVec4(0.0F, 0.0F, 0.0F, 0.0F);
                        }
                     }

                     for (int var22 = 0; var22 < 8; var22++) {
                        if (var22 < n) {
                           int n3 = list.get(var22).color();
                           std140Builder.putVec4((n3 >> 16 & 0xFF) / 255.0F, (n3 >> 8 & 0xFF) / 255.0F, (n3 & 0xFF) / 255.0F, 1.0F);
                        } else {
                           std140Builder.putVec4(0.0F, 0.0F, 0.0F, 0.0F);
                        }
                     }

                     commandEncoder.writeToBuffer(this.gpuBufferSlice, std140Builder.get());
                  } catch (Throwable var17) {
                     if (memoryStack != null) {
                        try {
                           memoryStack.close();
                        } catch (Throwable var15) {
                           var17.addSuppressed(var15);
                        }
                     }

                     throw var17;
                  }

                  if (memoryStack != null) {
                     memoryStack.close();
                  }

                  GpuBuffer vertexBuffer = this.getGpuBuffer();
                  ShapeIndexBuffer indexBuffer = RenderSystem.getSequentialBuffer(DrawMode.QUADS);
                  GpuBuffer gpuBuffer = indexBuffer.getIndexBuffer(6);

                  try (RenderPass renderPass = commandEncoder.createRenderPass(
                        () -> "wex/potion-decal", iIllIIiilI2.getColorAttachmentView(), OptionalInt.empty()
                     )) {
                     renderPass.setPipeline(ClientRenderPipelines.POTION_DECAL);
                     RenderSystem.bindDefaultUniforms(renderPass);
                     renderPass.setUniform("PotionDecal", this.gpuBufferSlice);
                     renderPass.setVertexBuffer(0, vertexBuffer);
                     renderPass.setIndexBuffer(gpuBuffer, indexBuffer.getIndexType());
                     renderPass.bindTexture("DepthSampler", iIllIIiilI2.getDepthAttachmentView(), RenderSystem.getSamplerCache().get(FilterMode.NEAREST));
                     renderPass.drawIndexed(0, 0, 6, 1);
                  }
               } catch (Throwable throwable) {
                  if (ERROR_REPORTED.compareAndSet(false, true)) {
                     Throwable throwable2 = throwable.getCause() != null ? throwable.getCause() : throwable;
                     String string = String.valueOf(throwable2);
                     ClientChat.send("PotionDecal error: " + string);
                  }
               }
            }
         }
      }
   }

   private GpuBuffer getGpuBuffer() {
      if (this.gpuBuffer2 != null) {
         return this.gpuBuffer2;
      }

      ByteBuffer byteBuffer = ByteBuffer.allocateDirect(48).order(ByteOrder.nativeOrder());
      byteBuffer.putFloat(-1.0F).putFloat(-1.0F).putFloat(0.0F);
      byteBuffer.putFloat(1.0F).putFloat(-1.0F).putFloat(0.0F);
      byteBuffer.putFloat(1.0F).putFloat(1.0F).putFloat(0.0F);
      byteBuffer.putFloat(-1.0F).putFloat(1.0F).putFloat(0.0F);
      byteBuffer.flip();
      this.gpuBuffer2 = RenderSystem.getDevice().createBuffer(() -> "wex/potion-decal-quad", 32, byteBuffer);
      return this.gpuBuffer2;
   }

   private void update() {
      if (this.gpuBuffer == null) {
         this.gpuBuffer = RenderSystem.getDevice().createBuffer(() -> "wex/potion-decal-ubo", 136, 336L);
         this.gpuBufferSlice = this.gpuBuffer.slice();
      }
   }
}
