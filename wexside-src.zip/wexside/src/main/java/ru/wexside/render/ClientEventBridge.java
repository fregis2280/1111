package ru.wexside.render;

import java.io.IOException;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.BeforeBlockOutline;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.EndExtraction;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.EndMain;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.math.Vec3d;
import ru.wexside.WexSideClient;
import ru.wexside.event.ClientTickEvent;
import ru.wexside.event.DamageEvent;
import ru.wexside.event.DamageType;
import ru.wexside.event.EventBus;
import ru.wexside.event.HudRenderEvent;
import ru.wexside.event.IncomingPacketEvent;
import ru.wexside.event.TotemPopEvent;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.event.WorldSessionEvent;
import ru.wexside.misc.ConfigManager;
import ru.wexside.module.hud.AnimateModule;
import ru.wexside.module.misc.AutoConfigSaveModule;
import ru.wexside.module.render.BlockOverlayModule;
import ru.wexside.module.render.ColorCorrectionModule;
import ru.wexside.module.render.TargetESPModule;
import ru.wexside.module.render.TracersModule;
import ru.wexside.ui.WexsideScreen;
import ru.wexside.util.ClientClock;

public final class ClientEventBridge {
   private static DrawContext pendingHudContext;
   private static RenderTickCounter pendingHudTickCounter;

   private ClientEventBridge() {
   }

   public static void register(EventBus eventBus) {
      eventBus.subscribe(IncomingPacketEvent.class, event -> onIncomingPacket(eventBus, event));
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)client -> onEndTick(eventBus, client));
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)client -> saveActiveConfig());
      HudRenderCallback.EVENT.register((HudRenderCallback)(context, tickCounter) -> {
         RenderFrameClock.advanceFrame();
         pendingHudContext = context;
         pendingHudTickCounter = tickCounter;
      });
      WorldRenderEvents.END_EXTRACTION
         .register((EndExtraction)context -> RenderFrameState.update(context.camera().getCameraPos(), context.cullProjectionMatrix(), context.viewMatrix()));
      WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((BeforeBlockOutline)(context, outline) -> !BlockOverlayModule.isEnabled());
      WorldRenderEvents.END_MAIN.register((EndMain)context -> {
         eventBus.post(new WorldRenderEvent(context.matrices(), context.consumers(), ClientClock.tickDelta()));
         TargetESPModule.tick3();
         TracersModule.tick2();
         ColorCorrectionModule.tick();
      });
      ClientPlayConnectionEvents.JOIN
         .register((Join)(handler, sender, client) -> client.execute(() -> eventBus.post(new WorldSessionEvent(WorldSessionEvent.Change.JOINED))));
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(handler, client) -> client.execute(() -> {
         RenderFrameState.clear();
         eventBus.post(new WorldSessionEvent(WorldSessionEvent.Change.DISCONNECTED));
      }));
   }

   public static void renderHudAfterVanillaGui() {
      DrawContext context = pendingHudContext;
      RenderTickCounter tickCounter = pendingHudTickCounter;
      pendingHudContext = null;
      pendingHudTickCounter = null;
      EventBus eventBus = WexSideClient.getEventBus();
      if (eventBus != null && context != null && tickCounter != null) {
         AnimateModule.onHudRender(context);
         if (!(MinecraftClient.getInstance().currentScreen instanceof WexsideScreen)) {
            eventBus.post(new HudRenderEvent(context, tickCounter));
         }
      }
   }

   private static void onIncomingPacket(EventBus eventBus, IncomingPacketEvent event) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world != null) {
         Packet<?> class_25962 = event.getPacket();
         EntityStatusS2CPacket status;
         if (class_25962 instanceof EntityStatusS2CPacket && (status = (EntityStatusS2CPacket)class_25962).getStatus() == 35) {
            Entity entity = status.getEntity(client.world);
            if (entity != null) {
               eventBus.post(
                  new TotemPopEvent(entity, new Vec3d(entity.getX(), entity.getY() + entity.getHeight() * 0.5, entity.getZ()), System.currentTimeMillis())
               );
            }
         } else {
            EntityDamageS2CPacket damage;
            if (client.player != null
               && event.getPacket() instanceof EntityDamageS2CPacket
               && (damage = (EntityDamageS2CPacket)event.getPacket()).entityId() == client.player.getId()) {
               DamageSource source = damage.createDamageSource(client.world);
               DamageType type = source.getSource() != null && source.getAttacker() != null && source.getSource() != source.getAttacker()
                  ? DamageType.PROJECTILE
                  : (source.getAttacker() != null ? DamageType.DIRECT : DamageType.ENVIRONMENTAL);
               eventBus.post(new DamageEvent(type));
            }
         }
      }
   }

   private static void onEndTick(EventBus eventBus, MinecraftClient client) {
      ClientClock.advanceTick();
      if (client.player != null && client.world != null) {
         eventBus.post(new ClientTickEvent());
      }
   }

   private static void saveActiveConfig() {
      if (AutoConfigSaveModule.isActive()) {
         ConfigManager configManager = WexSideClient.getConfigManager();
         if (configManager != null && !configManager.hasPendingImportedEntries()) {
            String profile = configManager.getCurrentProfileName();
            if (profile == null || profile.isBlank()) {
               profile = "default";
            }

            try {
               configManager.saveProfile(profile);
            } catch (IOException exception) {
               WexSideClient.getInstance().getLogger().warn("Unable to auto-save profile {}", profile, exception);
            }
         }
      }
   }
}
