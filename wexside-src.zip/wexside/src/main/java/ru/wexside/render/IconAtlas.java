package ru.wexside.render;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL30;

public final class IconAtlas {
   private int slot;
   private final Deque<Integer> deque = new ArrayDeque<>();
   private int slot2;
   private int slot3;
   private int slot4;
   private int slot5;
   private int slot6;
   private int slot7;
   private static final int slot8 = 2;
   private final boolean enabled;
   private int slot9;
   private final int slot10;

   public IconAtlas(int n, boolean bl) {
      this.slot10 = Math.max(1, n);
      this.enabled = bl;
   }

   public int getIntType() {
      Integer n = this.deque.poll();
      if (n != null) {
         return n;
      } else {
         return this.slot6 >= this.slot10 ? -1 : this.slot6++;
      }
   }

   public void setIntType(int n) {
      if (n >= 0 && n < this.slot6) {
         this.deque.push(n);
      }
   }

   public int process(int n) {
      return n % this.slot4 * this.slot2;
   }

   public int getIntType2() {
      return this.slot;
   }

   public int getIntType3() {
      return this.slot9;
   }

   public void setIntType2(int n) {
      if (n > 0 && (n != this.slot7 || this.slot5 == 0)) {
         this.update();
         this.slot7 = n;
         this.slot2 = n + 2;
         this.slot4 = (int)Math.ceil(Math.sqrt(this.slot10));
         this.slot = this.slot4 * this.slot2;
         this.update2();
         this.slot9++;
      }
   }

   public int process2(int n) {
      return n / this.slot4 * this.slot2;
   }

   public int getIntType4() {
      return this.slot3;
   }

   public void update() {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client != null && !client.isOnThread()) {
         client.execute(this::update);
      } else {
         if (this.slot3 != 0) {
            GL30.glDeleteFramebuffers(this.slot3);
            this.slot3 = 0;
         }

         if (this.slot5 != 0) {
            GL30.glDeleteTextures(this.slot5);
            this.slot5 = 0;
         }

         this.slot7 = 0;
         this.slot2 = 0;
         this.slot4 = 0;
         this.slot = 0;
         this.slot6 = 0;
         this.deque.clear();
      }
   }

   private void update2() {
      int n = GL30.glGetInteger(32873);
      int n2 = GL30.glGetInteger(36006);
      float[] fArray = new float[4];
      GL30.glGetFloatv(3106, fArray);
      int n3 = this.enabled ? 9728 : 9729;
      this.slot5 = GL30.glGenTextures();
      GL30.glBindTexture(3553, this.slot5);
      GL30.glTexParameteri(3553, 10241, n3);
      GL30.glTexParameteri(3553, 10240, n3);
      GL30.glTexParameteri(3553, 10242, 33071);
      GL30.glTexParameteri(3553, 10243, 33071);
      int n4 = GL30.glGetInteger(35055);
      GL30.glBindBuffer(35052, 0);
      GL30.glTexImage2D(3553, 0, 32856, this.slot, this.slot, 0, 6408, 5121, (ByteBuffer)null);
      GL30.glBindBuffer(35052, n4);
      this.slot3 = GL30.glGenFramebuffers();
      GL30.glBindFramebuffer(36160, this.slot3);
      GL30.glFramebufferTexture2D(36160, 36064, 3553, this.slot5, 0);
      int n5 = GL30.glCheckFramebufferStatus(36160);
      if (n5 != 36053) {
         int n6 = n5;
         throw new IllegalStateException("Icon atlas framebuffer is incomplete: " + n6);
      }

      boolean bl = GL30.glIsEnabled(3089);
      ByteBuffer byteBuffer = BufferUtils.createByteBuffer(4);
      GL30.glGetBooleanv(3107, byteBuffer);
      GL30.glDisable(3089);
      GL30.glColorMask(true, true, true, true);
      GL30.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
      GL30.glClear(16384);
      GL30.glColorMask(byteBuffer.get(0) != 0, byteBuffer.get(1) != 0, byteBuffer.get(2) != 0, byteBuffer.get(3) != 0);
      if (bl) {
         GL30.glEnable(3089);
      }

      GL30.glClearColor(fArray[0], fArray[1], fArray[2], fArray[3]);
      GL30.glBindFramebuffer(36160, n2);
      GL30.glBindTexture(3553, n);
   }

   public int getIntType5() {
      return this.slot5;
   }
}
