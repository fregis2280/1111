package ru.wexside.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import ru.wexside.event.EventBus;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.ModelEspSettings;
import ru.wexside.model.esp.EspTargetClassifier;
import ru.wexside.util.EspFeatureRegistry;

public final class WorldSkeletonRenderer {
   private final EspFeatureRegistry espSettings;
   private final BufferAllocator bufferAllocator = new BufferAllocator(65536);
   private final Immediate vertexConsumers = VertexConsumerProvider.immediate(this.bufferAllocator);

   public WorldSkeletonRenderer(EventBus eventBus, EspFeatureRegistry espSettings) {
      this.espSettings = espSettings;
      eventBus.subscribe(WorldRenderEvent.class, this::render);
   }

   private void render(WorldRenderEvent event) {
      MinecraftClient client = MinecraftClient.getInstance();
      Vec3d camera = RenderCamera.position();
      if (this.espSettings.hasEnabledModelEsp() && client.world != null && client.player != null && camera != null) {
         Matrix4f matrix = new Matrix4f(event.getMatrices().peek().getPositionMatrix());
         this.renderSkeletons(matrix, client, camera, event.getFloatType());
      }
   }

   private void renderSkeletons(Matrix4f matrix, MinecraftClient client, Vec3d camera, float tickProgress) {
      RenderLayer layer = RenderLayers.linesTranslucent();
      VertexConsumer vertices = null;

      for (PlayerEntity player : client.world.getPlayers()) {
         ModelEspSettings settings;
         if (player != client.player && player.isAlive() && (settings = this.settingsFor(player)) != null && settings.isEnabled() && !settings.isModelStyle()) {
            if (vertices == null) {
               vertices = this.vertexConsumers.getBuffer(layer);
            }

            drawPlayer(vertices, matrix, player, camera, tickProgress, settings.getOutlineColor());
         }
      }

      if (vertices != null) {
         this.vertexConsumers.draw(layer);
      }
   }

   private ModelEspSettings settingsFor(PlayerEntity player) {
      return this.espSettings.getModelEspSettings(EspTargetClassifier.relation(player));
   }

   private static void drawPlayer(VertexConsumer vertices, Matrix4f matrix, PlayerEntity player, Vec3d camera, float tickProgress, int color) {
      Vec3d position = player.getLerpedPos(tickProgress).subtract(camera);
      float yaw = (float)Math.toRadians(-player.getLerpedYaw(tickProgress));
      float sin = (float)Math.sin(yaw);
      float cos = (float)Math.cos(yaw);
      float lean = player.isSneaking() ? 0.18F : 0.0F;
      Vector3f hips = point(position, 0.0F, 0.72F, lean, sin, cos);
      Vector3f chest = point(position, 0.0F, 1.35F, lean, sin, cos);
      Vector3f neck = point(position, 0.0F, 1.52F, lean, sin, cos);
      Vector3f head = point(position, 0.0F, 1.79F, lean, sin, cos);
      Vector3f leftShoulder = point(position, 0.34F, 1.38F, lean, sin, cos);
      Vector3f rightShoulder = point(position, -0.34F, 1.38F, lean, sin, cos);
      Vector3f leftHand = point(position, 0.5F, 0.82F, lean, sin, cos);
      Vector3f rightHand = point(position, -0.5F, 0.82F, lean, sin, cos);
      Vector3f leftHip = point(position, 0.18F, 0.7F, lean, sin, cos);
      Vector3f rightHip = point(position, -0.18F, 0.7F, lean, sin, cos);
      Vector3f leftFoot = point(position, 0.2F, 0.02F, 0.0F, sin, cos);
      Vector3f rightFoot = point(position, -0.2F, 0.02F, 0.0F, sin, cos);
      line(vertices, matrix, hips, chest, color, 2.0F);
      line(vertices, matrix, chest, neck, color, 2.0F);
      line(vertices, matrix, neck, head, color, 2.0F);
      line(vertices, matrix, leftShoulder, rightShoulder, color, 2.0F);
      line(vertices, matrix, leftShoulder, leftHand, color, 2.0F);
      line(vertices, matrix, rightShoulder, rightHand, color, 2.0F);
      line(vertices, matrix, leftHip, rightHip, color, 2.0F);
      line(vertices, matrix, leftHip, leftFoot, color, 2.0F);
      line(vertices, matrix, rightHip, rightFoot, color, 2.0F);
   }

   private static Vector3f point(Vec3d origin, float localX, float localY, float localZ, float sin, float cos) {
      float rotatedX = localX * cos - localZ * sin;
      float rotatedZ = localX * sin + localZ * cos;
      return new Vector3f((float)origin.x + rotatedX, (float)origin.y + localY, (float)origin.z + rotatedZ);
   }

   private static void line(VertexConsumer vertices, Matrix4f matrix, Vector3f from, Vector3f to, int color, float width) {
      Vector3f direction = new Vector3f(to).sub(from);
      if (direction.lengthSquared() > 0.0F) {
         direction.normalize();
      }

      Vector3f normal = matrix.transformDirection(new Vector3f(direction)).normalize();
      vertices.vertex(matrix, from.x, from.y, from.z).color(color).normal(normal.x, normal.y, normal.z).lineWidth(width);
      vertices.vertex(matrix, to.x, to.y, to.z).color(color).normal(normal.x, normal.y, normal.z).lineWidth(width);
   }
}
