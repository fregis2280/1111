package ru.wexside.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Builder;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import com.mojang.blaze3d.vertex.VertexFormatElement.Type;
import com.mojang.blaze3d.vertex.VertexFormatElement.Usage;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

public final class ClientRenderPipelines {
   private static final VertexFormatElement POSITION_2F = element(7, Type.FLOAT, 2);
   private static final VertexFormatElement MESH_POSITION_2F = element(8, Type.FLOAT, 2);
   private static final VertexFormatElement MESH_SIZE_2F = element(9, Type.FLOAT, 2);
   private static final VertexFormatElement TEXTURE_COORDINATE_2F = element(10, Type.FLOAT, 2);
   private static final VertexFormatElement CORNER_RADII_4F = element(11, Type.FLOAT, 4);
   private static final VertexFormatElement FILL_COLOR_4UB = element(12, Type.UBYTE, 4);
   private static final VertexFormatElement OUTLINE_COLOR_4UB = element(13, Type.UBYTE, 4);
   private static final VertexFormatElement OUTLINE_THICKNESS_1F = element(14, Type.FLOAT, 1);
   private static final VertexFormatElement EDGE_SOFTNESS_1F = element(15, Type.FLOAT, 1);
   private static final VertexFormatElement MSDF_EDGE_1F = element(16, Type.FLOAT, 1);
   private static final VertexFormatElement MSDF_TEXT_SIZE_1F = element(17, Type.FLOAT, 1);
   private static final VertexFormatElement MSDF_RANGE_1F = element(18, Type.FLOAT, 1);
   private static final VertexFormatElement MSDF_ATLAS_SIZE_2F = element(19, Type.FLOAT, 2);
   private static final VertexFormatElement TEXTURE_INDEX_1B = element(20, Type.BYTE, 1);
   private static final VertexFormatElement DRAW_MODE_1B = element(21, Type.BYTE, 1);
   public static final VertexFormat GUI_VERTEX_FORMAT = VertexFormat.builder()
      .add("aPosition", POSITION_2F)
      .add("aMeshPos", MESH_POSITION_2F)
      .add("aMeshSize", MESH_SIZE_2F)
      .add("aTexCoord", TEXTURE_COORDINATE_2F)
      .add("aRadius", CORNER_RADII_4F)
      .add("aColor", FILL_COLOR_4UB)
      .add("aOutlineColor", OUTLINE_COLOR_4UB)
      .add("aThickness", OUTLINE_THICKNESS_1F)
      .add("aSoftness", EDGE_SOFTNESS_1F)
      .add("aMsdfEdge", MSDF_EDGE_1F)
      .add("aMsdfTextSize", MSDF_TEXT_SIZE_1F)
      .add("aMsdfRange", MSDF_RANGE_1F)
      .add("aMsdfAtlasSize", MSDF_ATLAS_SIZE_2F)
      .add("aTexIndex", TEXTURE_INDEX_1B)
      .add("aDrawMode", DRAW_MODE_1B)
      .build();
   public static final RenderPipeline OVERLAY_PRESENT = RenderPipelines.register(
      fullscreenPipeline("overlay_present", "dc/present").withSampler("OverlaySampler").withBlend(BlendFunction.TRANSLUCENT).build()
   );
   public static final RenderPipeline MASK_CLEAR = RenderPipelines.register(fullscreenPipeline("mask_clear", "dc/clear").withoutBlend().build());
   public static final RenderPipeline KAWASE_DOWNSAMPLE = RenderPipelines.register(
      fullscreenPipeline("kawase_downsample", "dc/kawase")
         .withFragmentShader(id("dc/kawase_down"))
         .withSampler("InSampler")
         .withUniform("KawaseData", UniformType.UNIFORM_BUFFER)
         .withoutBlend()
         .build()
   );
   public static final RenderPipeline KAWASE_UPSAMPLE = RenderPipelines.register(
      fullscreenPipeline("kawase_upsample", "dc/kawase")
         .withFragmentShader(id("dc/kawase_up"))
         .withSampler("InSampler")
         .withUniform("KawaseData", UniformType.UNIFORM_BUFFER)
         .withoutBlend()
         .build()
   );
   public static final RenderPipeline MASK_WRITER = RenderPipelines.register(guiPipeline("mask_writer").withoutBlend().build());
   public static final RenderPipeline GUI_BATCH = RenderPipelines.register(guiPipeline("gui_batch").withBlend(BlendFunction.TRANSLUCENT).build());
   public static final RenderPipeline POTION_DECAL = RenderPipelines.register(
      fullscreenPipeline("potion_decal", "prediction/potion_decal")
         .withSampler("DepthSampler")
         .withUniform("PotionDecal", UniformType.UNIFORM_BUFFER)
         .withBlend(BlendFunction.TRANSLUCENT)
         .build()
   );

   private ClientRenderPipelines() {
   }

   private static VertexFormatElement element(int id, Type type, int count) {
      return VertexFormatElement.register(id, 0, type, Usage.GENERIC, count);
   }

   private static Builder fullscreenPipeline(String name, String shader) {
      return RenderPipeline.builder()
         .withLocation(id("pipeline/" + name))
         .withVertexShader(id(shader))
         .withFragmentShader(id(shader))
         .withVertexFormat(VertexFormats.POSITION, DrawMode.QUADS)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false);
   }

   private static Builder guiPipeline(String name) {
      Builder builder = RenderPipeline.builder()
         .withLocation(id("pipeline/" + name))
         .withVertexShader(id("dc/core_dc"))
         .withFragmentShader(id("dc/core_dc"))
         .withUniform("WexGlobals", UniformType.UNIFORM_BUFFER)
         .withSampler("MaskTex")
         .withVertexFormat(GUI_VERTEX_FORMAT, DrawMode.QUADS)
         .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
         .withDepthWrite(false)
         .withCull(false);

      for (int textureIndex = 0; textureIndex < 16; textureIndex++) {
         builder.withSampler("textureSampler[" + textureIndex + "]");
      }

      return builder;
   }

   private static Identifier id(String path) {
      return Identifier.of("wexside", path);
   }
}
