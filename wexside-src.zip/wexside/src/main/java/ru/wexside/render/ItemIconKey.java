package ru.wexside.render;

import net.minecraft.item.ItemStack;

public final class ItemIconKey {
   private final ItemStack stack;

   public ItemIconKey(ItemStack stack) {
      this.stack = stack != null && !stack.isEmpty() ? stack.copy() : ItemStack.EMPTY;
   }

   @Override
   public boolean equals(Object object) {
      return !(object instanceof ItemIconKey other) ? false : ItemStack.areEqual(this.stack, other.stack);
   }

   @Override
   public int hashCode() {
      return 31 * System.identityHashCode(this.stack.getItem()) + this.stack.getComponents().hashCode();
   }
}
