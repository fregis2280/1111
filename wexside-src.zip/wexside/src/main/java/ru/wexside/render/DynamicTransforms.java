package ru.wexside.render;

import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import ru.wexside.misc.SpatialTransform;
import ru.wexside.util.InlineMesh;

public final class DynamicTransforms {
   public void process8(
      List<InlineMesh> meshes,
      Vec3d cameraPosition,
      int fillColor,
      int outlineColor,
      List<SpatialTransform> transforms,
      boolean drawOutline,
      float outlineWidth,
      float animationTime,
      int animationMode
   ) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client != null && meshes != null && !meshes.isEmpty() && cameraPosition != null && transforms != null && !transforms.isEmpty()) {
         int animatedFillColor = this.animateColor(fillColor, animationTime, animationMode);
         int animatedOutlineColor = this.animateColor(outlineColor, animationTime, animationMode);
         BufferBuilder fillBuffer = Tessellator.getInstance().begin(DrawMode.TRIANGLES, VertexFormats.POSITION);
         BufferBuilder outlineBuffer = drawOutline ? Tessellator.getInstance().begin(DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR) : null;

         for (SpatialTransform transform : transforms) {
            Matrix4f modelMatrix = this.createModelMatrix(transform, cameraPosition);

            for (InlineMesh mesh : meshes) {
               this.emitTriangles(fillBuffer, modelMatrix, mesh, animatedFillColor);
               if (outlineBuffer != null) {
                  this.emitOutline(outlineBuffer, modelMatrix, mesh, animatedOutlineColor, outlineWidth);
               }
            }
         }

         this.draw(RenderLayers.debugQuads(), fillBuffer);
         if (outlineBuffer != null) {
            this.draw(RenderLayers.lines(), outlineBuffer);
         }
      }
   }

   private Matrix4f createModelMatrix(SpatialTransform transform, Vec3d cameraPosition) {
      return new Matrix4f()
         .translate(
            (float)(transform.centerX() - cameraPosition.x), (float)(transform.centerY() - cameraPosition.y), (float)(transform.centerZ() - cameraPosition.z)
         )
         .rotateY((float)Math.toRadians(transform.yawDegrees()))
         .rotateX((float)Math.toRadians(transform.pitchDegrees()))
         .rotateZ((float)Math.toRadians(transform.rollDegrees()))
         .scale(transform.scaleX(), transform.scaleY(), transform.scaleZ());
   }

   private void emitTriangles(BufferBuilder output, Matrix4f matrix, InlineMesh mesh, int color) {
      float[] positions = mesh.getFloatType();
      if (positions != null && positions.length >= 3) {
         int[] indices = mesh.getIntType2();
         float[] vertexColors = mesh.getFloatType4();
         if (indices == null) {
            for (int vertex = 0; vertex < positions.length / 3; vertex++) {
               this.emitVertex(output, matrix, positions, vertex, color, vertexColors);
            }
         } else {
            for (int vertex : indices) {
               this.emitVertex(output, matrix, positions, vertex, color, vertexColors);
            }
         }
      }
   }

   private void emitOutline(BufferBuilder output, Matrix4f matrix, InlineMesh mesh, int color, float outlineWidth) {
      float[] positions = mesh.getFloatType();
      int[] edges = mesh.getIntType();
      if (positions != null && edges != null) {
         int red = color >> 16 & 0xFF;
         int green = color >> 8 & 0xFF;
         int blue = color & 0xFF;
         int alpha = color >>> 24;

         for (int i = 0; i + 1 < edges.length; i += 2) {
            int v0 = edges[i];
            int v1 = edges[i + 1];
            int o0 = v0 * 3;
            int o1 = v1 * 3;
            if (o0 >= 0 && o0 + 2 < positions.length && o1 >= 0 && o1 + 2 < positions.length) {
               float dx = positions[o1] - positions[o0];
               float dy = positions[o1 + 1] - positions[o0 + 1];
               float dz = positions[o1 + 2] - positions[o0 + 2];
               float len = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
               if (len > 0.0F) {
                  dx /= len;
                  dy /= len;
                  dz /= len;
               }

               Vector3f normal = matrix.transformDirection(new Vector3f(dx, dy, dz)).normalize();
               output.vertex(matrix, positions[o0], positions[o0 + 1], positions[o0 + 2])
                  .color(red, green, blue, alpha)
                  .normal(normal.x, normal.y, normal.z)
                  .lineWidth(outlineWidth);
               output.vertex(matrix, positions[o1], positions[o1 + 1], positions[o1 + 2])
                  .color(red, green, blue, alpha)
                  .normal(normal.x, normal.y, normal.z)
                  .lineWidth(outlineWidth);
            }
         }
      }
   }

   private void emitVertex(BufferBuilder output, Matrix4f matrix, float[] positions, int vertex, int color, float[] vertexColors) {
      int positionOffset = vertex * 3;
      if (positionOffset >= 0 && positionOffset + 2 < positions.length) {
         int red = color >> 16 & 0xFF;
         int green = color >> 8 & 0xFF;
         int blue = color & 0xFF;
         int alpha = color >>> 24;
         int colorOffset = vertex * 4;
         if (vertexColors != null && colorOffset + 3 < vertexColors.length) {
            red = this.multiplyColor(red, vertexColors[colorOffset]);
            green = this.multiplyColor(green, vertexColors[colorOffset + 1]);
            blue = this.multiplyColor(blue, vertexColors[colorOffset + 2]);
            alpha = this.multiplyColor(alpha, vertexColors[colorOffset + 3]);
         }

         output.vertex(matrix, positions[positionOffset], positions[positionOffset + 1], positions[positionOffset + 2]).color(red, green, blue, alpha);
      }
   }

   private int multiplyColor(int channel, float multiplier) {
      return Math.clamp(Math.round(channel * multiplier), 0, 255);
   }

   private int animateColor(int color, float time, int mode) {
      if (mode <= 0) {
         return color;
      }

      float frequency = switch (mode) {
         case 1 -> 0.65F;
         case 2 -> 1.15F;
         case 3 -> 1.75F;
         case 4 -> 0.9F;
         default -> 2.25F;
      };
      float opacity = 0.72F + 0.28F * (float)Math.sin(time * frequency);
      int alpha = this.multiplyColor(color >>> 24, opacity);
      return color & 16777215 | alpha << 24;
   }

   private void draw(RenderLayer layer, BufferBuilder buffer) {
      layer.draw(buffer.end());
   }
}
