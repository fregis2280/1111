package ru.wexside.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import net.minecraft.client.texture.GlTexture;
import org.lwjgl.opengl.GL30;

class OverlayFramebuffer {
   private GpuTexture colorTexture;
   private int colorTextureId;
   private int width;
   private int height;
   private int framebufferId;
   private int depthStencilRenderbufferId;
   private GpuTextureView colorTextureView;

   void ensureSize(int width, int height) {
      if (width > 0 && height > 0) {
         if (this.width != width || this.height != height || this.framebufferId == 0) {
            this.close();
            this.colorTexture = RenderSystem.getDevice().createTexture(() -> "wex/overlay-stage", 12, TextureFormat.RGBA8, width, height, 1, 1);
            this.colorTextureView = RenderSystem.getDevice().createTextureView(this.colorTexture);
            if (!(this.colorTexture instanceof GlTexture glTexture)) {
               throw new IllegalStateException("FboStage requires OpenGL Mojang device (got " + this.colorTexture.getClass() + ")");
            } else {
               this.colorTextureId = glTexture.getGlId();
               int previousFramebuffer = GL30.glGetInteger(36006);
               int previousRenderbuffer = GL30.glGetInteger(36007);
               this.framebufferId = GL30.glGenFramebuffers();
               GL30.glBindFramebuffer(36160, this.framebufferId);
               GL30.glFramebufferTexture2D(36160, 36064, 3553, this.colorTextureId, 0);
               this.depthStencilRenderbufferId = GL30.glGenRenderbuffers();
               GL30.glBindRenderbuffer(36161, this.depthStencilRenderbufferId);
               GL30.glRenderbufferStorage(36161, 35056, width, height);
               GL30.glFramebufferRenderbuffer(36160, 33306, 36161, this.depthStencilRenderbufferId);
               int status = GL30.glCheckFramebufferStatus(36160);
               if (status != 36053) {
                  GL30.glBindFramebuffer(36160, previousFramebuffer);
                  GL30.glBindRenderbuffer(36161, previousRenderbuffer);
                  throw new IllegalStateException("Overlay FBO is incomplete: " + status);
               }

               GL30.glBindFramebuffer(36160, previousFramebuffer);
               GL30.glBindRenderbuffer(36161, previousRenderbuffer);
               this.width = width;
               this.height = height;
            }
         }
      }
   }

   GpuTextureView getColorTextureView() {
      return this.colorTextureView;
   }

   void bindAndClear() {
      float[] previousClearColor = new float[4];
      GL30.glGetFloatv(3106, previousClearColor);
      int previousClearStencil = GL30.glGetInteger(2961);
      GL30.glBindFramebuffer(36160, this.framebufferId);
      GL30.glViewport(0, 0, this.width, this.height);
      GL30.glDisable(3089);
      GL30.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
      GL30.glClearStencil(0);
      GL30.glClear(17664);
      GL30.glClearColor(previousClearColor[0], previousClearColor[1], previousClearColor[2], previousClearColor[3]);
      GL30.glClearStencil(previousClearStencil);
   }

   void close() {
      if (this.framebufferId != 0) {
         GL30.glDeleteFramebuffers(this.framebufferId);
         this.framebufferId = 0;
      }

      if (this.depthStencilRenderbufferId != 0) {
         GL30.glDeleteRenderbuffers(this.depthStencilRenderbufferId);
         this.depthStencilRenderbufferId = 0;
      }

      if (this.colorTextureView != null) {
         this.colorTextureView.close();
         this.colorTextureView = null;
      }

      if (this.colorTexture != null) {
         this.colorTexture.close();
         this.colorTexture = null;
      }

      this.colorTextureId = 0;
      this.width = 0;
      this.height = 0;
   }
}
