package ru.wexside.render;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import ru.wexside.WexSideClient;
import ru.wexside.item.ItemBadge;
import ru.wexside.misc.CaptureFramebuffer;
import ru.wexside.misc.DeferredRenderTask;
import ru.wexside.misc.EntityEspOverlayRenderer;
import ru.wexside.misc.FrameInterpolator;
import ru.wexside.misc.GlowEspSettings;
import ru.wexside.misc.ModelEspSettings;
import ru.wexside.model.esp.EspRelation;
import ru.wexside.model.esp.EspTargetType;
import ru.wexside.ui.GuiBounds;
import ru.wexside.util.EspFeatureRegistry;
import ru.wexside.util.GuiDrawApi;

public final class EspPreviewRenderer {
   private static final int MIN_PREVIEW_SIZE = 110;
   private static final int MAX_PREVIEW_SIZE = 640;
   private static final float MAX_PITCH = 35.0F;
   private static final float ROTATION_SENSITIVITY = 1.2F;
   private static final float ROTATION_RESET_SPEED = 8.0F;
   private static final String DONATION_TAG_KEY = "don-item";
   private static final String[] DONATION_PREFIXES = new String[]{"wexside:", "wexside_", "donate:"};
   private static final EquipmentSlot[] ARMOR_SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   private static final ItemStack ITEM_PREVIEW_STACK = new ItemStack(Items.TOTEM_OF_UNDYING);
   private static final float PREVIEW_SIZE_EPSILON = 0.5F;
   private static final float PREVIEW_ROTATION_EPSILON = 0.5F;
   private double lastMouseX;
   private double lastMouseY;
   private final SkeletonPreviewRenderer skeletonPreviewRenderer;
   private final EntityEspOverlayRenderer entityEspOverlayRenderer;
   private final MinecraftClient client = MinecraftClient.getInstance();
   private Entity mobPreviewEntity;
   private float requestedSize;
   private float lastRequestedSize = -1.0F;
   private float lastRequestedYaw = Float.NaN;
   private float lastRequestedPitch = Float.NaN;
   private EspTargetType lastRequestedTargetType;
   private EspRelation lastRequestedRelation;
   private float pitch;
   private EspTargetType espTargetType;
   private boolean rendered;
   private boolean rotating;
   private final GlowEspPreviewEffect glowEspPreviewEffect;
   private int previewSize = 110;
   private int framebufferWidth;
   private ClientWorld cachedWorld;
   private Entity playerPreviewEntity;
   private final CaptureFramebuffer captureFramebuffer = new CaptureFramebuffer();
   private EspRelation espRelation;
   private int previewPixelSize;
   private float yaw;
   private int framebufferHeight;
   private int skeletonTextureId;
   private int glowTextureId;

   public EspPreviewRenderer() {
      this.entityEspOverlayRenderer = new EntityEspOverlayRenderer();
      this.glowEspPreviewEffect = new GlowEspPreviewEffect();
      this.skeletonPreviewRenderer = new SkeletonPreviewRenderer();
      this.espRelation = EspRelation.DEFAULT;
   }

   private static float clampPitch(float pitch) {
      return Math.max(-35.0F, Math.min(35.0F, pitch));
   }

   private void clearPreviewMetadata(EntityRenderState illiliIIiI2) {
      illiliIIiI2.displayName = null;
      illiliIIiI2.nameLabelPos = null;
      illiliIIiI2.outlineColor = 0;
      illiliIIiI2.invisible = false;
      illiliIIiI2.onFire = false;
      illiliIIiI2.shadowRadius = 0.0F;
      illiliIIiI2.shadowPieces.clear();
      illiliIIiI2.light = 15728880;
      if (illiliIIiI2 instanceof PlayerEntityRenderState playerEntityRenderState) {
         playerEntityRenderState.capeVisible = false;
      }
   }

   private Consumer<DrawContext> createEntityDrawTask(Entity member4759, float f, float f2) {
      if (member4759 == null) {
         return null;
      }

      EntityRenderState illiliIIiI2 = this.client.getEntityRenderDispatcher().getAndUpdateRenderState(member4759, f);
      if (illiliIIiI2 == null) {
         return null;
      }

      this.clearPreviewMetadata(illiliIIiI2);
      Quaternionf quaternionf = new Quaternionf().rotateZ((float) Math.PI);
      float f3;
      float f4;
      if (illiliIIiI2 instanceof LivingEntityRenderState livingEntityRenderState) {
         livingEntityRenderState.bodyYaw = 180.0F + this.yaw;
         livingEntityRenderState.relativeHeadYaw = 0.0F;
         livingEntityRenderState.pitch = this.pitch;
         float f5 = illiliIIiI2.height <= 0.0F ? 1.8F : illiliIIiI2.height;
         f4 = this.previewSize * f2;
         f3 = f5 / 2.0F + 0.035F;
      } else {
         quaternionf.rotateY((float)Math.toRadians(this.yaw));
         f4 = this.previewSize * 0.8F;
         f3 = 0.0F;
      }

      Vector3f translation = new Vector3f(0.0F, f3, 0.0F);
      Quaternionf quaternionf2 = new Quaternionf().rotateX((float)Math.toRadians(-this.pitch));
      return context -> context.addEntity(illiliIIiI2, f4, translation, quaternionf, quaternionf2, 0, 0, this.previewSize, this.previewSize);
   }

   private String getDonationLabel(EspTargetType espTargetType) {
      return (espTargetType == EspTargetType.PLAYERS || espTargetType == EspTargetType.SELF) && this.client.player != null
         ? this.readDonationItemId(this.client.player.getOffHandStack())
         : null;
   }

   public void beginRotation(int n, int n2, GuiBounds bounds2) {
      if (bounds2.contains(n, n2)) {
         this.rotating = true;
         this.lastMouseX = this.getMouseX();
         this.lastMouseY = this.getMouseY();
      }
   }

   public void close() {
      this.rendered = false;
      this.lastRequestedTargetType = null;
      this.lastRequestedRelation = null;
      this.lastRequestedSize = -1.0F;
      this.lastRequestedYaw = Float.NaN;
      this.lastRequestedPitch = Float.NaN;
      this.captureFramebuffer.delete();
      this.entityEspOverlayRenderer.update();
      this.glowEspPreviewEffect.releaseFramebuffers();
      this.skeletonPreviewRenderer.close();
      this.mobPreviewEntity = null;
      this.playerPreviewEntity = null;
      this.cachedWorld = null;
   }

   public void render(GuiDrawApi drawApi, Matrix4f matrix4f, GuiBounds bounds2) {
      if (this.rendered && this.captureFramebuffer.getIntType() > 0) {
         float f = Math.min(bounds2.getWidth(), bounds2.getHeight());
         float f2 = bounds2.getX() + (bounds2.getWidth() - f) / 2.0F;
         float f3 = bounds2.getY() + (bounds2.getHeight() - f) / 2.0F;
         float f4 = (float)this.previewPixelSize / this.framebufferWidth;
         float f5 = 1.0F - (float)this.previewPixelSize / this.framebufferHeight;
         EspTargetType espTargetType = this.espTargetType;
         if (this.glowTextureId != 0) {
            int n = drawApi.bindTexture(this.glowTextureId, this.glowEspPreviewEffect.getWidth(), this.glowEspPreviewEffect.getHeight());
            drawApi.drawTexture(matrix4f, f2, f3, f, f, 0.0F, 1.0F, f4, f5, n, -1);
         }

         int n = drawApi.bindTexture(this.captureFramebuffer.getIntType(), this.framebufferWidth, this.framebufferHeight);
         drawApi.drawTexture(matrix4f, f2, f3, f, f, 0.0F, 1.0F, f4, f5, n, -1);
         EspFeatureRegistry espFeatures = WexSideClient.getEspFeatureRegistry();
         ChamsSettings chamsSettings = espFeatures != null && espTargetType == EspTargetType.PLAYERS ? espFeatures.getChamsSettings(this.espRelation) : null;
         if (chamsSettings != null && chamsSettings.isEnabled() && (chamsSettings.isVisibleFillEnabled() || chamsSettings.isHiddenFillEnabled())) {
            int chamsColor = chamsSettings.isVisibleFillEnabled() ? chamsSettings.getVisibleColor() : chamsSettings.getHiddenColor();
            n = drawApi.bindTexture(this.captureFramebuffer.getIntType(), this.framebufferWidth, this.framebufferHeight);
            drawApi.drawChamsPreviewTexture(matrix4f, f2, f3, f, f, 0.0F, 1.0F, f4, f5, n, chamsColor, chamsSettings.getMaterialModeIndex());
         }

         if (this.skeletonTextureId != 0) {
            int n3 = drawApi.bindTexture(this.skeletonTextureId, this.framebufferWidth, this.framebufferHeight);
            drawApi.drawTexture(matrix4f, f2, f3, f, f, 0.0F, 1.0F, f4, f5, n3, -1);
         }

         this.entityEspOverlayRenderer
            .process2(
               drawApi,
               matrix4f,
               this.calculateOverlayBounds(espTargetType, f2, f3, f),
               espTargetType,
               this.espRelation,
               this.getModelYaw(espTargetType),
               this.getDisplayName(espTargetType),
               this.getHealthValue(espTargetType),
               this.getEffectDuration(espTargetType),
               this.getHeldItemBadge(espTargetType),
               this.getDonationLabel(espTargetType)
            );
      }
   }

   public void requestPreviewRender(EspTargetType espTargetType, EspRelation espRelation, float f) {
      EspRelation espRelation2 = espRelation == null ? EspRelation.DEFAULT : espRelation;
      boolean bl = this.lastRequestedTargetType != espTargetType
         || this.lastRequestedRelation != espRelation2
         || Math.abs(this.lastRequestedSize - f) > 0.5F
         || Math.abs(this.lastRequestedYaw - this.yaw) > 0.5F
         || Math.abs(this.lastRequestedPitch - this.pitch) > 0.5F
         || !this.rendered;
      this.requestedSize = f;
      if (bl) {
         this.lastRequestedTargetType = espTargetType;
         this.lastRequestedRelation = espRelation2;
         this.lastRequestedSize = f;
         this.lastRequestedYaw = this.yaw;
         this.lastRequestedPitch = this.pitch;
         DeferredRenderTask.setRunnable(() -> this.renderPreview(espTargetType, espRelation2));
      }
   }

   public void updatePreviewRotation() {
      if (this.rotating && !this.isLeftMouseDown()) {
         this.rotating = false;
      }

      if (this.rotating) {
         double d = this.getMouseX();
         double d2 = this.getMouseY();
         this.yaw = wrapYaw(this.yaw - (float)(d - this.lastMouseX) * 1.2F);
         this.pitch = clampPitch(this.pitch + (float)(d2 - this.lastMouseY) * 1.2F);
         this.lastMouseX = d;
         this.lastMouseY = d2;
      } else {
         this.yaw = FrameInterpolator.lerpTowards(this.yaw, 0.0F, 8.0F);
         this.pitch = FrameInterpolator.lerpTowards(this.pitch, 0.0F, 8.0F);
      }
   }

   private void renderPreview(EspTargetType espTargetType, EspRelation espRelation) {
      this.rendered = false;
      this.glowTextureId = 0;
      this.skeletonTextureId = 0;
      this.espTargetType = espTargetType;
      EspRelation espRelation2 = this.espRelation = espRelation == null ? EspRelation.DEFAULT : espRelation;
      if (this.client.world != null && this.client.player != null) {
         OffscreenRenderManager renderPipeline2 = WexSideClient.getRenderPipeline2();
         if (renderPipeline2 != null) {
            Window window2 = this.client.getWindow();
            int n = window2.getFramebufferWidth();
            int n2 = window2.getFramebufferHeight();
            float f = window2.getScaleFactor();
            this.updatePreviewSize(f, n, n2);
            int n3 = Math.round(this.previewSize * f);
            if (n > 0 && n2 > 0 && n3 > 0 && n3 <= n && n3 <= n2) {
               float f2 = this.client.getRenderTickCounter().getTickProgress(true);
               Consumer<DrawContext> consumer = espTargetType == EspTargetType.ITEMS ? null : this.createPreviewDrawTask(espTargetType, f2);
               if (espTargetType == EspTargetType.ITEMS || consumer != null) {
                  int n4 = GL30.glGetInteger(36006);
                  int[] nArray = new int[4];
                  GL11.glGetIntegerv(2978, nArray);

                  try {
                     if (espTargetType == EspTargetType.ITEMS) {
                        renderPipeline2.process5(
                           this.captureFramebuffer,
                           n,
                           n2,
                           ITEM_PREVIEW_STACK,
                           ItemDisplayContext.GUI,
                           this.previewSize / 2.0F,
                           this.previewSize / 2.0F,
                           this.getItemRenderScale(),
                           -this.yaw,
                           this.pitch
                        );
                     } else {
                        renderPipeline2.process4(this.captureFramebuffer, n, n2, consumer);
                     }

                     this.previewPixelSize = n3;
                     this.framebufferWidth = n;
                     this.framebufferHeight = n2;
                     this.rendered = true;
                     this.entityEspOverlayRenderer.process(espTargetType, this.espRelation, this.getEquipment(espTargetType), f);
                     EspFeatureRegistry espFeatures = WexSideClient.getEspFeatureRegistry();
                     GlowEspSettings glowEspSettings = espFeatures != null && espTargetType == EspTargetType.PLAYERS
                        ? espFeatures.getGlowSettings(this.espRelation)
                        : null;
                     if (glowEspSettings != null && glowEspSettings.isEnabled()) {
                        this.glowTextureId = this.glowEspPreviewEffect.render(this.captureFramebuffer, n, n2, glowEspSettings);
                     }

                     ModelEspSettings modelEspSettings = espFeatures != null && espTargetType == EspTargetType.PLAYERS
                        ? espFeatures.getModelEspSettings(this.espRelation)
                        : null;
                     Entity member4759;
                     if (modelEspSettings != null && modelEspSettings.isEnabled() && (member4759 = this.getPlayerPreviewEntity()) instanceof PlayerEntity) {
                        PlayerEntity player2 = (PlayerEntity)member4759;
                        this.skeletonTextureId = this.skeletonPreviewRenderer
                           .render(
                              renderPipeline2,
                              player2,
                              n,
                              n2,
                              this.previewSize / 2.0F,
                              this.previewSize / 2.0F,
                              this.previewSize * 0.4F,
                              -0.95F,
                              180.0F + this.yaw,
                              modelEspSettings
                           );
                     }
                  } catch (RuntimeException var25) {
                  } finally {
                     GL30.glBindFramebuffer(36160, n4);
                     GL11.glViewport(nArray[0], nArray[1], nArray[2], nArray[3]);
                  }
               }
            }
         }
      }
   }

   private ItemBadge getHeldItemBadge(EspTargetType espTargetType) {
      if ((espTargetType == EspTargetType.PLAYERS || espTargetType == EspTargetType.SELF) && this.client.player != null) {
         ItemBadge itemBadge = ItemBadge.fromStack(this.client.player.getMainHandStack());
         return itemBadge != null ? itemBadge : ItemBadge.fromStack(this.client.player.getOffHandStack());
      } else {
         return null;
      }
   }

   private String getDisplayName(EspTargetType espTargetType) {
      return switch (espTargetType == null ? EspTargetType.PLAYERS : espTargetType) {
         case ENTITIES -> this.mobPreviewEntity != null ? this.mobPreviewEntity.getName().getString() : "Entity";
         case ITEMS -> ITEM_PREVIEW_STACK.getName().getString();
         default -> this.client.player != null ? this.client.player.getName().getString() : "Player";
      };
   }

   private Entity getPlayerPreviewEntity() {
      if (this.client.world == null || this.client.player == null) {
         return null;
      }

      if (this.playerPreviewEntity != null && this.cachedWorld == this.client.world) {
         return this.playerPreviewEntity;
      }

      try {
         OtherClientPlayerEntity otherClientPlayerEntity = new OtherClientPlayerEntity(this.client.world, this.client.player.getGameProfile());
         otherClientPlayerEntity.copyPositionAndRotation(this.client.player);
         otherClientPlayerEntity.equipStack(EquipmentSlot.HEAD, withEnchantmentGlint(new ItemStack(Items.DIAMOND_HELMET)));
         otherClientPlayerEntity.equipStack(EquipmentSlot.CHEST, withEnchantmentGlint(new ItemStack(Items.DIAMOND_CHESTPLATE)));
         otherClientPlayerEntity.equipStack(EquipmentSlot.LEGS, withEnchantmentGlint(new ItemStack(Items.DIAMOND_LEGGINGS)));
         otherClientPlayerEntity.equipStack(EquipmentSlot.FEET, withEnchantmentGlint(new ItemStack(Items.DIAMOND_BOOTS)));
         otherClientPlayerEntity.equipStack(EquipmentSlot.MAINHAND, withEnchantmentGlint(new ItemStack(Items.DIAMOND_SWORD)));
         otherClientPlayerEntity.equipStack(EquipmentSlot.OFFHAND, withEnchantmentGlint(new ItemStack(Items.ENCHANTED_GOLDEN_APPLE)));
         this.playerPreviewEntity = otherClientPlayerEntity;
         this.cachedWorld = this.client.world;
      } catch (RuntimeException runtimeException) {
         return null;
      }

      return this.playerPreviewEntity;
   }

   private Consumer<DrawContext> createPreviewDrawTask(EspTargetType espTargetType, float f) {
      return switch (espTargetType) {
         case ENTITIES -> this.createEntityDrawTask(this.getMobPreviewEntity(), f, 0.42F);
         case ITEMS -> null;
         case PLAYERS, SELF -> this.createEntityDrawTask(this.getPlayerPreviewEntity(), f, 0.4F);
      };
   }

   private List<ItemStack> getEquipment(EspTargetType espTargetType) {
      if (espTargetType != EspTargetType.PLAYERS && espTargetType != EspTargetType.SELF) {
         return List.of();
      } else if (!(this.getPlayerPreviewEntity() instanceof LivingEntity entity2)) {
         return List.of();
      } else {
         ArrayList<ItemStack> equipment = new ArrayList<>();
         equipment.add(entity2.getMainHandStack());
         equipment.add(entity2.getOffHandStack());

         for (EquipmentSlot iliiIIiliI2 : ARMOR_SLOTS) {
            equipment.add(entity2.getEquippedStack(iliiIIiliI2));
         }

         equipment.removeIf(ItemStack::isEmpty);
         return equipment;
      }
   }

   private double getMouseX() {
      Window window2 = this.client.getWindow();
      return this.client.mouse.getScaledX(window2);
   }

   private String readDonationItemId(ItemStack stack2) {
      NbtComponent customData = stack2.get(DataComponentTypes.CUSTOM_DATA);
      if (customData != null && !customData.isEmpty()) {
         NbtCompound iiililiiII2 = customData.copyNbt();
         if (!iiililiiII2.contains("don-item")) {
            return null;
         }

         String string = iiililiiII2.getString("don-item", "");

         for (String string2 : DONATION_PREFIXES) {
            if (string.startsWith(string2)) {
               return string.substring(string2.length()).toUpperCase();
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private float getModelYaw(EspTargetType espTargetType) {
      return espTargetType == EspTargetType.ITEMS ? -this.yaw : this.yaw;
   }

   private GuiBounds calculateOverlayBounds(EspTargetType espTargetType, float f, float f2, float f3) {
      float f4;
      float f5;
      float f6;

      float f7 = switch (espTargetType == null ? EspTargetType.PLAYERS : espTargetType) {
         case ENTITIES -> {
            f6 = 0.3F;
            f5 = 0.3F;
            f4 = 0.17F;
            yield 0.04F;
         }
         case ITEMS -> {
            f6 = 0.24F;
            f5 = 0.24F;
            f4 = 0.2F;
            yield 0.2F;
         }
         case PLAYERS, SELF -> {
            f6 = 0.34F;
            f5 = 0.34F;
            f4 = 0.05F;
            yield 0.11F;
         }
      };
      float f8 = f + f6 * f3;
      float f9 = f2 + f4 * f3;
      float f10 = f3 * (1.0F - f6 - f5);
      float f11 = f3 * (1.0F - f4 - f7);
      return new GuiBounds(f8, f9, f10, f11);
   }

   private boolean isLeftMouseDown() {
      return GLFW.glfwGetMouseButton(this.client.getWindow().getHandle(), 0) == 1;
   }

   private int getEffectDuration(EspTargetType espTargetType) {
      return espTargetType == EspTargetType.ENTITIES ? 2000 : 0;
   }

   private float getItemRenderScale() {
      return this.previewSize * 0.7F;
   }

   private static ItemStack withEnchantmentGlint(ItemStack stack2) {
      stack2.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
      return stack2;
   }

   private Entity getMobPreviewEntity() {
      if (this.mobPreviewEntity == null && this.client.world != null) {
         try {
            this.mobPreviewEntity = EntityType.ZOMBIE.create(this.client.world, SpawnReason.COMMAND);
         } catch (RuntimeException var2) {
         }
      }

      return this.mobPreviewEntity;
   }

   private double getMouseY() {
      Window window2 = this.client.getWindow();
      return this.client.mouse.getScaledY(window2);
   }

   private int getHealthValue(EspTargetType espTargetType) {
      return switch (espTargetType == null ? EspTargetType.PLAYERS : espTargetType) {
         case ENTITIES -> 20;
         case ITEMS -> -1;
         case PLAYERS, SELF -> this.client.player != null ? Math.round(this.client.player.getHealth()) : 20;
      };
   }

   private void updatePreviewSize(float f, int n, int n2) {
      int n3 = f <= 0.0F ? 110 : Math.round(this.requestedSize * 2.0F / f);
      int n4 = f <= 0.0F ? 640 : (int)Math.floor(Math.min(n, n2) / f);
      this.previewSize = Math.max(110, Math.min(Math.min(640, n4), n3));
   }

   private static float wrapYaw(float f) {
      float f2 = f % 360.0F;
      if (f2 > 180.0F) {
         f2 -= 360.0F;
      }

      if (f2 < -180.0F) {
         f2 += 360.0F;
      }

      return f2;
   }
}
