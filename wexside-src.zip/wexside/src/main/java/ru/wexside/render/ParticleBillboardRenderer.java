package ru.wexside.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionfc;

public final class ParticleBillboardRenderer {
   private ParticleBillboardRenderer() {
   }

   public static void drawBatch(
      VertexConsumer vertices,
      Vec3d cameraPosition,
      Quaternionfc cameraRotation,
      double x,
      double y,
      double z,
      float width,
      float height,
      int color,
      float rotationDegrees,
      float u1,
      float v1,
      float u2,
      float v2
   ) {
      Matrix4f transform = new Matrix4f()
         .translation((float)(x - cameraPosition.x), (float)(y - cameraPosition.y), (float)(z - cameraPosition.z))
         .rotate(cameraRotation)
         .rotateZ((float)Math.toRadians(rotationDegrees));
      float halfWidth = width * 0.5F;
      float halfHeight = height * 0.5F;
      vertices.vertex(transform, -halfWidth, -halfHeight, 0.0F)
         .color(color)
         .texture(u1, v2)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(15728880)
         .normal(0.0F, 1.0F, 0.0F);
      vertices.vertex(transform, halfWidth, -halfHeight, 0.0F)
         .color(color)
         .texture(u2, v2)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(15728880)
         .normal(0.0F, 1.0F, 0.0F);
      vertices.vertex(transform, halfWidth, halfHeight, 0.0F)
         .color(color)
         .texture(u2, v1)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(15728880)
         .normal(0.0F, 1.0F, 0.0F);
      vertices.vertex(transform, -halfWidth, halfHeight, 0.0F)
         .color(color)
         .texture(u1, v1)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(15728880)
         .normal(0.0F, 1.0F, 0.0F);
   }

   public static void draw(
      double x,
      double y,
      double z,
      float width,
      float height,
      int color,
      Identifier texture,
      boolean cutout,
      float rotationDegrees,
      float u1,
      float v1,
      float u2,
      float v2
   ) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world != null && texture != null) {
         Camera camera = client.gameRenderer.getCamera();
         Vec3d cameraPosition = camera.getCameraPos();
         Quaternionfc cameraRotation = camera.getRotation();
         RenderLayer layer = cutout ? RenderLayers.entityCutoutNoCull(texture) : RenderLayers.entityTranslucent(texture);
         Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
         VertexConsumer vertices = consumers.getBuffer(layer);
         drawBatch(vertices, cameraPosition, cameraRotation, x, y, z, width, height, color, rotationDegrees, u1, v1, u2, v2);
         consumers.draw(layer);
      }
   }
}
