package ru.wexside.render.world;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public final class SnowballImpactPredictor {
   private static final int MAX_TICKS = 120;
   private static final double DRAG = 0.99;
   private static final double GRAVITY = 0.03;

   private SnowballImpactPredictor() {
   }

   public static Vec3d predict(SnowballEntity snowball) {
      return trace(snowball.getEntityPos(), snowball.getVelocity(), snowball);
   }

   public static Vec3d predict(PlayerEntity player) {
      Vec3d start = player.getEyePos().add(player.getRotationVec(1.0F).multiply(0.25));
      Vec3d velocity = player.getRotationVec(1.0F).normalize().multiply(1.5).add(player.getVelocity());
      return trace(start, velocity, player);
   }

   private static Vec3d trace(Vec3d start, Vec3d initialVelocity, Entity source) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world == null) {
         return null;
      }

      Vec3d position = start;
      Vec3d velocity = initialVelocity;

      for (int tick = 0; tick < 120; tick++) {
         Vec3d next = position.add(velocity);
         BlockHitResult hit = client.world.raycast(new RaycastContext(position, next, ShapeType.COLLIDER, FluidHandling.NONE, source));
         if (hit.getType() != Type.MISS) {
            return hit.getPos();
         }

         position = next;
         velocity = velocity.multiply(0.99).add(0.0, -0.03, 0.0);
         if (position.y < client.world.getBottomY() - 8) {
            break;
         }
      }

      return null;
   }
}
