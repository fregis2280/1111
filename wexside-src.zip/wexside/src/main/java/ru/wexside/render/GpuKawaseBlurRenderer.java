package ru.wexside.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.RenderSystem.ShapeIndexBuffer;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import com.mojang.blaze3d.vertex.VertexFormat.IndexType;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.OptionalInt;
import net.minecraft.client.texture.GlTexture;
import ru.wexside.misc.FrameRateLimiter;

public final class GpuKawaseBlurRenderer implements AutoCloseable {
   private static final int PASS_COUNT = 3;
   private static final int TARGET_COUNT = 4;
   private static final int REFRESH_RATE = 120;
   private static final int TEXTURE_USAGE_RENDER_TARGET_AND_SAMPLED = 12;
   private static final int VERTEX_BUFFER_USAGE = 32;
   private static final int UNIFORM_BUFFER_USAGE = 136;
   private static final int UNIFORM_BUFFER_SIZE = 16;
   private final FrameRateLimiter refreshLimiter = new FrameRateLimiter(120);
   private GpuKawaseBlurRenderer.BlurTarget[] targets = new GpuKawaseBlurRenderer.BlurTarget[0];
   private GpuBuffer quadVertexBuffer;
   private GpuBuffer uniformBuffer;
   private GpuTextureView ownedSourceView;
   private int width = -1;
   private int height = -1;
   private int lastRenderedFrame = Integer.MIN_VALUE;
   private int refreshDecisionFrame = Integer.MIN_VALUE;
   private float offset = 1.6F;
   private float uploadedOffset = Float.NaN;
   private boolean refreshAllowed;

   public void setOffset(float offset) {
      if (!(Math.abs(this.offset - offset) < 0.001F)) {
         this.offset = offset;
         this.invalidate();
      }
   }

   public void invalidate() {
      this.lastRenderedFrame = Integer.MIN_VALUE;
      this.refreshDecisionFrame = Integer.MIN_VALUE;
      this.refreshLimiter.reset();
   }

   public void capture(int frame, GpuTexture sourceTexture, GpuTextureView sourceView, int width, int height) {
      if (sourceTexture != null && width > 0 && height > 0) {
         long now = System.nanoTime();
         boolean targetsReusable = this.width == width && this.height == height && this.targets.length == 4 && this.targets[0].view != null;
         if (this.refreshDecisionFrame != frame) {
            this.refreshDecisionFrame = frame;
            boolean readableSourceView = this.refreshAllowed = !targetsReusable || this.refreshLimiter.canRun(now);
         }

         if (sourceView != null || !targetsReusable) {
            if (this.refreshAllowed && this.lastRenderedFrame != frame) {
               this.closeOwnedSourceView();
               GpuTextureView readableSourceView = sourceView;
               if (readableSourceView == null) {
                  readableSourceView = this.ownedSourceView = RenderSystem.getDevice().createTextureView(sourceTexture);
               }

               this.ensureTargets(width, height);
               this.renderBlurPyramid(readableSourceView);
               this.lastRenderedFrame = frame;
               this.refreshLimiter.markRun(now);
            }
         }
      }
   }

   public int getResultTextureId() {
      if (this.targets.length == 0) {
         return 0;
      }

      int n;
      if (this.targets[0].texture instanceof GlTexture glTexture) {
         n = glTexture.getGlId();
      } else {
         n = 0;
      }

      return n;
   }

   public GpuTextureView getResultView() {
      return this.targets.length == 0 ? null : this.targets[0].view;
   }

   private void ensureTargets(int width, int height) {
      if (this.width != width || this.height != height || this.targets.length != 4) {
         this.closeTargets();
         this.width = width;
         this.height = height;
         this.targets = new GpuKawaseBlurRenderer.BlurTarget[4];

         for (int level = 0; level < 4; level++) {
            int targetWidth = Math.max(1, width >> level);
            int targetHeight = Math.max(1, height >> level);
            int targetLevel = level;
            GpuTexture texture = RenderSystem.getDevice()
               .createTexture(() -> "wex/dc-kawase-" + targetLevel, 12, TextureFormat.RGBA8, targetWidth, targetHeight, 1, 1);
            this.targets[level] = new GpuKawaseBlurRenderer.BlurTarget(texture, RenderSystem.getDevice().createTextureView(texture));
         }
      }
   }

   private void renderBlurPyramid(GpuTextureView sourceView) {
      CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
      ShapeIndexBuffer sequentialIndices = RenderSystem.getSequentialBuffer(DrawMode.QUADS);
      GpuBuffer indexBuffer = sequentialIndices.getIndexBuffer(6);
      GpuBuffer vertexBuffer = this.getOrCreateQuadVertexBuffer();
      this.updateUniformBuffer(commandEncoder);
      this.renderFullscreenPass(
         commandEncoder, ClientRenderPipelines.KAWASE_DOWNSAMPLE, this.targets[1].view, sourceView, vertexBuffer, indexBuffer, sequentialIndices.getIndexType()
      );

      for (int level = 2; level <= 3; level++) {
         this.renderFullscreenPass(
            commandEncoder,
            ClientRenderPipelines.KAWASE_DOWNSAMPLE,
            this.targets[level].view,
            this.targets[level - 1].view,
            vertexBuffer,
            indexBuffer,
            sequentialIndices.getIndexType()
         );
      }

      for (int var7 = 3; var7 >= 1; var7--) {
         this.renderFullscreenPass(
            commandEncoder,
            ClientRenderPipelines.KAWASE_UPSAMPLE,
            this.targets[var7 - 1].view,
            this.targets[var7].view,
            vertexBuffer,
            indexBuffer,
            sequentialIndices.getIndexType()
         );
      }
   }

   private void renderFullscreenPass(
      CommandEncoder commandEncoder,
      RenderPipeline pipeline,
      GpuTextureView outputView,
      GpuTextureView inputView,
      GpuBuffer vertexBuffer,
      GpuBuffer indexBuffer,
      IndexType indexType
   ) {
      try (RenderPass renderPass = commandEncoder.createRenderPass(() -> "wex/dc-kawase", outputView, OptionalInt.empty())) {
         renderPass.setPipeline(pipeline);
         RenderSystem.bindDefaultUniforms(renderPass);
         renderPass.setUniform("KawaseData", this.uniformBuffer.slice());
         renderPass.setVertexBuffer(0, vertexBuffer);
         renderPass.setIndexBuffer(indexBuffer, indexType);
         renderPass.bindTexture("InSampler", inputView, RenderSystem.getSamplerCache().get(FilterMode.LINEAR));
         renderPass.drawIndexed(0, 0, 6, 1);
      }
   }

   private GpuBuffer getOrCreateQuadVertexBuffer() {
      if (this.quadVertexBuffer != null) {
         return this.quadVertexBuffer;
      }

      ByteBuffer vertices = ByteBuffer.allocateDirect(48).order(ByteOrder.nativeOrder());
      vertices.putFloat(-1.0F).putFloat(-1.0F).putFloat(0.0F);
      vertices.putFloat(1.0F).putFloat(-1.0F).putFloat(0.0F);
      vertices.putFloat(1.0F).putFloat(1.0F).putFloat(0.0F);
      vertices.putFloat(-1.0F).putFloat(1.0F).putFloat(0.0F);
      vertices.flip();
      this.quadVertexBuffer = RenderSystem.getDevice().createBuffer(() -> "wex/dc-kawase-quad", 32, vertices);
      return this.quadVertexBuffer;
   }

   private void updateUniformBuffer(CommandEncoder commandEncoder) {
      ByteBuffer uniformData = ByteBuffer.allocateDirect(16).order(ByteOrder.nativeOrder());
      uniformData.putFloat(this.offset).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
      uniformData.flip();
      if (this.uniformBuffer == null) {
         this.uniformBuffer = RenderSystem.getDevice().createBuffer(() -> "wex/dc-kawase-data", 136, uniformData);
         this.uploadedOffset = this.offset;
      } else {
         if (this.uploadedOffset != this.offset) {
            commandEncoder.writeToBuffer(this.uniformBuffer.slice(), uniformData);
            this.uploadedOffset = this.offset;
         }
      }
   }

   private void closeOwnedSourceView() {
      if (this.ownedSourceView != null) {
         this.ownedSourceView.close();
         this.ownedSourceView = null;
      }
   }

   private void closeTargets() {
      for (GpuKawaseBlurRenderer.BlurTarget target : this.targets) {
         if (target != null) {
            target.close();
         }
      }

      this.targets = new GpuKawaseBlurRenderer.BlurTarget[0];
      this.width = -1;
      this.height = -1;
      this.refreshAllowed = false;
      this.invalidate();
   }

   @Override
   public void close() {
      this.closeOwnedSourceView();
      if (this.quadVertexBuffer != null) {
         this.quadVertexBuffer.close();
         this.quadVertexBuffer = null;
      }

      if (this.uniformBuffer != null) {
         this.uniformBuffer.close();
         this.uniformBuffer = null;
      }

      this.uploadedOffset = Float.NaN;
      this.closeTargets();
   }

   private static final class BlurTarget implements AutoCloseable {
      private GpuTexture texture;
      private GpuTextureView view;

      private BlurTarget(GpuTexture texture, GpuTextureView view) {
         this.texture = texture;
         this.view = view;
      }

      @Override
      public void close() {
         if (this.view != null) {
            this.view.close();
            this.view = null;
         }

         if (this.texture != null) {
            this.texture.close();
            this.texture = null;
         }
      }
   }
}
