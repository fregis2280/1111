package ru.wexside.notification;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.entry.RegistryEntry;
import ru.wexside.WexSideClient;
import ru.wexside.module.Module;
import ru.wexside.setting.BooleanSetting;
import ru.wexside.setting.Setting;

public final class NotificationTracker {
   private final Map<Module, Boolean> moduleStates = new HashMap<>();
   private Set<RegistryEntry<StatusEffect>> activeEffects;

   public void tick() {
      MinecraftClient client = MinecraftClient.getInstance();
      NotificationCenter center = WexSideClient.getNotificationCenter();
      if (client.player != null && center != null) {
         this.trackModules(center);
         this.trackEffects(client.player.getStatusEffects(), center);
      } else {
         this.activeEffects = null;
      }
   }

   private void trackModules(NotificationCenter center) {
      Iterator<Module> iterator = WexSideClient.getInstance().getModuleManager().getModules().iterator();

      while (iterator.hasNext()) {
         Module module;
         Setting setting = (module = iterator.next()).getToggleSetting();
         BooleanSetting toggle;
         boolean enabled = setting instanceof BooleanSetting && (toggle = (BooleanSetting)setting).isEnabled();
         Boolean previous = this.moduleStates.put(module, enabled);
         if (previous != null && previous != enabled) {
            center.push(new ModuleToggleNotification(module.getDisplayName(), enabled));
         }
      }
   }

   private void trackEffects(Iterable<StatusEffectInstance> effects, NotificationCenter center) {
      HashSet<RegistryEntry<StatusEffect>> current = new HashSet<>();

      for (StatusEffectInstance class_12932 : effects) {
         current.add(class_12932.getEffectType());
      }

      if (this.activeEffects != null) {
         for (RegistryEntry class_68802 : this.activeEffects) {
            if (!current.contains(class_68802)) {
               center.push(new EffectExpiredNotification(class_68802));
            }
         }
      }

      this.activeEffects = current;
   }
}
