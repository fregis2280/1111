package ru.wexside.notification;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Objects;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import org.joml.Matrix4f;
import ru.wexside.WexSideClient;
import ru.wexside.util.GuiDrawApi;

public final class NotificationCenter {
   private static final int MAX_VISIBLE = 5;
   private static final int MAX_RETAINED = 8;
   private static final float ROW_HEIGHT = 17.5F;
   private static final long DEFAULT_DURATION_MILLIS = 3000L;
   private final NotificationPreferences preferences;
   private final LinkedList<NotificationToast> notifications = new LinkedList<>();

   public NotificationCenter(NotificationPreferences preferences) {
      this.preferences = Objects.requireNonNull(preferences, "preferences");
   }

   public void push(NotificationFactory factory) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (!client.isOnThread()) {
         client.execute(() -> this.push(factory));
      } else if (client.player != null && this.preferences.isEnabled() && this.preferences.isCategoryVisible(factory.category())) {
         NotificationToast incoming = factory.create(3000L);
         if (incoming.key() != null) {
            for (NotificationToast existing : this.notifications) {
               if (Objects.equals(existing.key(), incoming.key())) {
                  existing.updateContent(incoming.icon(), incoming.accentColor(), incoming.parts());
                  this.playSound(factory.category());
                  return;
               }
            }
         }

         this.notifications.addLast(incoming);
         int active = 0;

         for (NotificationToast notification : this.notifications) {
            if (!notification.isDismissing()) {
               if (++active > 5) {
                  notification.beginDismiss();
               }
            }
         }

         while (this.notifications.size() > 8) {
            this.notifications.removeFirst().remove();
         }

         this.playSound(factory.category());
      }
   }

   public boolean accepts(NotificationCategory category) {
      return this.preferences.isEnabled() && this.preferences.isCategoryVisible(category);
   }

   public void render(float tickDelta) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.player != null && !this.notifications.isEmpty()) {
         GuiDrawApi renderer = WexSideClient.getHudRenderer();
         if (renderer != null) {
            Iterator iterator = this.notifications.iterator();
            int row = 0;
            float startY = client.getWindow().getScaledHeight() * 0.5F + 20.0F * tickDelta;
            float centerX = client.getWindow().getScaledWidth() * 0.5F;
            Matrix4f matrix = new Matrix4f().scale(client.getWindow().getScaleFactor());
            renderer.begin();

            try {
               while (iterator.hasNext()) {
                  NotificationToast notification = (NotificationToast)iterator.next();
                  notification.moveTo(startY + row * 17.5F * tickDelta, tickDelta);
                  if (notification.isExpired()) {
                     iterator.remove();
                  } else {
                     notification.render(renderer, matrix, centerX, tickDelta);
                     row++;
                  }
               }
            } finally {
               renderer.end();
            }
         }
      }
   }

   private void playSound(NotificationCategory category) {
      if (this.preferences.isSoundEnabled(category)) {
         MinecraftClient.getInstance()
            .getSoundManager()
            .play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK.value(), Math.max(0.0F, Math.min(1.0F, this.preferences.soundVolume()))));
      }
   }
}
