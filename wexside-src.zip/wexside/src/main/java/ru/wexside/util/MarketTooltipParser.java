package ru.wexside.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public final class MarketTooltipParser {
   private static final Pattern NUMBER = Pattern.compile("\\d+");
   private static final String BUY_PROMPT = "нажмите, чтобы купить";

   public MarketTooltipParser.DonMarketOffer parseDonMarketOffer(ItemStack stack, MinecraftClient client) {
      if (stack != null && !stack.isEmpty() && client != null) {
         Integer balance = null;
         Integer exchangeRate = null;
         Integer price = null;
         boolean purchasable = false;

         for (Text line : Screen.getTooltipFromItem(client, stack)) {
            String text = line.getString().toLowerCase();
            if (text.contains("биржа баланс:")) {
               balance = firstNumber(text);
            } else if (text.contains("курс:")) {
               exchangeRate = firstNumber(text);
            } else if (text.contains("цена:")) {
               price = firstNumber(text);
            } else if (text.contains("нажмите, чтобы купить")) {
               purchasable = true;
            }
         }

         return purchasable && balance != null && exchangeRate != null && price != null && balance >= price
            ? new MarketTooltipParser.DonMarketOffer(balance, exchangeRate, price)
            : null;
      } else {
         return null;
      }
   }

   public Integer parseAuctionPrice(ItemStack stack, MinecraftClient client) {
      if (stack != null && !stack.isEmpty() && client != null) {
         boolean purchasable = false;
         Integer highestDollarValue = null;

         for (Text line : Screen.getTooltipFromItem(client, stack)) {
            String text = line.getString();
            if (text.toLowerCase().contains("нажмите, чтобы купить")) {
               purchasable = true;
            }

            Integer value;
            int dollar;
            if ((dollar = text.indexOf(36)) >= 0
               && (value = parseDigits(text.substring(dollar + 1))) != null
               && (highestDollarValue == null || value > highestDollarValue)) {
               highestDollarValue = value;
            }
         }

         return purchasable ? highestDollarValue : null;
      } else {
         return null;
      }
   }

   public Integer parseUnitAuctionPrice(ItemStack stack, MinecraftClient client) {
      Integer total = this.parseAuctionPrice(stack, client);
      return total == null ? null : total / Math.max(1, stack.getCount());
   }

   private static Integer firstNumber(String text) {
      Matcher matcher = NUMBER.matcher(text);
      return matcher.find() ? parseDigits(matcher.group()) : null;
   }

   private static Integer parseDigits(String text) {
      String digits = text.replaceAll("\\D", "");
      if (digits.isEmpty()) {
         return null;
      }

      try {
         return Integer.parseInt(digits);
      } catch (NumberFormatException ignored) {
         return null;
      }
   }

   public record DonMarketOffer(int balance, int exchangeRate, int price) {
   }
}
