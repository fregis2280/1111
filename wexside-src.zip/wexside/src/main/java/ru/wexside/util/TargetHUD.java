package ru.wexside.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.function.BooleanSupplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.MerchantEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.wexside.WexSideClient;
import ru.wexside.misc.BakedIconEntry;
import ru.wexside.misc.FontRegistry;
import ru.wexside.misc.FrameInterpolator;
import ru.wexside.misc.PreparedLayer;
import ru.wexside.misc.TextureHandle;
import ru.wexside.misc.ThemeColors;
import ru.wexside.module.Module;
import ru.wexside.module.combat.AttackAuraModule;
import ru.wexside.render.HudIconRenderer;
import ru.wexside.render.IconAtlasEntry;
import ru.wexside.render.ItemIconCache;
import ru.wexside.render.PlayerHeadRenderCache;
import ru.wexside.render.RenderFrameClock;

public final class TargetHUD extends AbstractHudElement {
   private final int slot;
   private float value4;
   private final BooleanSupplier booleanSupplier;
   private final Map<UUID, IconAtlasEntry> map2;
   private AttackAuraModule attackAuraModule;
   private LivingEntity entity2;
   private long longType;
   private int slot2 = -1;
   static final int slot3 = 64;
   private boolean enabled;
   private LivingEntity entity3;
   private float value15;
   private final int slot4 = ColorUtils.rgba(0, 0, 0, 40);
   private LivingEntity entity4;
   private int slot5 = -1;
   private float value18;
   private final ItemIconCache itemIconCache = new ItemIconCache();
   private float value25;
   private int slot6;
   private final int slot7 = 4;
   private final BooleanSupplier booleanSupplier2;

   public TargetHUD(BooleanSupplier booleanSupplier, BooleanSupplier booleanSupplier2, BooleanSupplier booleanSupplier3) {
      super("Target HUD", booleanSupplier);
      this.slot = 2;
      this.map2 = new PlayerHeadRenderCache(64);
      this.booleanSupplier = booleanSupplier2;
      this.booleanSupplier2 = booleanSupplier3;
   }

   public void clearCaches() {
      this.itemIconCache.update3();

      for (IconAtlasEntry renderPipeline10 : this.map2.values()) {
         renderPipeline10.update2();
      }

      this.map2.clear();
   }

   @Override
   protected float getWidth() {
      return 118.5F;
   }

   @Override
   protected void updateLayout() {
      LivingEntity entity5 = this.getCurrentTarget();
      boolean bl = false;
      if (entity5 != null) {
         this.entity2 = entity5;
         this.value25 = this.value15;
         this.value15 = this.process5(entity5.hurtTime);
         float f = healthFraction(entity5);
         this.value18 = FrameInterpolator.lerpTowards(this.value18, f, 20.0F);
         bl = entity5.isUsingItem() && this.process17(entity5);
      }

      this.enabled = bl;
      this.value4 = FrameInterpolator.lerpTowards(this.value4, bl ? 1.0F : 0.0F, 15.0F);
      this.update2();
   }

   @Override
   protected void renderContent(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3, float f4, float f5) {
      if (this.entity2 != null) {
         this.renderPanelSurface(drawApi, matrix4f, f, f2, f3, f4, 8.0F, f5);
         drawApi.beginStencil(1);
         drawApi.drawRoundedRectangle(matrix4f, f, f2, f3, f4, 8.0F * f5, -1);
         drawApi.applyStencilMask(1);
         this.process9(drawApi, matrix4f, f, f2, f5);
         this.process8(drawApi, matrix4f, f, f2, f5);
         this.process4(drawApi, matrix4f, f, f2, f5);
         this.process18(drawApi, matrix4f, f, f2, f5);
         this.process11(drawApi, matrix4f, f, f2, f5);
         this.process16(drawApi, matrix4f, f, f2, f5);
         drawApi.endStencil();
      }
   }

   private void update2() {
      if (this.entity2 != null) {
         float f = MinecraftClient.getInstance().getWindow().getScaleFactor();
         ArrayList<BakedIconEntry> arrayList = new ArrayList<>();
         LivingEntity livingEntity = this.entity2;
         AbstractClientPlayerEntity player;
         IconAtlasEntry headTexture;
         if (livingEntity instanceof AbstractClientPlayerEntity
            && (headTexture = this.map2.computeIfAbsent((player = (AbstractClientPlayerEntity)livingEntity).getUuid(), ignored -> new IconAtlasEntry(true)))
               .process(f)) {
            SkinTextures skin = player.getSkin();
            arrayList.add(new BakedIconEntry(headTexture, (context, x, y, size) -> HudIconRenderer.drawPlayerHead(context, skin, x, y, size)));
         }

         this.itemIconCache.update2();

         for (ItemStack equipment : this.getList()) {
            if (!equipment.isEmpty()) {
               this.itemIconCache.process(equipment);
            }
         }

         ItemStack activeItem = this.entity2.getActiveItem();
         if (this.enabled && !activeItem.isEmpty()) {
            this.itemIconCache.process(activeItem);
         }

         this.itemIconCache.process2(f, arrayList);
         if (!arrayList.isEmpty()) {
            WexSideClient.getRenderPipeline2().setList(arrayList);
         }

         this.itemIconCache.update();
      }
   }

   @Override
   protected float getHeight() {
      return 36.0F;
   }

   @Override
   protected boolean isContentVisible() {
      if (this.getCurrentTarget() == null) {
         this.slot2 = -1;
         return false;
      }

      int n = this.getIntType();
      if (this.slot2 < 0) {
         this.slot2 = n;
      }

      return n - this.slot2 >= 2;
   }

   private LivingEntity getLivingEntity() {
      if (this.attackAuraModule == null) {
         for (Module module : WexSideClient.getInstance().getModuleManager().getModules()) {
            if (module instanceof AttackAuraModule) {
               AttackAuraModule attackAuraModule;
               this.attackAuraModule = attackAuraModule = (AttackAuraModule)module;
               break;
            }
         }
      }

      return this.attackAuraModule != null ? this.attackAuraModule.getLivingEntity() : null;
   }

   private IconAtlasEntry process2(LivingEntity entity5) {
      return !(entity5 instanceof PlayerEntity player2) ? null : this.map2.get(player2.getUuid());
   }

   private LivingEntity process3(float f) {
      MinecraftClient mc = MinecraftClient.getInstance();
      ClientPlayerEntity player3 = mc.player;
      if (player3 != null && mc.world != null) {
         float f2 = mc.getRenderTickCounter().getTickProgress(false);
         Vec3d vec3 = player3.getCameraPosVec(f2);
         Vec3d vec;
         EntityHitResult iIIIllIilI2 = ProjectileUtil.raycast(
            player3,
            vec3,
            vec3.add((vec = player3.getRotationVec(f2)).multiply(f)),
            player3.getBoundingBox().stretch(vec.multiply(f)).expand(1.0),
            entity -> entity instanceof LivingEntity && entity != player3 && entity.isAlive(),
            f * f
         );
         Entity iIiiiilIiI2;
         if (iIIIllIilI2 != null && (iIiiiilIiI2 = iIIIllIilI2.getEntity()) instanceof LivingEntity) {
            LivingEntity entity5 = (LivingEntity)iIiiiilIiI2;
            return entity5;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private void process4(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3) {
      int n = ThemeColors.accent();
      String string2;
      String string = !(this.entity2 instanceof PlayerEntity)
         ? this.process10(this.entity2)
         : (process12(string2 = this.process7(this.entity2)) ? string2 : "Игрок");
      FontRegistry.font6.process2(matrix4f, drawApi, string, f + 35.0F * f3, f2 + 6.25F * f3, 5.0F * f3, n);
   }

   private float process5(int n) {
      int n2 = 10 - n;
      if (n2 == 10) {
         return 0.0F;
      }

      float f = n2 / 10.0F * 2.0F;
      if (f > 1.0F) {
         f = 2.0F - f;
      }

      return f;
   }

   private void process6(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3, float f4, int n) {
      drawApi.drawRoundedShadow(matrix4f, f, f2, f3, f3, 6.0F * f4, 5.0F * f4, this.slot4);
      IconAtlasEntry renderPipeline10 = this.process2(this.entity2);
      if (renderPipeline10 != null && renderPipeline10.isActive()) {
         int n2 = drawApi.bindTexture(renderPipeline10.getIntType4(), renderPipeline10.getIntType(), renderPipeline10.getIntType());
         drawApi.drawRoundedTexture(matrix4f, f, f2, f3, f3, 0.0F, 1.0F, 1.0F, 0.0F, 6.0F * f4, n2, n);
      } else {
         drawApi.drawRoundedRectangle(matrix4f, f, f2, f3, f3, 6.0F * f4, n);
      }
   }

   private String process7(LivingEntity entity5) {
      Team team2 = entity5.getScoreboardTeam();
      return team2 == null ? "" : team2.getPrefix().getString().replaceAll("§.?", "").trim();
   }

   private void process8(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3) {
      if (!(this.value4 < 0.001F) && this.entity2 != null && this.enabled) {
         ItemStack stack = this.entity2.getActiveItem();
         if (!stack.isEmpty()) {
            int n = (int)Math.clamp(this.value4 * 255.0F, 0.0F, 255.0F);
            int n2 = ColorUtils.rgba(255, 255, 255, n);
            float f4 = 12.0F * f3;
            float f5 = f + 12.0F * f3;
            float f6 = f2 + 8.0F * f3;
            this.itemIconCache.process4(drawApi, matrix4f, this.itemIconCache.process(stack), f5, f6, f4, n2);
            String string = String.format(Locale.ROOT, "%.2fс", this.process15(stack));
            float f7 = FontRegistry.font6.process3(string, 5.0F);
            float f8 = f + 18.0F * f3 - f7 * f3 / 2.0F;
            float f9 = f2 + 21.0F * f3;
            FontRegistry.font6.process2(matrix4f, drawApi, string, f8, f9, 5.0F * f3, n2);
         }
      }
   }

   private List<ItemStack> getList() {
      ArrayList<ItemStack> arrayList = new ArrayList<>(6);
      arrayList.add(this.entity2.getEquippedStack(EquipmentSlot.HEAD));
      arrayList.add(this.entity2.getEquippedStack(EquipmentSlot.CHEST));
      arrayList.add(this.entity2.getEquippedStack(EquipmentSlot.LEGS));
      arrayList.add(this.entity2.getEquippedStack(EquipmentSlot.FEET));
      arrayList.add(this.entity2.getMainHandStack());
      arrayList.add(this.entity2.getOffHandStack());
      return arrayList;
   }

   private void process9(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3) {
      float f4 = f + 5.0F * f3;
      float f5 = f2 + 5.0F * f3;
      float f6 = 26.0F * f3;
      float f7 = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
      float f8 = this.value25 + (this.value15 - this.value25) * f7;
      float f9 = this.booleanSupplier2.getAsBoolean() ? f8 * 0.5F : 0.0F;
      int n = Math.round((1.0F - f9) * 255.0F);
      int n2 = ColorUtils.rgba(255, n, n, 255);
      if (this.value4 < 0.001F) {
         this.process6(drawApi, matrix4f, f4, f5, f6, f3, n2);
      } else {
         this.process13(drawApi, matrix4f, f4, f5, f6, f3, n2);
      }
   }

   private String process10(LivingEntity entity5) {
      if (entity5 instanceof MerchantEntity) {
         return "Житель";
      } else if (entity5 instanceof AnimalEntity) {
         return "Животное";
      } else {
         return entity5 instanceof MobEntity ? "Моб" : "Существо";
      }
   }

   private void process11(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3) {
      List<ItemStack> list = this.getList();
      float f4 = f + 35.0F * f3;
      float f5 = 6.0F * f3;
      float f6 = f2 + 23.25F * f3;

      for (int i = 0; i < list.size(); i++) {
         ItemStack stack = list.get(i);
         if (!stack.isEmpty()) {
            this.itemIconCache.process4(drawApi, matrix4f, this.itemIconCache.process(stack), f4, f6, f5, -1);
         } else if (i < 4) {
            drawApi.drawRoundedRectangle(matrix4f, f4, f6, f5, f5, 4.0F * f3, ThemeColors.visualizerSlot());
         }

         f4 += 8.5F * f3;
      }
   }

   private static boolean process12(String string) {
      for (int i = 0; i < string.length(); i++) {
         if (Character.isLetterOrDigit(string.charAt(i))) {
            return true;
         }
      }

      return false;
   }

   private void process13(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3, float f4, int n) {
      float f5 = 16.0F * f4;
      drawApi.begin();
      PreparedLayer preparedLayer = drawApi.prepareLayer(matrix4f, f, f2, f3, f3, f5);
      drawApi.beginLayerFrame(preparedLayer.getTexture());
      Matrix4f matrix4f2 = new Matrix4f(preparedLayer.getContentMatrix()).translate(preparedLayer.contentX(), preparedLayer.contentY(), 0.0F);
      this.process6(drawApi, matrix4f2, 0.0F, 0.0F, f3, f4, n);
      drawApi.endLayerFrame();
      TextureHandle texture = drawApi.blurTexture(preparedLayer.getTexture(), this.value4 * 4.0F);
      drawApi.drawLayerTexture(
         matrix4f,
         texture,
         preparedLayer.drawX(),
         preparedLayer.drawY(),
         preparedLayer.drawWidth(),
         preparedLayer.drawHeight(),
         0.0F,
         1.0F,
         preparedLayer.maxU(),
         1.0F - preparedLayer.maxV(),
         -1
      );
      drawApi.end();
   }

   private String process14(String string, float f, float f2) {
      if (FontRegistry.font2.process3(string, f) <= f2) {
         return string;
      }

      String string2 = "…";
      float f3 = FontRegistry.font2.process3(string2, f);
      StringBuilder stringBuilder = new StringBuilder();

      for (int i = 0; i < string.length(); i++) {
         char c = string.charAt(i);
         String string3 = stringBuilder.toString();
         String string4 = string3 + c;
         if (FontRegistry.font2.process3(string4, f) + f3 > f2) {
            break;
         }

         stringBuilder.append(string.charAt(i));
      }

      String string5 = string2;
      String string6 = String.valueOf(stringBuilder);
      return string6 + string5;
   }

   private LivingEntity resolveTarget() {
      LivingEntity entity5 = this.getLivingEntity();
      if (entity5 != null) {
         return entity5;
      }

      LivingEntity raycastTarget = this.booleanSupplier.getAsBoolean() ? this.process3(50.0F) : null;
      if (raycastTarget != null) {
         return raycastTarget;
      }

      MinecraftClient mc = MinecraftClient.getInstance();
      return mc.currentScreen instanceof ChatScreen && mc.player != null ? mc.player : null;
   }

   private float process15(ItemStack stack) {
      int n = this.entity2.getItemUseTime();

      int n2 = switch (stack.getUseAction()) {
         case BOW, SPEAR, CROSSBOW -> this.entity2.getItemUseTimeLeft();
         case EAT, DRINK -> 20 - n;
         case BLOCK -> 25 - n;
         case TOOT_HORN, BRUSH -> 10 - n;
         default -> n;
      };
      return Math.max(0.0F, n2 / 20.0F);
   }

   private void process16(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3) {
      float f4 = f + 0.5F + 100.5F * f3;
      float f5 = f2 + 0.5F + 18.0F * f3;
      float f6 = 10.0F * f3;
      float f7 = 2.5F * f3;
      drawApi.drawCircle(matrix4f, f4, f5, 0.0F, 360.0F, f7, f6, ThemeColors.separatorHover());
      float f8 = this.value18 * 360.0F;
      if (f8 > 0.0F) {
         drawApi.drawCircle(matrix4f, f4, f5, 0.0F, f8, f7, f6, ThemeColors.accent());
      }

      int n;
      boolean bl = (n = healthValue(this.entity2)) == 0 || n == 1000;
      String string = bl ? "?" : String.valueOf(n);
      float f9 = FontRegistry.font6.process3(string, 6.5F);
      float f10 = FontRegistry.font6.process4(string, 6.5F);
      FontRegistry.font6.process2(matrix4f, drawApi, string, f4 - f9 * f3 / 2.0F, f5 - f10 * f3 / 2.0F, 6.5F * f3, ThemeColors.hudTextPrimary());
   }

   private LivingEntity getCurrentTarget() {
      int n = RenderFrameClock.currentFrame();
      if (n != this.slot5) {
         this.slot5 = n;
         this.entity3 = this.resolveTarget();
      }

      return this.entity3;
   }

   private boolean process17(LivingEntity entity5) {
      int n = entity5.getItemUseTimeLeft();
      long l = System.currentTimeMillis();
      if (entity5 == this.entity4 && n == this.slot6) {
         return l - this.longType < 750L;
      }

      this.entity4 = entity5;
      this.slot6 = n;
      this.longType = l;
      return true;
   }

   private void process18(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3) {
      String string = this.entity2.getName().getString();
      float f4 = 55.5F;
      String string2 = this.process14(string, 7.5F, f4);
      FontRegistry.font2.process2(matrix4f, drawApi, string2, f + 35.0F * f3, f2 + 12.25F * f3, 7.5F * f3, ThemeColors.hudTextPrimary());
   }

   private int getIntType() {
      ClientPlayerEntity player3 = MinecraftClient.getInstance().player;
      return player3 != null ? player3.age : 0;
   }

   private static int healthValue(LivingEntity entity) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world != null) {
         Scoreboard scoreboard = client.world.getScoreboard();
         ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
         ReadableScoreboardScore score = objective == null ? null : scoreboard.getScore(entity, objective);
         if (score != null) {
            return score.getScore();
         }
      }

      return Math.round(entity.getHealth());
   }

   private static float healthFraction(LivingEntity entity) {
      float maximum = entity.getMaxHealth();
      return maximum <= 0.0F ? 0.0F : Math.clamp(healthValue(entity) / maximum, 0.0F, 1.0F);
   }
}
