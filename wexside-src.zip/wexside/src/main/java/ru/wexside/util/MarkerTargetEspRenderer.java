package ru.wexside.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import ru.wexside.animation.TimedPulse;
import ru.wexside.event.EntityAttackEvent;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.LazyMeshModel;
import ru.wexside.misc.PreviousValueTransition;
import ru.wexside.misc.SpatialTransform;
import ru.wexside.misc.TargetChange;
import ru.wexside.misc.TargetEspEffect;
import ru.wexside.misc.TargetTransition;
import ru.wexside.misc.TransitionPhase;
import ru.wexside.module.render.TargetEspRenderer;
import ru.wexside.render.model.BuiltInMesh;

public final class MarkerTargetEspRenderer extends TargetEspRenderer implements TargetEspEffect {
   private final LazyMeshModel lazyMeshModel = LazyMeshModel.create(BuiltInMesh.MARKER);
   static final long member5632 = 420L;
   private final PreviousValueTransition<MarkerTargetEspRenderer.TargetMarkerState> previousState;
   static final float value4 = 0.4F;
   private static final WorldMeshBatchRenderer MODEL_RENDERER = new WorldMeshBatchRenderer("target-marker");
   static final float value5 = 1.5F;
   static final float value6 = 0.42F;
   static final float value7 = 0.25F;
   private final ModelRenderOptions modelRenderOptions;
   private final TargetTransition<Entity> targetTransition;
   private MarkerTargetEspRenderer.TargetMarkerState lastState;
   static final long member8917 = 320L;
   static final long member12527 = 300L;
   static final int slot = -65476;
   static final float value8 = 1.28F;
   private final ModelRenderQueue modelRenderQueue = new ModelRenderQueue();
   static final float value9 = 0.5F;
   private final TimedPulse attackPulse;
   static final float value10 = 1.16F;

   public MarkerTargetEspRenderer() {
      this.modelRenderOptions = ModelRenderOptions.process4(true).process10(false);
      this.targetTransition = new TargetTransition<>();
      this.attackPulse = new TimedPulse();
      this.previousState = new PreviousValueTransition<>();
   }

   @Override
   public void setEntityAttackEvent(EntityAttackEvent iIiiiilIiIEvent) {
      if (iIiiiilIiIEvent.getEntity() != null) {
         this.attackPulse.trigger();
      }
   }

   @Override
   public void setWorldRenderEvent(WorldRenderEvent floatTypeEvent2) {
      MinecraftClient mc = this.client();
      if (this.canRender(mc)) {
         if (this.lazyMeshModel.isLoaded() && this.lazyMeshModel.getMeshModel() != null && !this.lazyMeshModel.getMeshModel().getList().isEmpty()) {
            this.process2(this.target(mc, Entity.class), floatTypeEvent2.getFloatType());
            if (!this.targetTransition.isEmpty()) {
               float f = this.getTransitionOpacity();
               Entity target = this.targetTransition.current();
               if (!(f <= 0.0F)) {
                  MarkerTargetEspRenderer.TargetMarkerState state = target != null ? this.captureState(target, floatTypeEvent2.getFloatType()) : null;
                  if (state != null) {
                     this.lastState = state;
                  } else {
                     state = this.lastState;
                  }

                  if (state == null) {
                     this.update2();
                  } else {
                     this.modelRenderQueue.update();
                     this.renderMarker(this.interpolatePreviousState(state), this.getMarkerScale(), f);
                     if (!this.modelRenderQueue.isActive()) {
                        MODEL_RENDERER.process10(
                           floatTypeEvent2.getMatrices(), mc.getBufferBuilders().getEntityVertexConsumers(), this.cameraPosition(), this.modelRenderQueue
                        );
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void update() {
      this.update2();
      this.modelRenderQueue.update();
   }

   private void update2() {
      this.targetTransition.reset();
      this.attackPulse.reset();
      this.previousState.reset();
      this.lastState = null;
   }

   private void renderMarker(MarkerTargetEspRenderer.TargetMarkerState state, float f, float f2) {
      long l = System.currentTimeMillis();
      Vec3d vec = this.cameraPosition();
      double d = state.position().x;
      double d2 = state.position().y + state.height() * 0.65;
      double d3 = state.position().z;
      double d4 = vec.x - d;
      double d5 = vec.y - d2;
      double d6 = vec.z - d3;
      float f4 = (float)Math.toDegrees(Math.atan2(d4, d6));
      float f5 = (float)Math.toDegrees(-Math.atan2(d5, Math.sqrt(d4 * d4 + d6 * d6)));
      float f6 = 1.0F + AnimationMath.sin((float)l * 0.004F) * 0.035F;
      float f7 = AnimationMath.sin((float)l * 0.005F) * 0.035F;
      f *= f6;
      int n = this.process3(this.primaryColor(), this.secondaryColor(), l);
      if (this.attackPulse.isActive(l, 320L)) {
         float f3 = this.attackPulse.progress(l, 320L);
         float f8 = f3 < 0.5F ? f3 / 0.5F : (f3 - 0.5F) / 0.5F;
         float f9 = AnimationMath.easeInOutSine(f8);
         f = f3 < 0.5F ? AnimationMath.lerp(f, 0.4F, f9) : AnimationMath.lerp(0.4F, f, f9);
         n = f3 < 0.5F ? AnimationMath.lerpColor(n, -65476, f9) : AnimationMath.lerpColor(-65476, n, f9);
      }

      float f3 = (float)Math.sin(System.currentTimeMillis() / 666.6666666666666) * 360.0F;
      this.modelRenderQueue
         .process7(
            this.lazyMeshModel.getMeshModel(),
            new SpatialTransform(d, d2 + f7, d3, f, f, f, f4, f5, f3),
            AnimationMath.applyOpacity(n, f2, 0.5F),
            this.modelRenderOptions
         );
   }

   private void process2(Entity entity2, float f) {
      TargetChange<Entity> targetChange = this.targetTransition.updateTarget(entity2);
      if (targetChange.changed()) {
         MarkerTargetEspRenderer.TargetMarkerState oldState = this.lastState;
         MarkerTargetEspRenderer.TargetMarkerState newState = this.captureState(this.targetTransition.current(), f);
         if (oldState != null && newState != null) {
            this.previousState.remember(oldState);
         }
      }
   }

   private int process3(int n, int n2, long l) {
      float f = 0.5F + 0.5F * AnimationMath.sin((float)l * 0.004F);
      return AnimationMath.lerpColor(n, n2, f * 0.45F);
   }

   private MarkerTargetEspRenderer.TargetMarkerState captureState(Entity entity2, float f) {
      return entity2 != null && entity2.isAlive()
         ? new MarkerTargetEspRenderer.TargetMarkerState(this.interpolatedPosition(entity2, f), entity2.getHeight())
         : null;
   }

   private MarkerTargetEspRenderer.TargetMarkerState interpolatePreviousState(MarkerTargetEspRenderer.TargetMarkerState state) {
      if (!this.previousState.hasValue()) {
         return state;
      } else {
         float f = this.previousState.progress(420L);
         if (f >= 1.0F) {
            this.previousState.clear();
            return state;
         } else {
            float f2 = AnimationMath.easeOut(f, 1.16F);
            MarkerTargetEspRenderer.TargetMarkerState previous = this.previousState.get();
            Vec3d start = previous.position();
            Vec3d end = state.position();
            return new MarkerTargetEspRenderer.TargetMarkerState(
               new Vec3d(AnimationMath.lerp(start.x, end.x, f2), AnimationMath.lerp(start.y, end.y, f2), AnimationMath.lerp(start.z, end.z, f2)),
               AnimationMath.lerp((float)previous.height(), (float)state.height(), f2)
            );
         }
      }
   }

   private float getMarkerScale() {
      if (this.targetTransition.phase() == TransitionPhase.IDLE) {
         return 0.25F;
      }

      float f = this.targetTransition.progress(300L);
      return this.targetTransition.phase() == TransitionPhase.APPEARING
         ? AnimationMath.lerp(0.42F, 0.25F, AnimationMath.easeOut(f, 1.28F))
         : AnimationMath.lerp(0.25F, 0.42F, AnimationMath.smoothStep(f));
   }

   private float getTransitionOpacity() {
      if (this.targetTransition.phase() == TransitionPhase.IDLE) {
         return 1.0F;
      }

      float f = this.targetTransition.progress(300L);
      if (this.targetTransition.phase() == TransitionPhase.APPEARING) {
         if (f >= 1.0F) {
            this.targetTransition.finishAppearance();
         }

         return AnimationMath.easeInOutSine(f);
      } else if (f >= 1.0F) {
         this.update2();
         return 0.0F;
      } else {
         return 1.0F - AnimationMath.smoothStep(f);
      }
   }

   private record TargetMarkerState(Vec3d position, double height) {
   }
}
