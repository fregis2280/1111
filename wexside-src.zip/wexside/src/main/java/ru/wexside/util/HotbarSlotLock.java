package ru.wexside.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import ru.wexside.event.ClientTickEvent;
import ru.wexside.event.EventBus;
import ru.wexside.event.IncomingPacketEvent;

public class HotbarSlotLock {
   private long longType;
   private int slot = -1;

   public HotbarSlotLock(EventBus eventBus) {
      eventBus.subscribe(ClientTickEvent.class, ignored -> this.update2());
      eventBus.subscribe(IncomingPacketEvent.class, this::onIncomingPacket);
   }

   public boolean isActive() {
      return this.slot != -1;
   }

   public void process(int n, long l) {
      if (n >= 0 && n <= 8) {
         this.slot = n;
         this.longType = System.currentTimeMillis() + Math.max(50L, l);
      }
   }

   private void onIncomingPacket(IncomingPacketEvent gameEvent5) {
      if (this.slot != -1) {
         if (gameEvent5.getPacket() instanceof UpdateSelectedSlotS2CPacket) {
            ClientPlayerEntity player2 = MinecraftClient.getInstance().player;
            if (player2 != null) {
               PlayerInventory inv = player2.getInventory();
               if (inv.getSelectedSlot() != this.slot) {
                  inv.setSelectedSlot(this.slot);
               }
            }
         }
      }
   }

   public void update() {
      this.slot = -1;
      this.longType = 0L;
   }

   private void update2() {
      if (this.slot != -1) {
         if (System.currentTimeMillis() >= this.longType) {
            this.update();
         }
      }
   }
}
