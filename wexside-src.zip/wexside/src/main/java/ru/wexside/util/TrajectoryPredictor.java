package ru.wexside.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.thrown.ExperienceBottleEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.EggItem;
import net.minecraft.item.EnderPearlItem;
import net.minecraft.item.ExperienceBottleItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.item.SnowballItem;
import net.minecraft.item.ThrowablePotionItem;
import net.minecraft.item.TridentItem;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import ru.wexside.prediction.ProjectileImpact;
import ru.wexside.prediction.ProjectileMotionStep;
import ru.wexside.prediction.TrajectoryPrediction;
import ru.wexside.render.RenderCamera;

public final class TrajectoryPredictor {
   private final MinecraftClient mc = MinecraftClient.getInstance();
   static final int slot = 12;
   static final float value3 = 10.0F;
   private Vec3d vec = Vec3d.ZERO;
   static final int slot2 = 200;
   static final double value4 = 0.3;
   static final double value5 = 0.3;
   static final double value6 = 0.6;
   static final float value7 = (float) (Math.PI / 180.0);

   public List<TrajectoryPrediction> process(LivingEntity screenHandler, ItemStack stack, float f) {
      if (stack != null && !stack.isEmpty()) {
         if (ProjectileType.fromItem(stack.getItem()) == null) {
            return List.of();
         }

         this.updateShooterVelocity(screenHandler);
         boolean bl = this.process22(stack);
         float[] fArray;
         if (bl) {
            float[] fArray2 = new float[]{0.0F, -10.0F, 0.0F};
            fArray = fArray2;
            fArray2[2] = 10.0F;
         } else {
            float[] fArray3;
            fArray = fArray3 = new float[1];
            fArray3[0] = 0.0F;
         }

         float[] fArray4 = fArray;
         ArrayList<TrajectoryPrediction> arrayList = new ArrayList<>(fArray4.length);

         for (float f2 : fArray4) {
            TrajectoryPrediction trajectoryPrediction = this.process9(screenHandler, stack, f, f2);
            if (trajectoryPrediction != null) {
               arrayList.add(trajectoryPrediction);
            }
         }

         return arrayList;
      } else {
         return List.of();
      }
   }

   public TrajectoryPrediction process2(Entity entity2, float f) {
      if (this.mc.world == null || entity2 == null) {
         return null;
      } else if (entity2 instanceof ItemEntity iIIIlIIIII2) {
         return this.process3(iIIIlIIIII2, f);
      } else {
         ProjectileType iiIlilIilI2 = ProjectileType.fromEntity(entity2);
         if (iiIlilIilI2 == null) {
            return null;
         }

         Vec3d vec2 = new Vec3d(entity2.getX(), entity2.getY(), entity2.getZ());
         Vec3d vec3 = entity2.getVelocity();
         boolean bl = this.process7(iiIlilIilI2);
         return this.process11(
            entity2,
            vec2,
            vec3,
            FluidHandling.NONE,
            iiIlilIilI2,
            (vec4, vec5) -> {
               boolean bl2 = this.process24(vec4);
               return bl
                  ? vec5.subtract(0.0, -this.process6(entity2), 0.0).multiply(this.process19(entity2, bl2))
                  : vec5.multiply(this.process19(entity2, bl2)).subtract(0.0, -this.process6(entity2), 0.0);
            },
            bl
         );
      }
   }

   public TrajectoryPrediction process3(ItemEntity iIIIlIIIII2, float f) {
      return this.mc.world != null && iIIIlIIIII2 != null
         ? this.process11(
            iIIIlIIIII2,
            new Vec3d(iIIIlIIIII2.getX(), iIIIlIIIII2.getY(), iIIIlIIIII2.getZ()),
            iIIIlIIIII2.getVelocity(),
            FluidHandling.NONE,
            ProjectileType.ITEM,
            (vec4, vec5) -> vec5.multiply(this.process19(iIIIlIIIII2, this.process24(vec4))).subtract(0.0, -this.process6(iIIIlIIIII2), 0.0),
            false
         )
         : null;
   }

   public Vec3d process4(LivingEntity screenHandler, float f) {
      return screenHandler == this.mc.player && this.mc.options.getPerspective().isFirstPerson() && RenderCamera.position() != null
         ? RenderCamera.position()
         : screenHandler.getCameraPosVec(f);
   }

   private Vec3d process5(LivingEntity screenHandler, Item iiIilIIilI2, float f, float f2) {
      Vec3d vec4 = this.process8(screenHandler.getPitch(f), screenHandler.getYaw(f), this.process17(iiIilIIilI2));
      return iiIilIIilI2 instanceof CrossbowItem && f2 != 0.0F ? this.process25(vec4, screenHandler.getRotationVec(f), f2).normalize() : vec4;
   }

   private double process6(Entity entity2) {
      if (entity2 instanceof ExperienceBottleEntity) {
         return 0.07;
      } else {
         ProjectileType iiIlilIilI2 = ProjectileType.fromEntity(entity2);
         if (iiIlilIilI2 == ProjectileType.TRIDENT || iiIlilIilI2 == ProjectileType.ARROW || iiIlilIilI2 == ProjectileType.POTION) {
            return 0.05;
         } else if (iiIlilIilI2 == ProjectileType.PEARL) {
            return 0.03;
         } else {
            return iiIlilIilI2 == ProjectileType.ITEM ? 0.04 : 0.03;
         }
      }
   }

   private boolean process7(ProjectileType iiIlilIilI2) {
      return iiIlilIilI2 == ProjectileType.POTION || iiIlilIilI2 == ProjectileType.PEARL;
   }

   private Vec3d process8(float f, float f2, float f3) {
      float f4 = f * (float) (Math.PI / 180.0);
      float f5 = f2 * (float) (Math.PI / 180.0);
      float f6 = (f + f3) * (float) (Math.PI / 180.0);
      double d = -Math.sin(f5) * Math.cos(f4);
      double d2 = -Math.sin(f6);
      double d3 = Math.cos(f5) * Math.cos(f4);
      return new Vec3d(d, d2, d3).normalize();
   }

   private TrajectoryPrediction process9(LivingEntity screenHandler, ItemStack stack, float f, float f2) {
      if (this.mc.world == null) {
         return null;
      }

      Item iiIilIIilI2 = stack.getItem();
      float f3 = this.process18(screenHandler, stack);
      if (f3 <= 0.0F) {
         return null;
      }

      Vec3d vec2 = this.process4(screenHandler, f);
      Vec3d vec3 = this.process5(screenHandler, iiIilIIilI2, f, f2);
      Vec3d vec6 = this.process21(screenHandler, iiIilIIilI2, f, f2);
      Vec3d vec7 = this.process23(iiIilIIilI2);
      Vec3d vec8 = vec3.multiply(f3).multiply(vec7);
      Vec3d vec9 = vec6.multiply(f3);
      ProjectileMotionStep ilIIlIIIlI2 = (vec4, vec5) -> {
         boolean inFluid = this.process24(vec4);
         return vec5.multiply(this.process13(iiIilIIilI2, inFluid)).subtract(0.0, -this.process20(iiIilIIilI2), 0.0);
      };
      ProjectileType iiIlilIilI2 = ProjectileType.fromItem(iiIilIIilI2);
      TrajectoryPrediction trajectoryPrediction = this.process11(screenHandler, vec2, vec8, FluidHandling.NONE, iiIlilIilI2, ilIIlIIIlI2, false);
      if (trajectoryPrediction == null) {
         return null;
      }

      boolean bl = this.process17(iiIilIIilI2) != 0.0F || vec7.lengthSquared() >= 1.0E-6;
      if (!bl) {
         return trajectoryPrediction;
      }

      TrajectoryPrediction trajectoryPrediction2 = this.process11(screenHandler, vec2, vec9, FluidHandling.NONE, iiIlilIilI2, ilIIlIIIlI2, false);
      return this.process12(trajectoryPrediction, trajectoryPrediction2);
   }

   private static double process10(double d) {
      d = Math.max(0.0, Math.min(1.0, d));
      return d * d * (3.0 - 2.0 * d);
   }

   private TrajectoryPrediction process11(
      Entity entity2, Vec3d vec4, Vec3d vec5, FluidHandling fluidHandling, ProjectileType iiIlilIilI2, ProjectileMotionStep motionStep, boolean applyBeforeMove
   ) {
      if (this.mc.world == null) {
         return null;
      }

      ArrayList<Vec3d> arrayList = new ArrayList<>(201);
      arrayList.add(vec4);
      Vec3d vec2 = vec4;
      Vec3d vec3 = vec5;

      for (int i = 0; i < 200; i++) {
         if (applyBeforeMove) {
            vec3 = motionStep.apply(vec2, vec3);
         }

         Vec3d vec7 = vec2.add(vec3);
         BlockHitResult hit2 = this.mc.world.raycast(new RaycastContext(vec2, vec7, ShapeType.COLLIDER, fluidHandling, entity2));
         EntityHitResult iIIIllIilI2 = this.process14(vec2, vec7, entity2, iiIlilIilI2);
         double d = hit2.getType() == Type.BLOCK ? vec2.squaredDistanceTo(hit2.getPos()) : Double.MAX_VALUE;
         double d2 = iIIIllIilI2 != null ? vec2.squaredDistanceTo(iIIIllIilI2.getPos()) : Double.MAX_VALUE;
         Vec3d vec6 = vec3.lengthSquared() > 1.0E-8 ? vec3.normalize() : Vec3d.ZERO;
         if (iIIIllIilI2 != null && d2 <= d) {
            Vec3d vec9 = iIIIllIilI2.getPos();
            arrayList.add(vec9);
            Direction process17 = vec6.lengthSquared() > 1.0E-8 ? Direction.getFacing(vec6.x, vec6.y, vec6.z).getOpposite() : Direction.UP;
            return new TrajectoryPrediction(arrayList, new ProjectileImpact(vec9, vec6, process17, iIIIllIilI2.getEntity()), i);
         }

         if (hit2.getType() == Type.BLOCK) {
            Vec3d vec10 = hit2.getPos();
            arrayList.add(vec10);
            return new TrajectoryPrediction(arrayList, new ProjectileImpact(vec10, vec6, hit2.getSide(), null), i);
         }

         vec2 = vec7;
         arrayList.add(vec2);
         if (!applyBeforeMove) {
            vec3 = motionStep.apply(vec2, vec3);
         }

         if (vec2.y < this.mc.world.getBottomY()) {
            break;
         }
      }

      return new TrajectoryPrediction(arrayList, null, Math.max(0, arrayList.size() - 1));
   }

   private TrajectoryPrediction process12(TrajectoryPrediction trajectoryPrediction, TrajectoryPrediction trajectoryPrediction2) {
      if (trajectoryPrediction2 == null) {
         return trajectoryPrediction;
      }

      List<Vec3d> list = trajectoryPrediction.points();
      List<Vec3d> list2 = trajectoryPrediction2.points();
      int n = Math.min(12, Math.min(list.size(), list2.size()));
      ArrayList<Vec3d> arrayList = new ArrayList<>(list.size());

      for (int i = 0; i < list.size(); i++) {
         if (i < n) {
            double d = process10(i / 12.0);
            Vec3d vec4 = list2.get(i);
            Vec3d vec5 = list.get(i);
            arrayList.add(new Vec3d(vec4.x + (vec5.x - vec4.x) * d, vec4.y + (vec5.y - vec4.y) * d, vec4.z + (vec5.z - vec4.z) * d));
         } else {
            arrayList.add(list.get(i));
         }
      }

      return new TrajectoryPrediction(arrayList, trajectoryPrediction.impact(), trajectoryPrediction.flightTicks());
   }

   private double process13(Item iiIilIIilI2, boolean bl) {
      if (iiIilIIilI2 instanceof TridentItem) {
         return 0.99;
      } else if (iiIilIIilI2 instanceof EnderPearlItem || iiIilIIilI2 instanceof SnowballItem || iiIilIIilI2 instanceof EggItem) {
         return bl ? 0.8 : 0.99;
      } else if (iiIilIIilI2 instanceof BowItem || iiIilIIilI2 instanceof CrossbowItem) {
         return bl ? 0.6 : 0.99;
      } else if (!this.process16(iiIilIIilI2) && !(iiIilIIilI2 instanceof ExperienceBottleItem)) {
         return 0.98;
      } else {
         return bl ? 0.8 : 0.99;
      }
   }

   private EntityHitResult process14(Vec3d vec4, Vec3d vec5, Entity entity2, ProjectileType iiIlilIilI2) {
      if (this.mc.world == null) {
         return null;
      }

      Box box = new Box(vec4, vec5).expand(0.3);
      Entity iIiiiilIiI2 = null;
      Vec3d vec2 = null;
      double d = Double.MAX_VALUE;

      for (Entity candidate : this.mc.world.getOtherEntities(entity2, box)) {
         double d2;
         Optional intersection;
         ProjectileEntity projectile;
         if (candidate.isAlive()
            && (!(entity2 instanceof ProjectileEntity) || (projectile = (ProjectileEntity)entity2).getOwner() != candidate)
            && (iiIlilIilI2 != ProjectileType.POTION || ProjectileType.fromEntity(candidate) != ProjectileType.POTION)
            && !(intersection = candidate.getBoundingBox().expand(0.3).raycast(vec4, vec5)).isEmpty()
            && (d2 = vec4.squaredDistanceTo((Vec3d)intersection.get())) < d) {
            d = d2;
            iIiiiilIiI2 = candidate;
            vec2 = (Vec3d)intersection.get();
         }
      }

      return iIiiiilIiI2 != null && vec2 != null ? new EntityHitResult(iIiiiilIiI2, vec2) : null;
   }

   public Vec3d process15(Entity entity2, float f) {
      return new Vec3d(
         MathHelper.lerp(f, entity2.lastX, entity2.getX()),
         MathHelper.lerp(f, entity2.lastY, entity2.getY()),
         MathHelper.lerp(f, entity2.lastZ, entity2.getZ())
      );
   }

   private boolean process16(Item iiIilIIilI2) {
      return iiIilIIilI2 instanceof ThrowablePotionItem || iiIilIIilI2 instanceof PotionItem;
   }

   private float process17(Item iiIilIIilI2) {
      return !(iiIilIIilI2 instanceof ExperienceBottleItem) && !this.process16(iiIilIIilI2) ? 0.0F : -20.0F;
   }

   private float process18(LivingEntity screenHandler, ItemStack stack) {
      Item iiIilIIilI2 = stack.getItem();
      if (iiIilIIilI2 instanceof ExperienceBottleItem) {
         return 0.7F;
      } else if (this.process16(iiIilIIilI2)) {
         return 0.5F;
      } else if (iiIilIIilI2 instanceof EnderPearlItem || iiIilIIilI2 instanceof SnowballItem || iiIilIIilI2 instanceof EggItem) {
         return 1.5F;
      } else if (iiIilIIilI2 instanceof BowItem) {
         int n = screenHandler.isUsingItem() ? stack.getMaxUseTime(screenHandler) - screenHandler.getItemUseTimeLeft() : 20;
         return BowItem.getPullProgress(n) * 3.0F;
      } else if (iiIilIIilI2 instanceof CrossbowItem) {
         return 3.15F;
      } else {
         return iiIilIIilI2 instanceof TridentItem ? 2.5F + Math.max(0.0F, EnchantmentHelper.getTridentSpinAttackStrength(stack, screenHandler)) * 0.5F : 1.5F;
      }
   }

   private double process19(Entity entity2, boolean bl) {
      ProjectileType iiIlilIilI2 = ProjectileType.fromEntity(entity2);
      if (iiIlilIilI2 == ProjectileType.TRIDENT) {
         return 0.99;
      } else if (iiIlilIilI2 == ProjectileType.PEARL) {
         return bl ? 0.8 : 0.99;
      } else if (iiIlilIilI2 == ProjectileType.ARROW) {
         return bl ? 0.6 : 0.99;
      } else if (iiIlilIilI2 == ProjectileType.POTION) {
         return bl ? 0.8 : 0.99;
      } else {
         return iiIlilIilI2 == ProjectileType.ITEM ? 0.98 : 0.99;
      }
   }

   private double process20(Item iiIilIIilI2) {
      if (iiIilIIilI2 instanceof TridentItem) {
         return 0.05;
      } else if (iiIilIIilI2 instanceof EnderPearlItem || iiIilIIilI2 instanceof SnowballItem || iiIilIIilI2 instanceof EggItem) {
         return 0.03;
      } else if (iiIilIIilI2 instanceof BowItem || iiIilIIilI2 instanceof CrossbowItem) {
         return 0.05;
      } else if (iiIilIIilI2 instanceof ExperienceBottleItem) {
         return 0.07;
      } else {
         return this.process16(iiIilIIilI2) ? 0.05 : 0.04;
      }
   }

   private Vec3d process21(LivingEntity screenHandler, Item iiIilIIilI2, float f, float f2) {
      Vec3d vec4 = this.process8(screenHandler.getPitch(f), screenHandler.getYaw(f), 0.0F);
      return iiIilIIilI2 instanceof CrossbowItem && f2 != 0.0F ? this.process25(vec4, screenHandler.getRotationVec(f), f2).normalize() : vec4;
   }

   private boolean process22(ItemStack stack) {
      if (!(stack.getItem() instanceof CrossbowItem)) {
         return false;
      }

      ItemEnchantmentsComponent itemEnchantmentsComponent = EnchantmentHelper.getEnchantments(stack);

      for (RegistryEntry enchantment : itemEnchantmentsComponent.getEnchantments()) {
         if (enchantment.matchesKey(Enchantments.MULTISHOT) && itemEnchantmentsComponent.getLevel(enchantment) > 0) {
            return true;
         }
      }

      return false;
   }

   private Vec3d process23(Item iiIilIIilI2) {
      if (ProjectileType.fromItem(iiIilIIilI2) == ProjectileType.CROSSBOW) {
         return Vec3d.ZERO;
      }

      Vec3d vec4 = this.vec;
      double d = vec4.lengthSquared();
      if (d > 0.36) {
         vec4 = vec4.multiply(0.6 / Math.sqrt(d));
      }

      return vec4;
   }

   private boolean process24(Vec3d vec4) {
      return this.mc.world == null ? false : !this.mc.world.getFluidState(BlockPos.ofFloored(vec4)).isEmpty();
   }

   private void updateShooterVelocity(LivingEntity screenHandler) {
      double d = screenHandler.getX() - screenHandler.lastX;
      double d2 = screenHandler.isOnGround() ? 0.0 : Math.min(0.0, screenHandler.getY() - screenHandler.lastY);
      double d3 = screenHandler.getZ() - screenHandler.lastZ;
      this.vec = new Vec3d(this.vec.x + (d - this.vec.x) * 0.3, this.vec.y + (d2 - this.vec.y) * 0.3, this.vec.z + (d3 - this.vec.z) * 0.3);
   }

   private Vec3d process25(Vec3d vec4, Vec3d vec5, float f) {
      if (vec5.lengthSquared() < 1.0E-8) {
         return vec4;
      }

      Vec3d vec2 = vec5.normalize();
      double d = Math.toRadians(f);
      double d2 = Math.cos(d);
      double d3 = Math.sin(d);
      return vec4.multiply(d2).add(vec2.crossProduct(vec4).multiply(d3)).add(vec2.multiply(vec2.dotProduct(vec4) * (1.0 - d2)));
   }
}
