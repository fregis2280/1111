package ru.wexside.util;

import java.util.function.BooleanSupplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import ru.wexside.WexSideClient;
import ru.wexside.misc.FadeAnimation;
import ru.wexside.misc.HudElementConfig;
import ru.wexside.misc.PreparedLayer;
import ru.wexside.misc.TextureHandle;
import ru.wexside.misc.ThemeColors;
import ru.wexside.misc.ThemeManager;
import ru.wexside.ui.HudElementLayout;

public abstract class AbstractHudElement {
   private static final float OPAQUE_THRESHOLD = 0.98F;
   private static final float HIDDEN_THRESHOLD = 0.02F;
   private static final float MAXIMUM_BLUR_RADIUS = 16.0F;
   private static final float LAYER_PADDING = 32.0F;
   protected final String name;
   protected final HudElementConfig hudElementConfig;
   protected final FadeAnimation fadeAnimation = new FadeAnimation(15.0F);
   protected final HudElementLayout layout;

   protected AbstractHudElement(String name, BooleanSupplier visibility) {
      this.name = name;
      this.layout = WexSideClient.getHudLayoutManager().register(name).visibleWhen(visibility);
      this.hudElementConfig = new HudElementConfig(name);
      WexSideClient.getInstance().getConfigRegistry().register(this.hudElementConfig);
      WexSideClient.getInventoryHudRegistry().register(this);
      this.configureDefaultAnchor(name);
   }

   public HudElementConfig getHudElementConfig() {
      return this.hudElementConfig;
   }

   public final void renderFrame() {
      boolean visible = this.layout.isVisible() && (this.isContentVisible() || this.isEditorScreen());
      this.fadeAnimation.updateTarget(visible);
      float alpha = this.resolveVisibilityAlpha(visible);
      if (!(alpha <= 0.0F)) {
         this.hudElementConfig.updateScaleAnimation();
         this.layout.setScale(this.hudElementConfig.getScale());
         this.updateLayout();
         this.layout.setSize(this.getWidth(), this.getHeight());
         float scale = this.layout.getScale();
         float width = this.layout.getWidth();
         float height = this.layout.getHeight();
         GuiDrawApi renderer = WexSideClient.getHudRenderer();
         float pixelScale = 2.0F;
         float x = Math.round(this.layout.getX() * pixelScale) / pixelScale;
         float y = Math.round(this.layout.getY() * pixelScale) / pixelScale;
         Matrix4f matrix = new Matrix4f().scale(pixelScale).translate(x, y, 0.0F);
         if (alpha >= 1.0F) {
            renderer.begin();
            this.renderContent(renderer, matrix, 0.0F, 0.0F, width, height, scale);
            renderer.end();
         } else {
            renderer.begin();
            PreparedLayer layer = renderer.prepareLayer(matrix, 0.0F, 0.0F, width, height, 32.0F);
            Vector4f transformedBottomLeft = matrix.transform(new Vector4f(-32.0F, height + 32.0F, 0.0F, 1.0F));
            float textureBottomPadding = layer.getTexture().getHeight() * (1.0F - layer.maxV());
            float layerX = renderer.getLayerOffsetX() + transformedBottomLeft.x;
            float layerY = renderer.getLayerOffsetY() + (renderer.getFramebufferHeight() - transformedBottomLeft.y) - textureBottomPadding;
            renderer.beginLayerFrame(layer.getTexture(), layerX, layerY);
            Matrix4f contentMatrix = new Matrix4f(layer.getContentMatrix()).translate(layer.contentX(), layer.contentY(), 0.0F);
            this.renderContent(renderer, contentMatrix, 0.0F, 0.0F, width, height, scale);
            renderer.endLayerFrame();
            TextureHandle texture = renderer.blurTexture(layer.getTexture(), 16.0F * (1.0F - alpha));
            int color = ColorUtils.withAlpha(-1, 255.0F * alpha);
            renderer.drawLayerTexture(
               matrix, texture, layer.drawX(), layer.drawY(), layer.drawWidth(), layer.drawHeight(), 0.0F, 1.0F, layer.maxU(), 1.0F - layer.maxV(), color
            );
            renderer.end();
         }
      }
   }

   protected abstract float getWidth();

   protected boolean isEditorScreen() {
      return MinecraftClient.getInstance().currentScreen instanceof ChatScreen || MinecraftClient.getInstance().currentScreen instanceof InventoryScreen;
   }

   protected void updateLayout() {
   }

   protected abstract void renderContent(GuiDrawApi var1, Matrix4f var2, float var3, float var4, float var5, float var6, float var7);

   protected final void renderPanelSurface(GuiDrawApi renderer, Matrix4f matrix, float x, float y, float width, float height, float radius, float scale) {
      float scaledRadius = radius * scale;
      if (ThemeManager.getThemeManager().isHudBlurEnabled()) {
         renderer.drawBlurredRoundedRectangle(matrix, x, y, width, height, scaledRadius);
      }

      renderer.drawRoundedRectangle(matrix, x, y, width, height, scaledRadius, ThemeColors.hudBackground());
      renderer.drawRoundedOutline(matrix, x, y, width, height, scaledRadius, scale, ThemeColors.withHoverOverlay(ThemeColors.notificationOutline()));
   }

   public String getName() {
      return this.name;
   }

   protected abstract float getHeight();

   private void configureDefaultAnchor(String name) {
      float anchorX;

      float anchorY = switch (name) {
         case "Watermark" -> {
            anchorX = 0.0F;
            yield 0.0F;
         }
         case "Keybinds" -> {
            anchorX = 1.0F;
            yield 0.0F;
         }
         case "Cooldowns" -> {
            anchorX = 0.5F;
            yield 0.02F;
         }
         case "Effects" -> {
            anchorX = 1.0F;
            yield 0.2F;
         }
         case "Schedules" -> {
            anchorX = 1.0F;
            yield 0.55F;
         }
         case "Staff List" -> {
            anchorX = 0.0F;
            yield 0.38F;
         }
         case "Target HUD" -> {
            anchorX = 0.5F;
            yield 0.28F;
         }
         case "Armor HUD" -> {
            anchorX = 0.5F;
            yield 0.82F;
         }
         case "Inventory HUD" -> {
            anchorX = 0.0F;
            yield 1.0F;
         }
         case "Server Helper" -> {
            anchorX = 0.0F;
            yield 0.66F;
         }
         case "Totem Counter" -> {
            anchorX = 0.5F;
            yield 0.78F;
         }
         default -> {
            anchorX = 0.5F;
            yield 0.5F;
         }
      };
      this.layout.setAnchor(anchorX, anchorY);
   }

   protected boolean isContentVisible() {
      return true;
   }

   protected float centerVertically(float y, float scale, float contentHeight) {
      return this.centerWithinHeight(y, scale, contentHeight, this.getHeight());
   }

   public float getMaximumBlurRadius() {
      return 16.0F;
   }

   public FadeAnimation getFadeAnimation() {
      return this.fadeAnimation;
   }

   private float resolveVisibilityAlpha(boolean visible) {
      float progress = this.fadeAnimation.getProgress();
      if (visible) {
         if (progress < 0.98F) {
            return progress;
         }

         this.fadeAnimation.setProgress(1.0F);
         return 1.0F;
      } else {
         if (progress > 0.02F) {
            return progress;
         }

         this.fadeAnimation.setProgress(0.0F);
         return 0.0F;
      }
   }

   protected float centerWithinHeight(float y, float scale, float contentHeight, float containerHeight) {
      return y + (containerHeight - contentHeight) / 2.0F * scale;
   }

   public HudElementLayout getLayout() {
      return this.layout;
   }

   public float getLayerPadding() {
      return 32.0F;
   }
}
