package ru.wexside.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import ru.wexside.market.AuctionPrice;
import ru.wexside.market.AuctionPriceParser;
import ru.wexside.misc.AuctionHighlightSettings;
import ru.wexside.misc.SlotHighlight;
import ru.wexside.misc.SlotHighlightProvider;

public final class AuctionSlotHighlighter implements SlotHighlightProvider {
   private final Supplier<AuctionHighlightSettings> configSupplier;
   private final AuctionPriceParser priceParser = new AuctionPriceParser();
   private final BooleanSupplier enabledSupplier;

   public AuctionSlotHighlighter(BooleanSupplier enabledSupplier, Supplier<AuctionHighlightSettings> configSupplier) {
      this.enabledSupplier = enabledSupplier;
      this.configSupplier = configSupplier;
   }

   private static int withAlpha(int rgb, int alpha) {
      return alpha << 24 | rgb & 16777215;
   }

   private static int pulseAlpha(int speed) {
      double period = Math.max(1, speed);
      float wave = 0.5F + 0.5F * (float)Math.sin(System.currentTimeMillis() / 1000.0 * period * Math.PI);
      return Math.round(50.0F + 180.0F * wave);
   }

   @Override
   public List<SlotHighlight> process4(HandledScreen<?> screen) {
      if (!this.enabledSupplier.getAsBoolean()) {
         return List.of();
      }

      MinecraftClient client = MinecraftClient.getInstance();
      ScreenHandler handler = screen.getScreenHandler();
      if (handler != null && ContainerScreenHelper.isAuctionContainer(handler, screen)) {
         AuctionHighlightSettings config = this.configSupplier.get();
         ArrayList<AuctionSlotHighlighter.PricedSlot> pricedSlots = new ArrayList<>();

         for (int i = 0; i < handler.slots.size(); i++) {
            Slot slot = handler.slots.get(i);
            ItemStack stack = slot.getStack();
            AuctionPrice priceInfo;
            if (!stack.isEmpty()
               && (!config.enabled3 || stack.getDamage() <= 0)
               && (priceInfo = this.priceParser.parse(stack, client)) != null
               && (!config.enabled || config.slot2 < 0 || priceInfo.unitPrice() <= config.slot2)) {
               pricedSlots.add(new AuctionSlotHighlighter.PricedSlot(i, priceInfo.totalPrice()));
            }
         }

         if (pricedSlots.isEmpty()) {
            return List.of();
         }

         pricedSlots.sort(Comparator.comparingInt(AuctionSlotHighlighter.PricedSlot::price));
         int count = Math.min(Math.max(1, config.slot4), pricedSlots.size());
         int color = config.enabled2 ? withAlpha(config.slot, pulseAlpha(config.slot3)) : config.slot;
         ArrayList<SlotHighlight> highlights = new ArrayList<>(count);

         for (int i = 0; i < count; i++) {
            AuctionSlotHighlighter.PricedSlot pricedSlot = pricedSlots.get(i);
            highlights.add(new SlotHighlight(pricedSlot.slotIndex(), color));
         }

         return highlights;
      } else {
         return List.of();
      }
   }

   private record PricedSlot(int slotIndex, int price) {
   }
}
