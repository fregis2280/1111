package ru.wexside.util;

public final class RecentColorPalette {
   private final int[] colors;

   public RecentColorPalette(int... colors) {
      int[] nArray;
      if (colors != null && colors.length != 0) {
         nArray = (int[])colors.clone();
      } else {
         int[] nArray2 = new int[1];
         nArray = nArray2;
         nArray2[0] = -1;
      }

      this.colors = nArray;
   }

   public int[] getColors() {
      return this.colors;
   }

   public int size() {
      return this.colors.length;
   }

   public int getColor(int index) {
      return this.colors[Math.clamp(index, 0, this.colors.length - 1)];
   }

   public void addColor(int color) {
      for (int existing : this.colors) {
         if (existing == color) {
            return;
         }
      }

      System.arraycopy(this.colors, 0, this.colors, 1, this.colors.length - 1);
      this.colors[0] = color;
   }

   public RecentColorPalette copy() {
      return new RecentColorPalette(this.colors);
   }
}
