package ru.wexside.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.wexside.event.EventBus;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.ChamsRenderer;
import ru.wexside.misc.GlowEspRenderer;
import ru.wexside.misc.WorldBoxSettings;
import ru.wexside.model.esp.EspTargetClassifier;
import ru.wexside.model.esp.EspTargetType;
import ru.wexside.render.BoxEspEntry;
import ru.wexside.render.BoxEspRenderer;
import ru.wexside.render.RenderCamera;
import ru.wexside.render.RenderProjection;
import ru.wexside.render.WorldSkeletonRenderer;

public final class EspRenderCoordinator {
   private final WorldSkeletonRenderer worldSkeletonRenderer;
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private final ChamsRenderer chamsRenderer;
   private final NameplateRenderer nameplateRenderer;
   private final GlowEspRenderer glowEspRenderer;
   private final EspFeatureRegistry espFeatures;
   private final ServerItemCooldownOverlay serverItemCooldownOverlay;

   public EspRenderCoordinator(EventBus eventBus, EspFeatureRegistry espFeatures) {
      this.espFeatures = espFeatures;
      eventBus.subscribe(WorldRenderEvent.class, this::renderWorldBoxes);
      this.nameplateRenderer = new NameplateRenderer(eventBus, espFeatures);
      this.serverItemCooldownOverlay = new ServerItemCooldownOverlay(eventBus, espFeatures);
      this.chamsRenderer = new ChamsRenderer(eventBus, espFeatures);
      this.glowEspRenderer = new GlowEspRenderer(eventBus, espFeatures);
      this.worldSkeletonRenderer = new WorldSkeletonRenderer(eventBus, espFeatures);
   }

   private void renderWorldBoxes(WorldRenderEvent event) {
      if (this.espFeatures.hasEnabledWorldBox()) {
         ClientPlayerEntity player2 = this.mc.player;
         ClientWorld world2 = this.mc.world;
         Vec3d vec = RenderCamera.position();
         if (player2 != null && world2 != null && vec != null) {
            Frustum frustum2 = RenderProjection.frustum();
            VertexConsumerProvider consumers = event.getConsumers();
            if (consumers != null) {
               float tickProgress = event.getFloatType();
               ArrayList<BoxEspEntry> entries = new ArrayList<>();

               for (Entity entity : world2.getEntities()) {
                  WorldBoxSettings settings;
                  EspTargetType targetType;
                  if (entity.isAlive()
                     && (targetType = EspTargetClassifier.targetType(entity, player2)) != null
                     && (settings = this.espFeatures.getWorldBoxSettings(targetType, EspTargetClassifier.relation(entity))) != null
                     && settings.isEnabled()
                     && RenderProjection.isVisible(entity, frustum2)) {
                     Box box = this.getExpandedBoundingBox(entity, tickProgress, this.getExpansion(settings.getScale()));
                     if (this.isValidBox(box)) {
                        entries.add(
                           new BoxEspEntry(
                              box, settings.getColor(), settings.isDottedStyle(), settings.isDepthTestEnabled() || targetType == EspTargetType.ITEMS
                           )
                        );
                     }
                  }
               }

               if (!entries.isEmpty()) {
                  Matrix4f matrix = new Matrix4f(event.getMatrices().peek().getPositionMatrix());
                  long animationTime = System.currentTimeMillis();
                  this.renderEntries(entries, true, matrix, vec, animationTime, consumers);
                  this.renderEntries(entries, false, matrix, vec, animationTime, consumers);
               }
            }
         }
      }
   }

   private void renderEntries(
      List<BoxEspEntry> entries, boolean depthTest, Matrix4f matrix, Vec3d cameraPosition, long animationTime, VertexConsumerProvider consumers
   ) {
      if (!entries.stream().noneMatch(entry -> entry.depthTest() == depthTest)) {
         RenderLayer outlineLayer = depthTest ? RenderLayers.linesTranslucent() : RenderLayers.lines();
         VertexConsumer outlineBuffer = consumers.getBuffer(outlineLayer);

         for (BoxEspEntry entry3 : entries) {
            if (entry3.depthTest() == depthTest) {
               if (entry3.animated()) {
                  BoxEspRenderer.animatedOutline(outlineBuffer, matrix, cameraPosition, entry3.box(), entry3.color(), animationTime);
               } else {
                  BoxEspRenderer.outline(outlineBuffer, matrix, cameraPosition, entry3.box(), entry3.color());
               }
            }
         }
      }
   }

   private Box getExpandedBoundingBox(Entity entity, float tickProgress, float expansion) {
      Vec3d interpolatedPosition = entity.getLerpedPos(tickProgress);
      Box box = entity.getBoundingBox()
         .offset(interpolatedPosition.x - entity.getX(), interpolatedPosition.y - entity.getY(), interpolatedPosition.z - entity.getZ());
      return expansion > 0.0F ? box.expand(expansion) : box;
   }

   private boolean isValidBox(Box box) {
      return box != null
         && Double.isFinite(box.minX)
         && Double.isFinite(box.minY)
         && Double.isFinite(box.minZ)
         && Double.isFinite(box.maxX)
         && Double.isFinite(box.maxY)
         && Double.isFinite(box.maxZ)
         && box.maxX >= box.minX
         && box.maxY >= box.minY
         && box.maxZ >= box.minZ;
   }

   private float getExpansion(int scale) {
      return (Math.max(1, scale) - 1) * 0.05F;
   }
}
