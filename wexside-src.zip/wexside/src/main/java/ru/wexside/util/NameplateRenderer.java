package ru.wexside.util;

import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.entity.mob.StrayEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Formatting;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import ru.wexside.WexSideClient;
import ru.wexside.event.EventBus;
import ru.wexside.event.HudRenderEvent;
import ru.wexside.event.WorldSessionEvent;
import ru.wexside.item.ItemBadge;
import ru.wexside.item.ItemBadgeCategory;
import ru.wexside.misc.BakedIconEntry;
import ru.wexside.misc.FontRegistry;
import ru.wexside.misc.FriendList;
import ru.wexside.misc.NameTagSettings;
import ru.wexside.model.esp.EspTargetClassifier;
import ru.wexside.model.esp.EspTargetType;
import ru.wexside.module.player.NameProtectModule;
import ru.wexside.render.ItemIconCache;
import ru.wexside.render.NameplateLayout;
import ru.wexside.render.RenderCamera;
import ru.wexside.render.RenderProjection;

public final class NameplateRenderer {
   private static final float value5 = 1.15F;
   private static final float value6 = 11.0F;
   private final int backgroundColor;
   private static final float value7 = 6.25F;
   private final int specialItemBackgroundColor;
   private static final float value8 = 5.0F;
   private static final int slot3 = 16733525;
   private static final int process19 = 16776960;
   static volatile NameplateRenderer fire2;
   private static final float value9 = 2.0F;
   private static final int slot4 = -1;
   private static final MsdfFontRenderer enchantmentFont = FontRegistry.icons;
   private static final EquipmentSlot[] ARMOR_SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   private static final int slot5 = 5635925;
   private final MinecraftClient mc = MinecraftClient.getInstance();
   private static final float value10 = 2.0F;
   private final Text friendSuffix;
   private static final int slot6 = 11184810;
   private static final float value11 = 1.15F;
   private final Text separator;
   private static final MsdfFontRenderer nameFont = FontRegistry.regularText;
   private final EspFeatureRegistry espFeatures;
   private final ItemIconCache itemIcons;
   private final int friendBackgroundColor;
   private static final int slot8 = 8421504;

   public NameplateRenderer(EventBus eventBus, EspFeatureRegistry espFeatures) {
      this.espFeatures = espFeatures;
      this.itemIcons = new ItemIconCache();
      this.backgroundColor = -871362544;
      this.specialItemBackgroundColor = -869654000;
      this.friendBackgroundColor = -871355880;
      this.separator = Text.literal(" ");
      this.friendSuffix = Text.literal("[Friend]").withColor(5635925);
      eventBus.subscribe(HudRenderEvent.class, this::setHudRenderEvent, -100);
      eventBus.subscribe(WorldSessionEvent.class, this::onWorldChanged);
      fire2 = this;
   }

   private void onWorldChanged(WorldSessionEvent event) {
      this.itemIcons.close();
   }

   private boolean process(ItemStack stack) {
      return stack.isIn(ItemTags.SWORDS);
   }

   private MutableText buildLabel(Entity entity, NameTagSettings settings) {
      boolean localPlayer = entity == this.mc.player;
      FriendList friends = WexSideClient.getFriends();
      boolean friend = friends != null && friends.contains(entity.getName().getString());
      Text text;
      if (entity instanceof ItemEntity item) {
         text = item.getStack().getName();
      } else {
         text = entity.getDisplayName();
      }

      Text displayName = text;
      MutableText label = displayName != null ? displayName.copy() : entity.getName().copy();
      if (displayName != null && displayName.getContent() instanceof TranslatableTextContent) {
         label = displayName.copy().fillStyle(Style.EMPTY.withColor(8421504));
      }

      if (friend && !localPlayer && NameProtectModule.isEnabled()) {
         label = Text.literal(NameProtectModule.getString());
      }

      if (settings.isHealthVisible() && entity instanceof LivingEntity living) {
         label.append(this.separator).append(this.bracketedText(16733525, String.valueOf(this.getHealth(entity, living))));
      }

      int reward = settings.isMoneyVisible() && entity instanceof HostileEntity ? this.getMobReward(entity) : 0;
      if (reward != 0) {
         label.append(this.separator).append(this.bracketedText(16776960, "~" + reward + "$"));
      }

      if (friend && !localPlayer) {
         label.append(this.separator).append(this.friendSuffix);
      }

      return label;
   }

   private float process3(NameplateLayout nameplateLayout, int n) {
      return nameplateLayout.centerX + (n - (nameplateLayout.equipment.size() - 1) / 2.0F) * 11.0F;
   }

   private static int enchantmentLevel(ItemStack stack, RegistryKey<Enchantment> enchantment) {
      ItemEnchantmentsComponent espFeatures = EnchantmentHelper.getEnchantments(stack);

      for (Entry entry : espFeatures.getEnchantmentEntries()) {
         if (((RegistryEntry)entry.getKey()).matchesKey(enchantment)) {
            return entry.getIntValue();
         }
      }

      return 0;
   }

   private float process5(GuiDrawApi drawApi, Matrix4f matrix4f, StringBuilder stringBuilder, float f, float f2, float f3, int n) {
      String string = stringBuilder.toString();
      stringBuilder.setLength(0);
      nameFont.process2(matrix4f, drawApi, string, f, f2, f3, n);
      return nameFont.process3(string, f3);
   }

   private List<String> process6(ItemStack stack) {
      ArrayList<String> arrayList = new ArrayList<>();
      int n = enchantmentLevel(stack, Enchantments.PROTECTION);
      int n2 = enchantmentLevel(stack, Enchantments.THORNS);
      int n3 = enchantmentLevel(stack, Enchantments.UNBREAKING);
      int n4 = enchantmentLevel(stack, Enchantments.MENDING);
      int n5 = enchantmentLevel(stack, Enchantments.FEATHER_FALLING);
      int n6 = enchantmentLevel(stack, Enchantments.DEPTH_STRIDER);
      int n7 = enchantmentLevel(stack, Enchantments.SHARPNESS);
      int n8 = enchantmentLevel(stack, Enchantments.LOOTING);
      int n9 = enchantmentLevel(stack, Enchantments.INFINITY);
      int n10 = enchantmentLevel(stack, Enchantments.POWER);
      int n11 = enchantmentLevel(stack, Enchantments.PUNCH);
      int n12 = enchantmentLevel(stack, Enchantments.FLAME);
      int n13 = enchantmentLevel(stack, Enchantments.KNOCKBACK);
      int n14 = enchantmentLevel(stack, Enchantments.FIRE_ASPECT);
      int n15 = enchantmentLevel(stack, Enchantments.EFFICIENCY);
      int n16 = enchantmentLevel(stack, Enchantments.SILK_TOUCH);
      int n17 = enchantmentLevel(stack, Enchantments.FORTUNE);
      int n18 = enchantmentLevel(stack, Enchantments.FIRE_PROTECTION);
      int n19 = enchantmentLevel(stack, Enchantments.BLAST_PROTECTION);
      if (this.process35(stack)) {
         if (n7 > 0) {
            int n20 = n7;
            arrayList.add("Shr" + n20);
         }

         if (n15 > 0) {
            int n21 = n15;
            arrayList.add("Eff" + n21);
         }

         if (n3 > 0) {
            int n22 = n3;
            arrayList.add("Unb" + n22);
         }
      }

      if (this.process11(stack)) {
         if (n18 > 0) {
            int n23 = n18;
            arrayList.add("Fire" + n23);
         }

         if (n19 > 0) {
            int n24 = n19;
            arrayList.add("Bla" + n24);
         }

         if (n6 > 0) {
            int n25 = n6;
            arrayList.add("Dep" + n25);
         }

         if (n5 > 0) {
            int n26 = n5;
            arrayList.add("Fea" + n26);
         }

         if (n > 0) {
            int n27 = n;
            arrayList.add("Pro" + n27);
         }

         if (n2 > 0) {
            int n28 = n2;
            arrayList.add("Thr" + n28);
         }

         if (n4 > 0) {
            arrayList.add("Mn");
         }

         if (n3 > 0) {
            int n29 = n3;
            arrayList.add("Unb" + n29);
         }
      }

      if (this.process28(stack)) {
         if (n9 > 0) {
            int n30 = n9;
            arrayList.add("Inf" + n30);
         }

         if (n10 > 0) {
            int n31 = n10;
            arrayList.add("Pow" + n31);
         }

         if (n11 > 0) {
            int n32 = n11;
            arrayList.add("Pun" + n32);
         }

         if (n4 > 0) {
            arrayList.add("Mn");
         }

         if (n12 > 0) {
            int n33 = n12;
            arrayList.add("Fla" + n33);
         }

         if (n3 > 0) {
            int n34 = n3;
            arrayList.add("Unb" + n34);
         }
      }

      if (this.process(stack)) {
         if (n8 > 0) {
            int n35 = n8;
            arrayList.add("L" + n35);
         }

         if (n7 > 0) {
            int n36 = n7;
            arrayList.add("Shr" + n36);
         }

         if (n13 > 0) {
            int n37 = n13;
            arrayList.add("Kno" + n37);
         }

         if (n14 > 0) {
            int n38 = n14;
            arrayList.add("Fir" + n38);
         }

         if (n3 > 0) {
            int n39 = n3;
            arrayList.add("Unb" + n39);
         }

         if (n4 > 0) {
            arrayList.add("Mn");
         }
      }

      if (this.process23(stack)) {
         if (n3 > 0) {
            int n40 = n3;
            arrayList.add("Unb" + n40);
         }

         if (n4 > 0) {
            arrayList.add("Mn");
         }

         if (n15 > 0) {
            int n41 = n15;
            arrayList.add("Eff" + n41);
         }

         if (n16 > 0) {
            int n42 = n16;
            arrayList.add("Sil" + n42);
         }

         if (n17 > 0) {
            int n43 = n17;
            arrayList.add("For" + n43);
         }
      }

      return arrayList;
   }

   private void process7(GuiDrawApi drawApi, Matrix4f matrix4f, NameplateLayout nameplateLayout) {
      Text iIiilliIII2 = nameplateLayout.badge.label();
      float f = this.process13(iIiilliIII2, 6.25F);
      this.process38(drawApi, matrix4f, iIiilliIII2, nameplateLayout.centerX - f / 2.0F, this.process17(nameplateLayout), 6.25F);
   }

   private void process8(GuiDrawApi drawApi, Matrix4f matrix4f, NameplateLayout nameplateLayout) {
      float f = nameFont.process4(nameplateLayout.label.getString(), nameplateLayout.fontSize);
      float f2 = nameplateLayout.labelWidth;
      float f3 = nameplateLayout.centerX - f2 / 2.0F;
      float f4 = f3 - 1.5F;
      float f5 = nameplateLayout.baselineY - f - 2.5F;
      float f6 = f3 + f2 + 1.5F - f4;
      float f7 = nameplateLayout.baselineY - 2.0F - f5;
      drawApi.fillRectangle(matrix4f, f4, f5, f6, f7, nameplateLayout.friend ? this.friendBackgroundColor : this.backgroundColor);
   }

   private boolean process11(ItemStack stack) {
      return stack.isIn(ItemTags.ARMOR_ENCHANTABLE);
   }

   private boolean process12(Entity entity2, Frustum frustum2) {
      EspTargetType espTargetType = EspTargetClassifier.targetType(entity2, this.mc.player);
      NameTagSettings talisman = this.espFeatures.getNameTagSettings(espTargetType, EspTargetClassifier.relation(entity2));
      return espTargetType != null
         && talisman != null
         && talisman.isEnabled()
         && entity2.isAlive()
         && RenderProjection.isVisible(entity2, frustum2)
         && (entity2 != this.mc.player || !this.mc.options.getPerspective().isFirstPerson());
   }

   private float process13(Text iIiilliIII2, float f) {
      float[] fArray = new float[]{0.0F};
      StringBuilder stringBuilder = new StringBuilder(16);
      iIiilliIII2.visit((style, string) -> {
         String string2 = string;
         stringBuilder.setLength(0);

         for (int i = 0; i < string2.length(); i++) {
            char c = string2.charAt(i);
            if ((c == 167 || c == '&') && i + 1 < string2.length() && Formatting.byCode(Character.toLowerCase(string2.charAt(i + 1))) != null) {
               i++;
            } else {
               stringBuilder.append(c);
            }
         }

         if (stringBuilder.length() > 0) {
            fArray[0] += nameFont.process3(stringBuilder.toString(), f);
         }

         return Optional.empty();
      }, Style.EMPTY);
      return fArray[0];
   }

   private float process14(float f, float f2, float f3, float f4, float f5, float f6, float f7, float f8) {
      float f10 = Math.max(0.0F, Math.min(f + f3, f5 + f7) - Math.max(f, f5));
      float f11 = f10 * Math.max(0.0F, Math.min(f2 + f4, f6 + f8) - Math.max(f2, f6));
      return f11 == 0.0F ? 0.0F : f11 / Math.min(f3 * f4, f7 * f8);
   }

   private float process15(NameplateLayout nameplateLayout) {
      return nameplateLayout.badge != null
         ? this.process17(nameplateLayout) - nameFont.process4("Ag", 6.25F) - 2.0F
         : nameplateLayout.baselineY - 23.0F - 10.0F;
   }

   public static boolean process16(Entity entity2) {
      NameplateRenderer fire = fire2;
      if (fire == null) {
         return false;
      }

      MinecraftClient mc2 = MinecraftClient.getInstance();
      EspTargetType espTargetType = EspTargetClassifier.targetType(entity2, mc2.player);
      NameTagSettings talisman = fire.espFeatures.getNameTagSettings(espTargetType, EspTargetClassifier.relation(entity2));
      return espTargetType != null && talisman != null && talisman.isEnabled() && (entity2 != mc2.player || !mc2.options.getPerspective().isFirstPerson());
   }

   private float process17(NameplateLayout nameplateLayout) {
      return nameplateLayout.baselineY - 23.0F - 9.0F;
   }

   private int getHealth(Entity entity, LivingEntity living) {
      Scoreboard scoreboard = this.mc.world.getScoreboard();
      ScoreboardObjective objective = scoreboard.getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
      ReadableScoreboardScore score = objective == null ? null : scoreboard.getScore(entity, objective);
      return score != null ? score.getScore() : Math.round(living.getHealth());
   }

   private List<ItemStack> process20(LivingEntity entity3) {
      ArrayList<ItemStack> arrayList = new ArrayList<>();
      arrayList.add(entity3.getMainHandStack());
      arrayList.add(entity3.getOffHandStack());

      for (EquipmentSlot iliiIIiliI2 : ARMOR_SLOTS) {
         arrayList.add(entity3.getEquippedStack(iliiIIiliI2));
      }

      arrayList.removeIf(ItemStack::isEmpty);
      return arrayList;
   }

   private void process22(GuiDrawApi drawApi, Matrix4f matrix4f, NameplateLayout nameplateLayout) {
      float f = nameplateLayout.baselineY - 23.0F;

      for (int i = 0; i < nameplateLayout.equipment.size(); i++) {
         float f2 = this.process3(nameplateLayout, i);
         boolean bl = this.process29(nameplateLayout.equipment.get(i));
         drawApi.fillRectangle(matrix4f, f2 - 5.0F, f, 10.0F, 10.0F, bl ? this.specialItemBackgroundColor : this.backgroundColor);
      }
   }

   private boolean process23(ItemStack stack) {
      return stack.isIn(ItemTags.PICKAXES) || stack.isIn(ItemTags.SHOVELS) || stack.isIn(ItemTags.HOES);
   }

   private float process25(NameplateLayout nameplateLayout) {
      float f = 0.0F;

      for (ItemStack stack : nameplateLayout.equipment) {
         for (String string : this.process6(stack)) {
            f = Math.max(f, enchantmentFont.process3(string, 5.0F));
         }
      }

      float f2 = 10.5F;
      return f > f2 ? 5.0F * f2 / f : 5.0F;
   }

   private boolean process26(Entity entity2) {
      if (entity2 == this.mc.player) {
         return false;
      }

      FriendList friendList2 = WexSideClient.getFriends();
      return friendList2 != null && friendList2.contains(entity2.getName().getString());
   }

   private int getMobReward(Entity entity2) {
      if (entity2 instanceof SpiderEntity) {
         return 700;
      } else if (entity2 instanceof CreeperEntity) {
         return 2000;
      } else if (entity2 instanceof StrayEntity) {
         return 4000;
      } else if (entity2 instanceof SkeletonEntity || entity2 instanceof ZombieEntity) {
         return 600;
      } else if (entity2 instanceof EndermanEntity) {
         return 1000;
      } else {
         return entity2 instanceof WitherEntity ? 10000 : 0;
      }
   }

   private boolean process28(ItemStack stack) {
      return stack.getItem() instanceof BowItem;
   }

   private void setHudRenderEvent(HudRenderEvent gameEvent20) {
      if (!this.espFeatures.hasEnabledNameTags()) {
         this.itemIcons.close();
      } else if (this.mc.world != null && this.mc.player != null && RenderCamera.position() != null) {
         Frustum frustum = RenderProjection.frustum();
         Matrix4f viewProjection = RenderProjection.viewProjectionMatrix();
         ArrayList<Entity> visibleEntities = new ArrayList<>();

         for (Entity entity2 : this.mc.world.getEntities()) {
            if (this.process12(entity2, frustum)) {
               visibleEntities.add(entity2);
            }
         }

         if (!visibleEntities.isEmpty()) {
            visibleEntities.sort(Comparator.comparingDouble(entity -> this.mc.player.getEntityPos().squaredDistanceTo(entity.getEntityPos())));
            ArrayList<NameplateLayout> nameplates = new ArrayList<>();
            ArrayList<float[]> occupiedBounds = new ArrayList<>();
            Iterator scale = visibleEntities.iterator();

            while (true) {
               Entity class_12972;
               float f4;
               NameTagSettings settings;
               Vector2f projected;
               MutableText label;
               float f;
               while (true) {
                  if (!scale.hasNext()) {
                     if (nameplates.isEmpty()) {
                        return;
                     }

                     float scalex = this.mc.getWindow().getScaleFactor();
                     this.itemIcons.beginFrame();

                     for (NameplateLayout nameplate : nameplates) {
                        if (nameplate.equipment != null) {
                           nameplate.equipmentIcons = new ArrayList<>(nameplate.equipment.size());

                           for (ItemStack stack : nameplate.equipment) {
                              nameplate.equipmentIcons.add(this.itemIcons.get(stack));
                           }
                        }
                     }

                     ArrayList<BakedIconEntry> arrayList = new ArrayList<>();
                     this.itemIcons.collectBakeEntries(scalex, arrayList);
                     if (!arrayList.isEmpty()) {
                        WexSideClient.getRenderPipeline2().setList(arrayList);
                     }

                     GuiDrawApi renderer = WexSideClient.getHudRenderer();
                     Matrix4f guiMatrix = new Matrix4f().scale(scalex);
                     renderer.begin();

                     try {
                        for (NameplateLayout nameplate : nameplates) {
                           this.process8(renderer, guiMatrix, nameplate);
                           if (nameplate.badge != null) {
                              this.process31(renderer, guiMatrix, nameplate);
                           }

                           if (nameplate.equipment != null) {
                              this.process22(renderer, guiMatrix, nameplate);
                           }
                        }

                        for (NameplateLayout nameplate : nameplates) {
                           if (nameplate.equipment != null) {
                              this.process33(renderer, guiMatrix, nameplate);
                           }
                        }
                     } finally {
                        renderer.end();
                     }

                     renderer.begin();

                     try {
                        for (NameplateLayout nameplate : nameplates) {
                           this.process37(renderer, guiMatrix, nameplate);
                           if (nameplate.badge != null) {
                              this.process7(renderer, guiMatrix, nameplate);
                           }
                        }

                        for (NameplateLayout nameplate : nameplates) {
                           if (nameplate.equipment != null && nameplate.showEnchantments) {
                              this.process30(renderer, guiMatrix, nameplate);
                           }
                        }
                     } finally {
                        renderer.end();
                     }

                     this.itemIcons.evictUnused();
                     return;
                  }

                  class_12972 = (Entity)scale.next();
                  settings = this.espFeatures
                     .getNameTagSettings(EspTargetClassifier.targetType(class_12972, this.mc.player), EspTargetClassifier.relation(class_12972));
                  projected = RenderProjection.projectEntityLabel(class_12972, viewProjection);
                  if (settings != null && projected != null) {
                     label = this.buildLabel(class_12972, settings);
                     String string = label.getString();
                     f = string.contains("★") ? 9.0F : 7.0F;
                     float f5 = f4 = this.process13(label, f);
                     float f6 = nameFont.process4(string, f) + 4.0F;
                     float f7 = projected.x - f5 / 2.0F;
                     float f8 = projected.y - f6;
                     if (!settings.shouldPreventOverlap()) {
                        break;
                     }

                     boolean overlaps = false;

                     for (float[] bounds : occupiedBounds) {
                        if (this.process14(f7, f8, f5, f6, bounds[0], bounds[1], bounds[2], bounds[3]) > settings.getOverlapThreshold()) {
                           overlaps = true;
                           break;
                        }
                     }

                     if (!overlaps) {
                        occupiedBounds.add(new float[]{f7, f8, f5, f6});
                        break;
                     }
                  }
               }

               NameplateLayout nameplate = new NameplateLayout(projected.x, projected.y, label, f, f4);
               nameplate.friend = this.process26(class_12972);
               nameplate.showEnchantments = settings.shouldShowEnchantments();
               LivingEntity living;
               List<ItemStack> equipment;
               if (settings.areItemsVisible()
                  && class_12972 instanceof LivingEntity
                  && !(equipment = this.process20(living = (LivingEntity)class_12972)).isEmpty()) {
                  nameplate.equipment = equipment;
               }

               if (class_12972 instanceof LivingEntity livingx) {
                  nameplate.badge = process40(livingx, settings.isTalismanVisible(), settings.isSphereVisible());
               }

               nameplates.add(nameplate);
            }
         }
      }
   }

   private boolean process29(ItemStack stack) {
      Item iiIilIIilI2 = stack.getItem();
      BlockItem text2;
      boolean bl = iiIilIIilI2 instanceof BlockItem && (text2 = (BlockItem)iiIilIIilI2).getBlock() instanceof AbstractSkullBlock;
      return bl || stack.getItem() == Items.TOTEM_OF_UNDYING;
   }

   private void process30(GuiDrawApi drawApi, Matrix4f matrix4f, NameplateLayout nameplateLayout) {
      float f = this.process25(nameplateLayout);
      float f2 = enchantmentFont.process4("Ag", f) + 1.0F;
      float f3 = this.process15(nameplateLayout);

      for (int i = 0; i < nameplateLayout.equipment.size(); i++) {
         float f4 = this.process3(nameplateLayout, i);
         List<String> list = this.process6(nameplateLayout.equipment.get(i));

         for (int j = 0; j < list.size(); j++) {
            String string = list.get(j);
            float f5 = enchantmentFont.process3(string, f);
            enchantmentFont.process2(matrix4f, drawApi, string, f4 - f5 / 2.0F, f3 - j * f2, f, -1);
         }
      }
   }

   private void process31(GuiDrawApi drawApi, Matrix4f matrix4f, NameplateLayout nameplateLayout) {
      Text iIiilliIII2 = nameplateLayout.badge.label();
      float f = this.process13(iIiilliIII2, 6.25F);
      float f2 = nameFont.process4(iIiilliIII2.getString(), 6.25F);
      float f3 = nameplateLayout.centerX - f / 2.0F;
      float f4 = this.process17(nameplateLayout);
      drawApi.fillRectangle(matrix4f, f3 - 1.5F, f4 - 1.0F, f + 3.0F, f2 + 2.0F, this.backgroundColor);
   }

   private void process33(GuiDrawApi drawApi, Matrix4f matrix4f, NameplateLayout nameplateLayout) {
      float f = nameplateLayout.baselineY - 23.0F;

      for (int i = 0; i < nameplateLayout.equipment.size(); i++) {
         float f2 = this.process3(nameplateLayout, i);
         this.itemIcons.process3(drawApi, matrix4f, nameplateLayout.equipmentIcons.get(i), f2 - 4.5F, f + 0.5F, 9.0F);
      }
   }

   private boolean process35(ItemStack stack) {
      return stack.isIn(ItemTags.AXES);
   }

   private MutableText bracketedText(int color, String value) {
      return Text.empty()
         .append(Text.literal("[").withColor(11184810))
         .append(Text.literal(value).withColor(color))
         .append(Text.literal("]").withColor(11184810));
   }

   private void process37(GuiDrawApi drawApi, Matrix4f matrix4f, NameplateLayout nameplateLayout) {
      float f3 = nameFont.process4(nameplateLayout.label.getString(), nameplateLayout.fontSize);
      float f4 = nameplateLayout.labelWidth;
      float f5 = nameplateLayout.centerX - f4 / 2.0F;
      float f6 = nameplateLayout.baselineY - f3 - 2.5F;
      this.process38(drawApi, matrix4f, nameplateLayout.label, f5, f6, nameplateLayout.fontSize);
   }

   private void process38(GuiDrawApi drawApi, Matrix4f matrix4f, Text iIiilliIII2, float f, float f2, float f3) {
      float[] fArray = new float[]{f};
      StringBuilder stringBuilder = new StringBuilder(16);
      iIiilliIII2.visit(
         (style, string) -> {
            String string2 = string;
            TextColor textColor = style.getColor();
            int baseColor;
            int currentColor = baseColor = 0xFF000000 | (textColor != null ? textColor.getRgb() : 16777215);

            for (int i = 0; i < string2.length(); i++) {
               char c = string2.charAt(i);
               Formatting formatting;
               if ((c == 167 || c == '&') && i + 1 < string2.length() && (formatting = Formatting.byCode(Character.toLowerCase(string2.charAt(i + 1)))) != null
                  )
                {
                  int nextColor = formatting == Formatting.RESET
                     ? baseColor
                     : (formatting.getColorValue() != null ? 0xFF000000 | formatting.getColorValue() : currentColor);
                  if (nextColor != currentColor && stringBuilder.length() > 0) {
                     fArray[0] += this.process5(drawApi, matrix4f, stringBuilder, fArray[0], f2, f3, currentColor);
                  }

                  currentColor = nextColor;
                  i++;
               } else {
                  stringBuilder.append(c);
               }
            }

            if (stringBuilder.length() > 0) {
               fArray[0] += this.process5(drawApi, matrix4f, stringBuilder, fArray[0], f2, f3, currentColor);
            }

            return Optional.empty();
         },
         Style.EMPTY
      );
   }

   private static ItemBadge process40(LivingEntity entity3, boolean bl, boolean bl2) {
      if (!bl && !bl2) {
         return null;
      }

      ItemBadge itemBadge = ItemBadge.fromStack(entity3.getOffHandStack());
      if (itemBadge == null) {
         return null;
      }

      boolean enabledForCategory = itemBadge.category() == ItemBadgeCategory.TALISMAN ? bl : bl2;
      return enabledForCategory ? itemBadge : null;
   }
}
