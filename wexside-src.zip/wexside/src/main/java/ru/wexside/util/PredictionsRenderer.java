package ru.wexside.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import ru.wexside.WexSideClient;
import ru.wexside.event.HudRenderEvent;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.BakedIconEntry;
import ru.wexside.misc.FontRegistry;
import ru.wexside.misc.LazyMeshModel;
import ru.wexside.misc.SpatialTransform;
import ru.wexside.module.render.PredictionsModule;
import ru.wexside.prediction.ImpactQuad;
import ru.wexside.prediction.LandingPrediction;
import ru.wexside.prediction.LandingTimeLabel;
import ru.wexside.prediction.ModelOrientation;
import ru.wexside.prediction.PotionImpactMarker;
import ru.wexside.prediction.ProjectileImpact;
import ru.wexside.prediction.TrajectoryPrediction;
import ru.wexside.render.DepthSampler;
import ru.wexside.render.ItemIconCache;
import ru.wexside.render.RenderCamera;
import ru.wexside.render.RenderProjection;
import ru.wexside.render.model.BuiltInMesh;
import ru.wexside.render.world.WorldLineRenderer;

public final class PredictionsRenderer {
   private final TrajectoryPredictor trajectoryPredictor;
   private final Map<Integer, Vec3d> stablePotionImpactPositions;
   private static final WorldMeshBatchRenderer MODEL_RENDERER = new WorldMeshBatchRenderer("trajectory-prediction");
   private final LazyMeshModel arrowModel;
   private static final MsdfFontRenderer LANDING_LABEL_FONT = FontRegistry.boldText;
   private float animationTimeSeconds;
   private final LazyMeshModel roundProjectileModel;
   private final ModelRenderQueue modelRenderQueue;
   private final PredictionsModule predictionsModule;
   private final List<LandingPrediction> landingPredictions;
   private final List<PotionImpactMarker> potionImpactMarkers;
   private final ItemIconCache itemIconCache = new ItemIconCache();
   private final LazyMeshModel entityBoxModel;
   private final List<ImpactQuad> impactQuads;
   private float pulseScale = 1.0F;
   private final DepthSampler depthSampler;
   private static final Identifier IMPACT_MARKER_TEXTURE = Identifier.of("wexside", "textures/prediction/arrow_cross.png");
   private final LazyMeshModel tridentModel;
   private Matrix4f currentWorldMatrix;

   public PredictionsRenderer(PredictionsModule predictionsModule) {
      this.landingPredictions = new ArrayList<>();
      this.impactQuads = new ArrayList<>();
      this.depthSampler = new DepthSampler();
      this.tridentModel = LazyMeshModel.create(BuiltInMesh.TRIDENT);
      this.roundProjectileModel = LazyMeshModel.create(BuiltInMesh.SKULL);
      this.arrowModel = LazyMeshModel.create(BuiltInMesh.ARROW);
      this.entityBoxModel = LazyMeshModel.create(BuiltInMesh.CUBE);
      this.modelRenderQueue = new ModelRenderQueue();
      this.potionImpactMarkers = new ArrayList<>();
      this.stablePotionImpactPositions = new HashMap<>();
      this.predictionsModule = predictionsModule;
      this.trajectoryPredictor = new TrajectoryPredictor();
   }

   private double[][] rotationYMatrix(float f) {
      double d = Math.toRadians(f);
      double d2 = Math.cos(d);
      double d3 = Math.sin(d);
      return new double[][]{{d2, 0.0, d3}, {0.0, 1.0, 0.0}, {-d3, 0.0, d2}};
   }

   private void addPotionImpactBox(Vec3d vec) {
      if (this.predictionsModule.showEntityHitBox()) {
         MinecraftClient mc = MinecraftClient.getInstance();
         if (mc.world != null) {
            for (Entity entity2 : mc.world.getEntities()) {
               if (this.isLivingTarget(entity2) && new Vec3d(entity2.getX(), entity2.getY(), entity2.getZ()).distanceTo(vec) <= 3.0) {
                  WorldLineRenderer.drawEntityBox(this.currentWorldMatrix, entity2, -45747);
               }
            }
         }
      }
   }

   private int withAlpha(int n, float f) {
      int n2 = Math.clamp(Math.round(f * 255.0F), 0, 255);
      return n2 << 24 | n & 16777215;
   }

   private void renderActiveProjectilePredictions(WorldRenderEvent floatTypeEvent2, MinecraftClient mc) {
      HashSet<Integer> hashSet = new HashSet<>();

      for (Entity entity2 : mc.world.getEntities()) {
         TrajectoryPrediction trajectoryPrediction;
         if (this.shouldTrackEntity(entity2) && (trajectoryPrediction = this.trajectoryPredictor.process2(entity2, floatTypeEvent2.getFloatType())) != null) {
            boolean bl = this.isOwnedByLocalPlayer(mc, entity2);
            int n = this.getEntityTrajectoryColor(entity2, bl);
            this.renderTrajectory(trajectoryPrediction, n, false, 0);
            ProjectileImpact illliiiilI2 = trajectoryPrediction.impact();
            if (illliiiilI2 != null) {
               ItemStack landingItem = this.getProjectileItemStack(entity2);
               if (this.predictionsModule.showLandingTime() && !landingItem.isEmpty()) {
                  this.landingPredictions.add(new LandingPrediction(illliiiilI2.position(), trajectoryPrediction.flightTicks(), landingItem));
               }

               ProjectileType iiIlilIilI2;
               if ((iiIlilIilI2 = ProjectileType.fromEntity(entity2)) == ProjectileType.POTION) {
                  hashSet.add(entity2.getId());
                  Vec3d vec = this.snapPotionImpactToGround(illliiiilI2.position(), illliiiilI2.face());
                  Vec3d vec2 = this.stablePotionImpactPositions.get(entity2.getId());
                  if (vec2 == null) {
                     if (entity2.getVelocity().lengthSquared() < 0.05) {
                        continue;
                     }

                     vec2 = vec;
                     this.stablePotionImpactPositions.put(entity2.getId(), vec2);
                  } else if (vec2.squaredDistanceTo(vec) > 2.25) {
                     vec2 = vec;
                     this.stablePotionImpactPositions.put(entity2.getId(), vec2);
                  }

                  this.potionImpactMarkers.add(new PotionImpactMarker(vec2, n));
                  if (bl) {
                     this.addPotionImpactBox(vec2);
                  }
               } else {
                  if (bl) {
                     this.markHitEntity(illliiiilI2);
                  }

                  if (iiIlilIilI2 != null && this.predictionsModule.shouldShowTrajectory(toProjectileKind(iiIlilIilI2), bl)) {
                     this.queueImpactModel(mc, iiIlilIilI2, illliiiilI2, n, floatTypeEvent2.getFloatType());
                  } else {
                     this.renderCircularImpactMarker(illliiiilI2.position(), illliiiilI2.face(), illliiiilI2.hitEntity());
                  }
               }
            }
         }
      }

      this.stablePotionImpactPositions.keySet().retainAll(hashSet);
   }

   private void flushModelQueue(WorldRenderEvent floatTypeEvent2, MinecraftClient mc) {
      if (!this.modelRenderQueue.isActive()) {
         MODEL_RENDERER.process10(floatTypeEvent2.getMatrices(), mc.getBufferBuilders().getEntityVertexConsumers(), this.toVec3d(), this.modelRenderQueue);
         this.modelRenderQueue.update();
      }
   }

   private void queuePotionAffectedEntityBoxes(MinecraftClient mc, Vec3d vec, int n, float f) {
      if (this.entityBoxModel.isLoaded() && this.entityBoxModel.getMeshModel() != null && !this.entityBoxModel.getMeshModel().getList().isEmpty()) {
         ModelRenderOptions modelRenderOptions = ModelRenderOptions.process4(true).process5(false).process7(2.2F).process10(true);
         int n2 = this.withScaledAlpha(n, 0.0F);

         for (Entity entity2 : mc.world.getEntities()) {
            LivingEntity entity3;
            if (entity2 instanceof LivingEntity
               && (entity3 = (LivingEntity)entity2).isAlive()
               && !(new Vec3d(entity3.getX(), entity3.getY(), entity3.getZ()).distanceTo(vec) > 3.0)) {
               Box box = entity3.getBoundingBox();
               double d = MathHelper.lerp(f, entity3.lastX, entity3.getX()) - entity3.getX();
               double d2 = MathHelper.lerp(f, entity3.lastY, entity3.getY()) - entity3.getY();
               double d3 = MathHelper.lerp(f, entity3.lastZ, entity3.getZ()) - entity3.getZ();
               this.modelRenderQueue
                  .process7(
                     this.entityBoxModel.getMeshModel(),
                     new SpatialTransform(
                        (box.minX + box.maxX) / 2.0 + d,
                        box.minY + d2 + 0.01F + 0.004F,
                        (box.minZ + box.maxZ) / 2.0 + d3,
                        (float)(box.maxX - box.minX + 0.12F),
                        0.02F,
                        (float)(box.maxZ - box.minZ + 0.12F)
                     ),
                     n2,
                     modelRenderOptions
                  );
            }
         }
      }
   }

   private double[][] rotationXMatrix(float f) {
      double d = Math.toRadians(f);
      double d2 = Math.cos(d);
      double d3 = Math.sin(d);
      return new double[][]{{1.0, 0.0, 0.0}, {0.0, d2, -d3}, {0.0, d3, d2}};
   }

   private ModelOrientation orientationAlongVelocity(Vec3d vec) {
      float f = (float)Math.toDegrees(Math.atan2(vec.x, vec.z)) - 90.0F;
      float f2 = (float)Math.toDegrees(Math.atan2(vec.y, Math.sqrt(vec.x * vec.x + vec.z * vec.z))) + 90.0F;
      double[][] dArray = this.multiplyMatrices(this.multiplyMatrices(this.rotationYMatrix(f), this.rotationZMatrix(f2)), this.rotationXMatrix(90.0F));
      return this.matrixToOrientation(dArray);
   }

   private void renderLandingLabel(GuiDrawApi drawApi, Matrix4f matrix4f, LandingTimeLabel label) {
      this.itemIconCache.process3(drawApi, matrix4f, label.bakedIcon, label.iconX, label.iconY, 9.0F);
      LANDING_LABEL_FONT.process2(matrix4f, drawApi, label.text, label.textX, label.textY, 7.0F, -1);
   }

   private float impactOutlineWidth(float f) {
      float f2 = MathHelper.clamp(f, 0.0F, 1.0F);
      return 1.0F + 1.0F * f2;
   }

   private Vec3d offsetOnImpactPlane(Vec3d vec, Direction process17, double d, double d2) {
      return switch (process17.getAxis()) {
         case Y -> vec.add(d, 0.0, d2);
         case Z -> vec.add(d, d2, 0.0);
         case X -> vec.add(0.0, d, d2);
      };
   }

   private LandingTimeLabel createLandingTimeLabel(float f, float f2, String string, ItemStack stack) {
      float f3 = LANDING_LABEL_FONT.process3(string, 7.0F);
      float f4 = LANDING_LABEL_FONT.process4(string, 7.0F);
      float f5 = Math.max(9.0F, f4);
      float f6 = 14.0F + f3 + 3.0F;
      float f7 = f5 + 6.0F;
      float f8 = f - f6 / 2.0F;
      float f9 = f2 - f7 / 2.0F;
      float f10 = f8 + 3.0F;
      float f11 = f9 + (f7 - 9.0F) / 2.0F;
      float f12 = f10 + 9.0F + 2.0F;
      float f13 = f9 + (f7 - f4) / 2.0F;
      return new LandingTimeLabel(f8, f9, f6, f7, f10, f11, f12, f13, string, stack);
   }

   private void renderCircularImpactMarker(Vec3d vec, Direction process17, Entity entity2) {
      if (this.predictionsModule.showImpactMarker() && vec != null && process17 != null) {
         int n = entity2 instanceof LivingEntity ? -45747 : this.predictionsModule.getImpactColorArgb();
         double d = 0.95 + 0.05 * Math.sin(this.animationTimeSeconds * Math.PI);
         double d2 = 0.3 * d;
         double d3 = 0.1 * d;
         ArrayList<WorldLineRenderer.Segment> lines = new ArrayList<>(42);

         for (int i = 0; i < 40; i++) {
            double d4 = (Math.PI * 2) * i / 40.0;
            double d5 = (Math.PI * 2) * (i + 1) / 40.0;
            lines.add(
               new WorldLineRenderer.Segment(
                  this.offsetOnImpactPlane(vec, process17, Math.cos(d4) * d2, Math.sin(d4) * d2),
                  this.offsetOnImpactPlane(vec, process17, Math.cos(d5) * d2, Math.sin(d5) * d2),
                  n,
                  n
               )
            );
         }

         switch (process17.getAxis()) {
            case Y:
               lines.add(new WorldLineRenderer.Segment(vec.add(-d3, 0.0, 0.0), vec.add(d3, 0.0, 0.0), n, n));
               lines.add(new WorldLineRenderer.Segment(vec.add(0.0, 0.0, -d3), vec.add(0.0, 0.0, d3), n, n));
               break;
            case Z:
               lines.add(new WorldLineRenderer.Segment(vec.add(-d3, 0.0, 0.0), vec.add(d3, 0.0, 0.0), n, n));
               lines.add(new WorldLineRenderer.Segment(vec.add(0.0, -d3, 0.0), vec.add(0.0, d3, 0.0), n, n));
               break;
            case X:
               lines.add(new WorldLineRenderer.Segment(vec.add(0.0, -d3, 0.0), vec.add(0.0, d3, 0.0), n, n));
               lines.add(new WorldLineRenderer.Segment(vec.add(0.0, 0.0, -d3), vec.add(0.0, 0.0, d3), n, n));
         }

         WorldLineRenderer.draw(this.currentWorldMatrix, lines);
      }
   }

   private void renderImpactQuads(WorldRenderEvent floatTypeEvent2, MinecraftClient mc) {
      if (!this.impactQuads.isEmpty()) {
         Vec3d vec = this.toVec3d();
         Matrix4f matrix4f = new Matrix4f(floatTypeEvent2.getMatrices().peek().getPositionMatrix());
         Immediate iIiIliiliI2 = mc.getBufferBuilders().getEntityVertexConsumers();
         RenderLayer enabled = RenderLayers.entityTranslucent(IMPACT_MARKER_TEXTURE);
         VertexConsumer iliIIiiliI2 = iIiIliiliI2.getBuffer(enabled);
         double d = 0.16 * this.pulseScale;

         for (ImpactQuad marker : this.impactQuads) {
            int n = marker.color();
            int n2 = n >>> 24 & 0xFF;
            int n3 = n >> 16 & 0xFF;
            int n4 = n >> 8 & 0xFF;
            int n5 = n & 0xFF;
            Vec3d vec2 = marker.position();
            Direction process17 = marker.face();
            Vec3d vec3 = this.offsetOnImpactPlane(vec2, process17, -d, -d).subtract(vec);
            Vec3d vec4 = this.offsetOnImpactPlane(vec2, process17, d, -d).subtract(vec);
            Vec3d vec5 = this.offsetOnImpactPlane(vec2, process17, d, d).subtract(vec);
            Vec3d vec6 = this.offsetOnImpactPlane(vec2, process17, -d, d).subtract(vec);
            this.writeImpactVertex(iliIIiiliI2, matrix4f, vec3, 0.0F, 0.0F, n3, n4, n5, n2);
            this.writeImpactVertex(iliIIiiliI2, matrix4f, vec4, 1.0F, 0.0F, n3, n4, n5, n2);
            this.writeImpactVertex(iliIIiiliI2, matrix4f, vec5, 1.0F, 1.0F, n3, n4, n5, n2);
            this.writeImpactVertex(iliIIiiliI2, matrix4f, vec3, 0.0F, 0.0F, n3, n4, n5, n2);
            this.writeImpactVertex(iliIIiiliI2, matrix4f, vec5, 1.0F, 1.0F, n3, n4, n5, n2);
            this.writeImpactVertex(iliIIiiliI2, matrix4f, vec6, 0.0F, 1.0F, n3, n4, n5, n2);
         }

         iIiIliiliI2.draw(enabled);
      }
   }

   public void onHudRender(HudRenderEvent gameEvent20) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (!this.predictionsModule.isModuleEnabled() || mc.player == null || mc.world == null || RenderCamera.position() == null) {
         this.itemIconCache.update3();
      } else if (this.predictionsModule.showLandingTime() && !this.landingPredictions.isEmpty()) {
         ArrayList<LandingTimeLabel> arrayList = new ArrayList<>(this.landingPredictions.size());

         for (LandingPrediction landingPrediction : this.landingPredictions) {
            Vector2f vector2f = RenderProjection.project(landingPrediction.position());
            ItemStack stack;
            if (vector2f != null && !(stack = landingPrediction.icon()).isEmpty()) {
               float f2 = Math.round(landingPrediction.flightTicks() / 20.0F * 10.0F) / 10.0F;
               arrayList.add(this.createLandingTimeLabel(vector2f.x, vector2f.y, f2 + " сек.", stack));
            }
         }

         if (!arrayList.isEmpty()) {
            float f3 = mc.getWindow().getScaleFactor();
            this.itemIconCache.update2();

            for (LandingTimeLabel label : arrayList) {
               label.bakedIcon = this.itemIconCache.process(label.item);
            }

            ArrayList<BakedIconEntry> arrayList2 = new ArrayList<>();
            this.itemIconCache.process2(f3, arrayList2);
            if (!arrayList2.isEmpty()) {
               WexSideClient.getRenderPipeline2().setList(arrayList2);
            }

            GuiDrawApi drawApi = WexSideClient.getHudRenderer();
            Matrix4f matrix = new Matrix4f().scale(f3);
            float f = 2.0F / f3;
            drawApi.begin();

            try {
               for (LandingTimeLabel label : arrayList) {
                  drawApi.drawRoundedOutline(matrix, label.x, label.y, label.width, label.height, 8.0F, f, -1340597728);
                  this.renderLandingLabel(drawApi, matrix, label);
               }
            } finally {
               drawApi.end();
            }

            this.itemIconCache.update();
         }
      } else {
         this.itemIconCache.update3();
      }
   }

   public void onWorldRender(WorldRenderEvent floatTypeEvent2) {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (this.predictionsModule.isModuleEnabled() && mc.player != null && mc.world != null) {
         this.clearFrameData();
         this.currentWorldMatrix = floatTypeEvent2 != null && floatTypeEvent2.getMatrices() != null
            ? floatTypeEvent2.getMatrices().peek().getPositionMatrix()
            : new Matrix4f();
         float f = ((float)mc.world.getTimeOfDay() + floatTypeEvent2.getFloatType()) / 20.0F;
         this.pulseScale = 0.95F + 0.05F * MathHelper.sin((float)(f * Math.PI));
         this.animationTimeSeconds = f;
         this.renderHeldItemPredictions(floatTypeEvent2, mc);
         this.renderOtherPlayerPredictions(floatTypeEvent2, mc);
         this.renderActiveProjectilePredictions(floatTypeEvent2, mc);
         this.renderDroppedItemTrajectories(floatTypeEvent2, mc);
         this.queuePotionEffectVolumes(floatTypeEvent2, mc);
         this.flushModelQueue(floatTypeEvent2, mc);
         this.renderImpactQuads(floatTypeEvent2, mc);
         this.updatePotionDepthSampler();
      } else {
         this.clearFrameData();
         this.stablePotionImpactPositions.clear();
      }
   }

   public void resetSession() {
      this.clearFrameData();
      this.itemIconCache.update3();
   }

   private void writeImpactVertex(VertexConsumer iliIIiiliI2, Matrix4f matrix4f, Vec3d vec, float f, float f2, int n, int n2, int n3, int n4) {
      iliIIiiliI2.vertex(matrix4f, (float)vec.x, (float)vec.y, (float)vec.z)
         .color(n, n2, n3, n4)
         .texture(f, f2)
         .overlay(OverlayTexture.DEFAULT_UV)
         .light(15728880)
         .normal(0.0F, 1.0F, 0.0F);
   }

   private void markHitEntity(ProjectileImpact impact) {
      if (this.predictionsModule.showEntityHitBox() && this.isLivingTarget(impact.hitEntity())) {
         WorldLineRenderer.drawEntityBox(this.currentWorldMatrix, impact.hitEntity(), -45747);
      }
   }

   private double[][] rotationZMatrix(float f) {
      double d = Math.toRadians(f);
      double d2 = Math.cos(d);
      double d3 = Math.sin(d);
      return new double[][]{{d2, -d3, 0.0}, {d3, d2, 0.0}, {0.0, 0.0, 1.0}};
   }

   private void addClassicArrowImpact(MinecraftClient mc, ProjectileType iiIlilIilI2, ProjectileImpact illliiiilI2, int n, float f) {
      Vec3d vec = this.trajectoryPredictor.process4(mc.player, f);
      float f2 = this.calculateDistanceFade(vec.distanceTo(illliiiilI2.position()));
      if (!(f2 < 0.02F)) {
         int n2 = illliiiilI2.hitEntity() != null ? -45747 : n;
         Direction process17 = illliiiilI2.face() != null ? illliiiilI2.face() : Direction.UP;
         this.impactQuads.add(new ImpactQuad(this.adjustImpactPosition(iiIlilIilI2, illliiiilI2), process17, this.withAlpha(n2, f2)));
      }
   }

   private int withScaledAlpha(int n, float f) {
      int n2 = Math.max(0, Math.min(255, Math.round(f * 0.85F * 255.0F)));
      return n2 << 24 | n & 16777215;
   }

   private void renderTrajectory(TrajectoryPrediction prediction, int n, boolean bl, int n2) {
      List<Vec3d> list = prediction.points();
      if (list != null && list.size() >= 2) {
         int n3 = list.size() - 1;
         ArrayList<WorldLineRenderer.Segment> lines = new ArrayList<>(n3);

         for (int i = 0; i < n3; i++) {
            if (i >= n2 && (!bl || i % 2 == 0)) {
               float f = Math.max(bl ? 0.16F : 0.08F, 1.0F - (float)i / n3);
               float f2 = Math.max(bl ? 0.08F : 0.04F, 1.0F - (float)(i + 1) / n3);
               if (bl) {
                  f *= 0.65F;
                  f2 *= 0.65F;
               }

               lines.add(new WorldLineRenderer.Segment(list.get(i), list.get(i + 1), this.withAlpha(n, f), this.withAlpha(n, f2)));
            }
         }

         WorldLineRenderer.draw(this.currentWorldMatrix, lines);
      }
   }

   private Vec3d adjustImpactPosition(ProjectileType iiIlilIilI2, ProjectileImpact illliiiilI2) {
      if (illliiiilI2.hitEntity() != null || illliiiilI2.face() == null) {
         return illliiiilI2.position();
      }

      if (iiIlilIilI2 != ProjectileType.ARROW && iiIlilIilI2 != ProjectileType.CROSSBOW) {
         return illliiiilI2.position();
      }

      Vec3d normal = Vec3d.of(illliiiilI2.face().getVector());
      return illliiiilI2.position().add(normal.multiply(0.018));
   }

   private Vec3d snapPotionImpactToGround(Vec3d vec, Direction process17) {
      double d = process17 == Direction.UP ? vec.y + 0.003 : Math.floor(vec.y) + 0.003;
      return new Vec3d(vec.x, d, vec.z);
   }

   private void queueImpactModel(MinecraftClient mc, ProjectileType iiIlilIilI2, ProjectileImpact illliiiilI2, int n, float f) {
      if (illliiiilI2 != null) {
         if ((iiIlilIilI2 == ProjectileType.ARROW || iiIlilIilI2 == ProjectileType.CROSSBOW) && this.predictionsModule.isClassicArrowStyle()) {
            this.addClassicArrowImpact(mc, iiIlilIilI2, illliiiilI2, n, f);
         } else {
            float f2;
            float f3;
            ModelOrientation orientation;
            LazyMeshModel arrowModel;
            switch (iiIlilIilI2) {
               case TRIDENT:
                  if (!this.tridentModel.isLoaded() || this.tridentModel.getMeshModel() == null || this.tridentModel.getMeshModel().getList().isEmpty()) {
                     return;
                  }

                  arrowModel = this.tridentModel;
                  orientation = this.orientationAlongVelocity(illliiiilI2.velocityDirection());
                  f3 = 0.2F;
                  f2 = 0.5F;
                  break;
               case PEARL:
               case POTION:
                  if (!this.roundProjectileModel.isLoaded()
                     || this.roundProjectileModel.getMeshModel() == null
                     || this.roundProjectileModel.getMeshModel().getList().isEmpty()) {
                     return;
                  }

                  arrowModel = this.roundProjectileModel;
                  float f4 = (float)Math.toDegrees(Math.atan2(illliiiilI2.velocityDirection().x, illliiiilI2.velocityDirection().z)) - 90.0F;
                  orientation = this.orientationFromYawPitch(f4, 90.0F);
                  f3 = 0.3F;
                  f2 = 0.5F;
                  break;
               case ARROW:
               case CROSSBOW:
                  if (!this.arrowModel.isLoaded() || this.arrowModel.getMeshModel() == null || this.arrowModel.getMeshModel().getList().isEmpty()) {
                     return;
                  }

                  arrowModel = this.arrowModel;
                  orientation = this.orientationAlongVelocity(illliiiilI2.velocityDirection());
                  f3 = 0.1F;
                  f2 = 1.0F;
                  break;
               case ITEM:
                  return;
               default:
                  return;
            }

            Vec3d vec = this.trajectoryPredictor.process4(mc.player, f);
            float f5 = this.calculateDistanceFade(vec.distanceTo(illliiiilI2.position()));
            if (!(f5 < 0.02F)) {
               float f6 = this.pulseScale;
               int n2 = illliiiilI2.hitEntity() != null ? -45747 : n;
               Vec3d vec2 = this.adjustImpactPosition(iiIlilIilI2, illliiiilI2);
               this.modelRenderQueue
                  .process7(
                     arrowModel.getMeshModel(),
                     new SpatialTransform(vec2.x, vec2.y, vec2.z, f3 * f6, f3 * f6, f3 * f6, orientation.yaw(), orientation.pitch(), orientation.roll()),
                     this.withScaledAlpha(n2, f5 * f2),
                     ModelRenderOptions.process4(true).process7(this.impactOutlineWidth(f5 * f2)).process10(false)
                  );
            }
         }
      }
   }

   private boolean isOwnedByLocalPlayer(MinecraftClient mc, Entity entity2) {
      if (mc.player == null) {
         return false;
      } else {
         return entity2 instanceof ProjectileEntity projectileEntity ? projectileEntity.getOwner() == mc.player : false;
      }
   }

   private void renderDroppedItemTrajectories(WorldRenderEvent floatTypeEvent2, MinecraftClient mc) {
      if (this.predictionsModule.isItemsEnabled()) {
         for (Entity entity2 : mc.world.getEntities()) {
            TrajectoryPrediction trajectoryPrediction;
            ItemEntity iIIIlIIIII2;
            if (entity2 instanceof ItemEntity
               && (iIIIlIIIII2 = (ItemEntity)entity2).isAlive()
               && !iIIIlIIIII2.isOnGround()
               && !(iIIIlIIIII2.getVelocity().lengthSquared() < 1.0E-5)
               && (trajectoryPrediction = this.trajectoryPredictor.process3(iIIIlIIIII2, floatTypeEvent2.getFloatType())) != null) {
               this.renderTrajectory(trajectoryPrediction, this.predictionsModule.getTrajectoryColor(toProjectileKind(ProjectileType.ITEM), true), true, 0);
            }
         }
      }
   }

   private ModelOrientation orientationFromYawPitch(float f, float f2) {
      return this.matrixToOrientation(this.multiplyMatrices(this.rotationYMatrix(f), this.rotationXMatrix(f2)));
   }

   private ItemStack getProjectileItemStack(Entity entity2) {
      if (entity2 instanceof TridentEntity) {
         return new ItemStack(Items.TRIDENT);
      } else if (entity2 instanceof ThrownItemEntity thrownItemEntity) {
         return thrownItemEntity.getStack();
      } else {
         return entity2 instanceof PersistentProjectileEntity ? new ItemStack(Items.ARROW) : ItemStack.EMPTY;
      }
   }

   private void renderOtherPlayerPredictions(WorldRenderEvent floatTypeEvent2, MinecraftClient mc) {
      for (AbstractClientPlayerEntity player : mc.world.getPlayers()) {
         ItemStack stack;
         ProjectileType iiIlilIilI2;
         if (player != mc.player
            && !(Math.abs(player.getPitch()) > 89.5F)
            && (iiIlilIilI2 = ProjectileType.fromItem((stack = player.getMainHandStack()).getItem())) != null
            && this.predictionsModule.shouldShowTrajectory(toProjectileKind(iiIlilIilI2), false)) {
            for (TrajectoryPrediction trajectoryPrediction : this.trajectoryPredictor.process(player, stack, floatTypeEvent2.getFloatType())) {
               ProjectileImpact illliiiilI2 = trajectoryPrediction.impact();
               if (illliiiilI2 != null) {
                  this.queueImpactModel(
                     mc,
                     iiIlilIilI2,
                     illliiiilI2,
                     this.predictionsModule.getTrajectoryColor(toProjectileKind(iiIlilIilI2), false),
                     floatTypeEvent2.getFloatType()
                  );
               }
            }
         }
      }
   }

   private void clearFrameData() {
      this.potionImpactMarkers.clear();
      this.landingPredictions.clear();
      this.impactQuads.clear();
   }

   private Vec3d toVec3d() {
      return RenderCamera.position() != null ? RenderCamera.position() : Vec3d.ZERO;
   }

   private boolean isLivingTarget(Entity entity2) {
      return entity2 != null && entity2.isAlive() && entity2 != MinecraftClient.getInstance().player
         ? entity2 instanceof PlayerEntity || entity2 instanceof MobEntity
         : false;
   }

   private float calculateDistanceFade(double d) {
      float f = (float)MathHelper.clamp((d - 0.5) / 13.5, 0.0, 1.0);
      return Math.min(f * f * (3.0F - 2.0F * f) * 2.5F, 1.0F);
   }

   private void renderHeldItemPredictions(WorldRenderEvent floatTypeEvent2, MinecraftClient mc) {
      if (!(Math.abs(mc.player.getPitch()) > 89.5F)) {
         ItemStack stack = getTrackedHeldStack(this.predictionsModule, mc.player);
         if (!stack.isEmpty()) {
            ProjectileType iiIlilIilI2 = ProjectileType.fromItem(stack.getItem());
            if (iiIlilIilI2 != null) {
               List<TrajectoryPrediction> list = this.trajectoryPredictor.process(mc.player, stack, floatTypeEvent2.getFloatType());
               boolean bl = !mc.options.getPerspective().isFirstPerson();

               for (TrajectoryPrediction trajectoryPrediction : list) {
                  if (this.predictionsModule.showHeldItems()) {
                     this.renderTrajectory(
                        trajectoryPrediction, this.predictionsModule.getTrajectoryColor(toProjectileKind(iiIlilIilI2), true), false, bl ? 10 : 0
                     );
                  }

                  ProjectileImpact illliiiilI2;
                  if ((illliiiilI2 = trajectoryPrediction.impact()) != null) {
                     if (iiIlilIilI2 == ProjectileType.POTION) {
                        Vec3d vec = this.snapPotionImpactToGround(illliiiilI2.position(), illliiiilI2.face());
                        this.potionImpactMarkers
                           .add(new PotionImpactMarker(vec, this.predictionsModule.getTrajectoryColor(toProjectileKind(iiIlilIilI2), true)));
                        this.addPotionImpactBox(vec);
                     } else {
                        this.markHitEntity(illliiiilI2);
                        if (this.predictionsModule.shouldShowTrajectory(toProjectileKind(iiIlilIilI2), true)) {
                           this.queueImpactModel(
                              mc,
                              iiIlilIilI2,
                              illliiiilI2,
                              this.predictionsModule.getTrajectoryColor(toProjectileKind(iiIlilIilI2), true),
                              floatTypeEvent2.getFloatType()
                           );
                        } else {
                           this.renderCircularImpactMarker(illliiiilI2.position(), illliiiilI2.face(), illliiiilI2.hitEntity());
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private double clampUnit(double d) {
      return Math.max(-1.0, Math.min(1.0, d));
   }

   private void updatePotionDepthSampler() {
      if (this.predictionsModule.isModuleEnabled() && this.predictionsModule.isPotionsEnabled() && !this.potionImpactMarkers.isEmpty()) {
         if (RenderCamera.position() != null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world != null && mc.player != null) {
               this.depthSampler.setList(this.potionImpactMarkers);
            }
         }
      }
   }

   private ModelOrientation matrixToOrientation(double[][] dArray) {
      double d = Math.asin(this.clampUnit(-dArray[1][2]));
      double d2 = Math.atan2(dArray[1][0], dArray[1][1]);
      double d3 = Math.atan2(dArray[0][2], dArray[2][2]);
      return new ModelOrientation((float)Math.toDegrees(d3), (float)Math.toDegrees(d), (float)Math.toDegrees(d2));
   }

   private void queuePotionEffectVolumes(WorldRenderEvent floatTypeEvent2, MinecraftClient mc) {
      if (this.predictionsModule.isPotionsEnabled() && !this.potionImpactMarkers.isEmpty()) {
         for (PotionImpactMarker marker : this.potionImpactMarkers) {
            this.queuePotionAffectedEntityBoxes(mc, marker.position(), marker.color(), floatTypeEvent2.getFloatType());
         }
      }
   }

   private double[][] multiplyMatrices(double[][] dArray, double[][] dArray2) {
      double[][] dArray3 = new double[3][3];

      for (int i = 0; i < 3; i++) {
         for (int j = 0; j < 3; j++) {
            dArray3[i][j] = dArray[i][0] * dArray2[0][j] + dArray[i][1] * dArray2[1][j] + dArray[i][2] * dArray2[2][j];
         }
      }

      return dArray3;
   }

   public static PredictionsModule.ProjectileKind toProjectileKind(ProjectileType type) {
      if (type == null) {
         return PredictionsModule.ProjectileKind.UNKNOWN;
      }

      return switch (type) {
         case TRIDENT -> PredictionsModule.ProjectileKind.TRIDENT;
         case PEARL -> PredictionsModule.ProjectileKind.PEARL;
         case POTION -> PredictionsModule.ProjectileKind.POTION;
         case ARROW -> PredictionsModule.ProjectileKind.ARROW;
         case CROSSBOW -> PredictionsModule.ProjectileKind.CROSSBOW;
         case ITEM -> PredictionsModule.ProjectileKind.ITEM;
      };
   }

   public static ItemStack getTrackedHeldStack(PredictionsModule module, PlayerEntity player) {
      if (player == null) {
         return ItemStack.EMPTY;
      }

      Item mainItem = player.getMainHandStack().getItem();
      if (module.isHeldItemCategoryEnabled(toProjectileKind(ProjectileType.fromItem(mainItem)))) {
         return player.getMainHandStack();
      }

      Item offItem = player.getOffHandStack().getItem();
      return module.isHeldItemCategoryEnabled(toProjectileKind(ProjectileType.fromItem(offItem))) ? player.getOffHandStack() : ItemStack.EMPTY;
   }

   private boolean shouldTrackEntity(Entity entity) {
      ProjectileType type = ProjectileType.fromEntity(entity);
      if (type != null && type != ProjectileType.ITEM) {
         if (entity instanceof TridentEntity slowEntity && slowEntity.getVelocity().lengthSquared() < 1.0E-7) {
            return false;
         } else {
            PredictionsModule.ProjectileKind kind = toProjectileKind(type);

            return switch (kind) {
               case TRIDENT -> this.predictionsModule.isTridentEnabled();
               case PEARL -> this.predictionsModule.isPearlEnabled();
               case ARROW -> this.predictionsModule.isArrowEnabled() || this.predictionsModule.isCrossbowEnabled();
               case POTION -> this.predictionsModule.isPotionsEnabled();
               case CROSSBOW, ITEM, UNKNOWN -> false;
            };
         }
      } else {
         return false;
      }
   }

   private int getEntityTrajectoryColor(Entity entity, boolean self) {
      ProjectileType type = ProjectileType.fromEntity(entity);
      return type == ProjectileType.ARROW && !this.predictionsModule.isArrowEnabled() && this.predictionsModule.isCrossbowEnabled()
         ? this.predictionsModule.getTrajectoryColor(PredictionsModule.ProjectileKind.CROSSBOW, self)
         : this.predictionsModule.getTrajectoryColor(toProjectileKind(type), self);
   }
}
