package ru.wexside.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.wexside.event.TotemPopEvent;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.TotemEffectRenderer;
import ru.wexside.render.BoxEspRenderer;

public final class TotemGhostRenderer implements TotemEffectRenderer {
   private static final long LIFETIME_MS = 900L;
   private static final int LAYERS = 3;
   private static final int MAX_GHOSTS = 16;
   private static final Vec3d FALLBACK_LOOK = new Vec3d(0.0, 0.0, 1.0);
   private final List<TotemGhostRenderer.TotemGhost> ghosts = new ArrayList<>();
   private final TotemEffectSettings settings;

   public TotemGhostRenderer(TotemEffectSettings settings) {
      this.settings = settings;
   }

   @Override
   public void renderWorld(WorldRenderEvent event) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world == null || client.player == null) {
         this.update2();
      } else if (!this.ghosts.isEmpty()) {
         Camera camera = client.gameRenderer.getCamera();
         Vec3d cameraPosition = camera.getCameraPos();
         Matrix4f matrix = event != null && event.getMatrices() != null ? new Matrix4f(event.getMatrices().peek().getPositionMatrix()) : new Matrix4f();
         long now = System.currentTimeMillis();
         Iterator<TotemGhostRenderer.TotemGhost> iterator = this.ghosts.iterator();

         while (iterator.hasNext()) {
            TotemGhostRenderer.TotemGhost ghost = iterator.next();
            if (now - ghost.spawnedAt() >= 900L) {
               iterator.remove();
            }
         }

         if (!this.ghosts.isEmpty()) {
            Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
            RenderLayer fillLayer = RenderLayers.debugQuads();
            RenderLayer outlineLayer = RenderLayers.linesTranslucent();
            VertexConsumer fill = consumers.getBuffer(fillLayer);

            for (TotemGhostRenderer.TotemGhost ghost : this.ghosts) {
               this.drawGhostFill(ghost, now, cameraPosition, matrix, fill);
            }

            consumers.draw(fillLayer);
            VertexConsumer outline = consumers.getBuffer(outlineLayer);

            for (TotemGhostRenderer.TotemGhost ghost : this.ghosts) {
               this.drawGhostOutline(ghost, now, cameraPosition, matrix, outline);
            }

            consumers.draw(outlineLayer);
         }
      }
   }

   private void drawGhostFill(TotemGhostRenderer.TotemGhost ghost, long now, Vec3d camera, Matrix4f matrix, VertexConsumer fill) {
      float progress = MathHelper.clamp((float)(now - ghost.spawnedAt()) / 900.0F, 0.0F, 1.0F);
      int baseColor = this.settings.getIntType3();
      Vec3d side = ghost.look().lengthSquared() > 1.0E-6 ? new Vec3d(-ghost.look().z, 0.0, ghost.look().x).normalize() : new Vec3d(1.0, 0.0, 0.0);

      for (int layer = 2; layer >= 0; layer--) {
         float layerDelay = layer * 0.08F;
         if (!(progress < layerDelay)) {
            float delayed = Math.max(0.0F, (progress - layerDelay) / (1.0F - layerDelay));
            float fade = (1.0F - delayed) * (1.0F - delayed) * (1.0F - layer * 0.18F);
            if (!(fade <= 0.025F)) {
               float eased = easeOutCubic(delayed);
               double travel = 0.16 + eased * 0.7 + layer * 0.08;
               double wobble = Math.sin(ghost.phase() + delayed * Math.PI * 2.0 + layer * 0.35) * 0.08;
               double rise = 0.16 + sineIn(delayed) * 0.56 + layer * 0.03;
               Vec3d position = ghost.origin().add(ghost.look().multiply(travel)).add(side.multiply(wobble)).add(0.0, rise, 0.0);
               float scale = 1.0F + (1.0F - delayed) * 0.06F + layer * 0.012F;
               Box box = box(position, ghost.width(), ghost.height(), scale);
               BoxEspRenderer.fill(fill, matrix, camera, box, withAlpha(baseColor, Math.round(107.0F * fade)));
            }
         }
      }
   }

   private void drawGhostOutline(TotemGhostRenderer.TotemGhost ghost, long now, Vec3d camera, Matrix4f matrix, VertexConsumer outline) {
      float progress = MathHelper.clamp((float)(now - ghost.spawnedAt()) / 900.0F, 0.0F, 1.0F);
      int baseColor = this.settings.getIntType3();
      Vec3d side = ghost.look().lengthSquared() > 1.0E-6 ? new Vec3d(-ghost.look().z, 0.0, ghost.look().x).normalize() : new Vec3d(1.0, 0.0, 0.0);

      for (int layer = 2; layer >= 0; layer--) {
         float layerDelay = layer * 0.08F;
         if (!(progress < layerDelay)) {
            float delayed = Math.max(0.0F, (progress - layerDelay) / (1.0F - layerDelay));
            float fade = (1.0F - delayed) * (1.0F - delayed) * (1.0F - layer * 0.18F);
            if (!(fade <= 0.025F)) {
               float eased = easeOutCubic(delayed);
               double travel = 0.16 + eased * 0.7 + layer * 0.08;
               double wobble = Math.sin(ghost.phase() + delayed * Math.PI * 2.0 + layer * 0.35) * 0.08;
               double rise = 0.16 + sineIn(delayed) * 0.56 + layer * 0.03;
               Vec3d position = ghost.origin().add(ghost.look().multiply(travel)).add(side.multiply(wobble)).add(0.0, rise, 0.0);
               float scale = 1.0F + (1.0F - delayed) * 0.06F + layer * 0.012F;
               Box box = box(position, ghost.width(), ghost.height(), scale);
               BoxEspRenderer.outline(outline, matrix, camera, box, withAlpha(baseColor, Math.round(230.0F * fade)));
            }
         }
      }
   }

   @Override
   public void setTotemPopEvent(TotemPopEvent event) {
      if (event.getEntity() instanceof PlayerEntity player) {
         MinecraftClient client = MinecraftClient.getInstance();
         Vec3d look = client.player == null ? FALLBACK_LOOK : client.player.getRotationVec(1.0F);
         if (look.lengthSquared() <= 1.0E-6) {
            look = FALLBACK_LOOK;
         }

         Box bounds = player.getBoundingBox();
         this.ghosts
            .add(
               new TotemGhostRenderer.TotemGhost(
                  event.toVec3d(),
                  look.normalize(),
                  bounds.maxX - bounds.minX,
                  player.getHeight(),
                  event.getLongType(),
                  ThreadLocalRandom.current().nextFloat() * (float) (Math.PI * 2)
               )
            );
         int overflow = this.ghosts.size() - 16;
         if (overflow > 0) {
            this.ghosts.subList(0, overflow).clear();
         }
      }
   }

   @Override
   public void update2() {
      this.ghosts.clear();
   }

   private static Box box(Vec3d position, double width, double height, float scale) {
      double halfWidth = width * scale * 0.5;
      return new Box(position.x - halfWidth, position.y, position.z - halfWidth, position.x + halfWidth, position.y + height * scale, position.z + halfWidth);
   }

   private static float sineIn(float value) {
      return (float)Math.sin(MathHelper.clamp(value, 0.0F, 1.0F) * Math.PI * 0.5);
   }

   private static float easeOutCubic(float value) {
      float inverse = 1.0F - MathHelper.clamp(value, 0.0F, 1.0F);
      return 1.0F - inverse * inverse * inverse;
   }

   private static int withAlpha(int color, int alpha) {
      return color & 16777215 | Math.clamp(alpha, 0, 255) << 24;
   }

   private record TotemGhost(Vec3d origin, Vec3d look, double width, double height, long spawnedAt, float phase) {
   }
}
