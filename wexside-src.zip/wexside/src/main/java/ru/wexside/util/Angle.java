package ru.wexside.util;

import java.util.Objects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Angle {
   public static final Angle ZERO;
   public static final Angle angle = ZERO = new Angle(0.0F, 0.0F);
   private final float yaw;
   private final float pitch;

   public Angle(float yaw, float pitch) {
      this.yaw = yaw;
      this.pitch = pitch;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }

   public float getFloatType() {
      return this.yaw;
   }

   public float getFloatType2() {
      return this.pitch;
   }

   @Override
   public boolean equals(Object clipToSpace) {
      if (this == clipToSpace) {
         return true;
      } else {
         return !(clipToSpace instanceof Angle other) ? false : Float.compare(this.yaw, other.yaw) == 0 && Float.compare(this.pitch, other.pitch) == 0;
      }
   }

   @Override
   public String toString() {
      return "Angle[yaw=" + this.yaw + ", pitch=" + this.pitch + "]";
   }

   @Override
   public int hashCode() {
      return Objects.hash(this.yaw, this.pitch);
   }

   public static Angle fromVectors(Vec3d from, Vec3d to) {
      return fromDelta(to.subtract(from));
   }

   public Vec3d toVec3d() {
      float degToRad = (float) (Math.PI / 180.0);
      float yawRad = -this.yaw * degToRad;
      float pitchRad = this.pitch * degToRad;
      float yawCos = MathHelper.cos(yawRad);
      float yawSin = MathHelper.sin(yawRad);
      float pitchCos = MathHelper.cos(pitchRad);
      float pitchSin = MathHelper.sin(pitchRad);
      return new Vec3d(yawSin * pitchCos, -pitchSin, yawCos * pitchCos);
   }

   public float process(Angle other) {
      Angle delta = this.process4(other);
      return (float)Math.hypot(delta.yaw, delta.pitch);
   }

   public static Angle process2(Vec3d from, LivingEntity entity) {
      Vec3d to = entity.getRotationVec(1.0F).add(0.0, -0.4, 0.0);
      return fromVectors(from, to);
   }

   public static Angle process3(Vec3d delta) {
      return fromDelta(delta);
   }

   public static Angle fromDelta(Vec3d delta) {
      double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
      float yaw = (float)(Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
      float pitch = (float)(-Math.toDegrees(Math.atan2(delta.y, horizontal)));
      return new Angle(yaw, pitch);
   }

   public Angle process4(Angle other) {
      float yawDelta = MathHelper.wrapDegrees(other.yaw - this.yaw);
      float pitchDelta = MathHelper.wrapDegrees(other.pitch - this.pitch);
      return new Angle(yawDelta, pitchDelta);
   }

   public Angle getAngle() {
      return new Angle(this.yaw, MathHelper.clamp(this.pitch, -90.0F, 90.0F));
   }
}
