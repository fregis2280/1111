package ru.wexside.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.LookAndOnGround;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.math.MathHelper;
import ru.wexside.event.ClientTickEvent;
import ru.wexside.event.EventBus;
import ru.wexside.event.IncomingPacketEvent;
import ru.wexside.event.OutgoingPacketEvent;
import ru.wexside.misc.RotationApplyResult;
import ru.wexside.misc.RotationStrategy;
import ru.wexside.misc.RotationStrategyFactory;

public class RotationController {
   static final int slot = 4;
   private float value = 90.0F;
   private boolean enabled;
   private Angle field40;
   private RotationStrategy field44;
   private int slot2;
   private String field48;
   private float value2 = 90.0F;
   private Angle field52;
   private Angle field56;
   private float value3 = 90.0F;
   private boolean enabled2 = true;
   private Angle field60;
   private int slot3;
   private boolean process = true;
   private int slot4;
   private RotationIntent field64 = RotationIntent.empty();
   private final RotationStrategyFactory field68;
   private boolean enabled3;

   private void setAspectRatioEvent12(OutgoingPacketEvent gameEvent12) {
      Packet<?> packet2 = gameEvent12.getPacket();
      LookAndOnGround lookAndOnGround;
      if (packet2 instanceof LookAndOnGround && (lookAndOnGround = (LookAndOnGround)packet2).changesLook()) {
         this.field60 = new Angle(lookAndOnGround.getYaw(0.0F), lookAndOnGround.getPitch(0.0F));
      }
   }

   public float getFloatType() {
      this.update6();
      return this.value;
   }

   public Float getFloatType2() {
      if (this.slot2 > 0) {
         return null;
      }

      this.update6();
      return this.enabled2 ? this.value2 : null;
   }

   public boolean isActive() {
      return this.field56 != null;
   }

   public void update() {
      this.slot3 = 0;
   }

   public boolean isAvailable() {
      return this.field56 != null;
   }

   public void update2() {
      this.slot4 = 0;
   }

   public Angle getAngle() {
      return this.field56;
   }

   public float getYaw() {
      return this.field56 != null
         ? this.field56.getYaw()
         : (MinecraftClient.getInstance().player != null ? MinecraftClient.getInstance().player.getYaw() : 0.0F);
   }

   public float getPitch() {
      return this.field56 != null
         ? this.field56.getPitch()
         : (MinecraftClient.getInstance().player != null ? MinecraftClient.getInstance().player.getPitch() : 0.0F);
   }

   public int slot5() {
      return this.slot4;
   }

   public void update3() {
      if (this.field44 != null) {
         RotationState iIiIlIIliI2 = this.process5(this.field64);
         this.field44.onDeactivated(iIiIlIIliI2);
      }

      this.field56 = null;
      this.field40 = null;
      this.field52 = null;
      this.field64 = RotationIntent.empty();
   }

   public RotationApplyResult apply(RotationIntent intent, String rotationMode) {
      return this.process2(intent, rotationMode);
   }

   public void reset() {
      this.update3();
   }

   public void markAttacked() {
      this.update();
   }

   public void notifyHit() {
      this.update2();
   }

   public boolean hasRotation() {
      return this.field56 != null;
   }

   public int ticksSinceHit() {
      return this.slot5();
   }

   public RotationIntent getIntent() {
      return this.field64;
   }

   public RotationApplyResult process2(RotationIntent intent2, String string) {
      this.setString(string);
      this.field64 = intent2;
      RotationState iIiIlIIliI2 = this.process5(intent2);
      RotationApplyResult rotationApplyResult = this.field44.process(iIiIlIIliI2, intent2);
      this.field40 = this.field56;
      this.field56 = this.process4(rotationApplyResult.angle(), iIiIlIIliI2.getPlayerAngle());
      return rotationApplyResult;
   }

   public boolean process3(float f, float f2) {
      return this.process && Math.abs(this.value3 - f) <= f2;
   }

   public RotationIntent empty() {
      return this.field64;
   }

   public void update4() {
      this.enabled = false;
   }

   public void update5() {
      this.enabled = true;
   }

   private void member2527(ClientTickEvent gameEvent6) {
      this.update7();
   }

   private void update6() {
      if (!this.enabled3) {
         ClientPlayerEntity player2 = MinecraftClient.getInstance().player;
         if (player2 != null) {
            this.enabled3 = true;
            float f = player2.getYaw();
            float f2 = player2.getPitch();
            if (!this.enabled2) {
               this.value2 = f;
               this.value = f2;
               this.enabled2 = true;
            }

            float f3 = this.field56 != null ? this.field56.getFloatType() : f;
            float f4 = this.field56 != null ? this.field56.getFloatType2() : f2;
            this.value2 = this.value2 + MathHelper.wrapDegrees(f3 - this.value2);
            this.value = f4;
         }
      }
   }

   private void setString(String string) {
      if (this.field44 == null || !string.equals(this.field48)) {
         if (this.field44 != null) {
            this.field44.onDeactivated(this.process5(this.field64));
         }

         this.field44 = this.field68.process(string);
         this.field48 = string;
         this.field44.onActivated(this.process5(this.field64));
      }
   }

   private void setAspectRatioEvent5(IncomingPacketEvent gameEvent5) {
      if (gameEvent5.getPacket() instanceof PlayerPositionLookS2CPacket positionPacket) {
         this.field60 = new Angle(positionPacket.change().yaw(), positionPacket.change().pitch());
         this.enabled2 = false;
         this.slot2 = 4;
      }
   }

   private Angle process4(Angle angle, Angle angle2) {
      if (angle == null) {
         return null;
      }

      Angle angle3 = this.field56 != null ? this.field56 : angle2;
      if (angle3 == null) {
         return angle;
      }

      Angle angle5 = angle3.process4(angle);
      float f = angle3.getFloatType() + MathHelper.wrapDegrees(angle5.getFloatType());
      float f2 = MathHelper.clamp(angle3.getFloatType2() + MathHelper.wrapDegrees(angle5.getFloatType2()), -90.0F, 90.0F);
      return new Angle(f, f2);
   }

   private RotationState process5(RotationIntent intent2) {
      ClientPlayerEntity player2 = MinecraftClient.getInstance().player;
      Angle angle = player2 != null ? new Angle(player2.getYaw(), player2.getPitch()) : Angle.angle;
      float f = player2 != null ? player2.getAttackCooldownProgress(0.0F) : 0.0F;
      boolean bl = f >= 0.9F;
      return new RotationState(this.field56, this.field40, this.field60, angle, intent2.target(), intent2.aimPoint(), this.slot3, this.slot4, f, bl);
   }

   private void update7() {
      if (this.slot2 > 0) {
         this.slot2--;
      }

      this.enabled3 = false;
      this.slot3++;
      this.slot4++;
      ClientPlayerEntity player2;
      this.field52 = this.field56 != null
         ? this.field56
         : ((player2 = MinecraftClient.getInstance().player) != null ? new Angle(player2.getYaw(), player2.getPitch()) : null);
   }

   public void onTick(float f) {
      this.value3 = f;
      this.process = true;
   }

   public RotationController(RotationStrategyFactory callback35, EventBus eventBus) {
      this.field68 = callback35;
      eventBus.subscribe(ClientTickEvent.class, ignored -> this.update7());
      eventBus.subscribe(IncomingPacketEvent.class, this::setAspectRatioEvent5);
      eventBus.subscribe(OutgoingPacketEvent.class, this::setAspectRatioEvent12);
   }
}
