package ru.wexside.util;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import ru.wexside.misc.ModelSurfaceMode;
import ru.wexside.render.ModelRenderBatch;

public final class WorldMeshBatchRenderer {
   public WorldMeshBatchRenderer(String debugName) {
   }

   public void process10(MatrixStack matrices, Immediate consumers, Vec3d cameraPosition, ModelRenderQueue queue) {
      if (matrices != null && consumers != null && queue != null && !queue.isActive()) {
         Vec3d camera = cameraPosition != null ? cameraPosition : Vec3d.ZERO;
         RenderLayer fillLayer = RenderLayers.debugQuads();
         RenderLayer outlineLayer = RenderLayers.lines();
         VertexConsumer fill = consumers.getBuffer(fillLayer);
         boolean hasFill = false;

         for (ModelRenderBatch batch : queue.getBatches()) {
            ModelRenderOptions options = batch.options();
            if (options.getModelSurfaceMode() != ModelSurfaceMode.HIDDEN) {
               Matrix4f base = new Matrix4f(matrices.peek().getPositionMatrix())
                  .translate((float)(batch.x() - camera.x), (float)(batch.y() - camera.y), (float)(batch.z() - camera.z));

               for (int i = 0; i < batch.meshes().size(); i++) {
                  InlineMesh mesh = batch.meshes().get(i);
                  Matrix4f model = new Matrix4f(base);
                  if (batch.transforms() != null && i < batch.transforms().length && batch.transforms()[i] != null) {
                     model.mul(batch.transforms()[i]);
                  }

                  emitTriangles(fill, model, mesh, batch.color());
                  hasFill = true;
               }
            }
         }

         if (hasFill) {
            consumers.draw(fillLayer);
         }

         boolean hasOutline = false;
         VertexConsumer outline = consumers.getBuffer(outlineLayer);

         for (ModelRenderBatch batch : queue.getBatches()) {
            ModelRenderOptions options = batch.options();
            if (options.getModelSurfaceMode() != ModelSurfaceMode.HIDDEN && options.isActive3()) {
               Matrix4f base = new Matrix4f(matrices.peek().getPositionMatrix())
                  .translate((float)(batch.x() - camera.x), (float)(batch.y() - camera.y), (float)(batch.z() - camera.z));

               for (int i = 0; i < batch.meshes().size(); i++) {
                  InlineMesh mesh = batch.meshes().get(i);
                  Matrix4f model = new Matrix4f(base);
                  if (batch.transforms() != null && i < batch.transforms().length && batch.transforms()[i] != null) {
                     model.mul(batch.transforms()[i]);
                  }

                  emitOutline(outline, model, mesh, options.process8(batch.outlineColor()), options.getFloatType());
                  hasOutline = true;
               }
            }
         }

         if (hasOutline) {
            consumers.draw(outlineLayer);
         }
      }
   }

   private static void emitTriangles(VertexConsumer output, Matrix4f matrix, InlineMesh mesh, int color) {
      float[] positions = mesh.getFloatType();
      int[] indices = mesh.getIntType2();
      if (positions != null) {
         if (indices == null) {
            for (int vertex = 0; vertex < positions.length / 3; vertex++) {
               emitFillVertex(output, matrix, positions, vertex, color);
            }
         } else {
            for (int vertex : indices) {
               emitFillVertex(output, matrix, positions, vertex, color);
            }
         }
      }
   }

   private static void emitOutline(VertexConsumer output, Matrix4f matrix, InlineMesh mesh, int color, float lineWidth) {
      float[] positions = mesh.getFloatType();
      int[] edges = mesh.getIntType();
      if (positions != null && edges != null) {
         for (int i = 0; i + 1 < edges.length; i += 2) {
            int v0 = edges[i];
            int v1 = edges[i + 1];
            int o0 = v0 * 3;
            int o1 = v1 * 3;
            if (o0 >= 0 && o0 + 2 < positions.length && o1 >= 0 && o1 + 2 < positions.length) {
               float dx = positions[o1] - positions[o0];
               float dy = positions[o1 + 1] - positions[o0 + 1];
               float dz = positions[o1 + 2] - positions[o0 + 2];
               float len = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
               if (len > 0.0F) {
                  dx /= len;
                  dy /= len;
                  dz /= len;
               }

               Vector3f normal = matrix.transformDirection(new Vector3f(dx, dy, dz)).normalize();
               output.vertex(matrix, positions[o0], positions[o0 + 1], positions[o0 + 2])
                  .color(color)
                  .normal(normal.x, normal.y, normal.z)
                  .lineWidth(lineWidth);
               output.vertex(matrix, positions[o1], positions[o1 + 1], positions[o1 + 2])
                  .color(color)
                  .normal(normal.x, normal.y, normal.z)
                  .lineWidth(lineWidth);
            }
         }
      }
   }

   private static void emitFillVertex(VertexConsumer output, Matrix4f matrix, float[] positions, int vertex, int color) {
      int offset = vertex * 3;
      if (offset >= 0 && offset + 2 < positions.length) {
         output.vertex(matrix, positions[offset], positions[offset + 1], positions[offset + 2]).color(color);
      }
   }
}
