package ru.wexside.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import ru.wexside.misc.AttackOptions;
import ru.wexside.misc.HitCooldown;
import ru.wexside.misc.Inventories;
import ru.wexside.misc.MaceCheck;
import ru.wexside.misc.ReachHelper;
import ru.wexside.misc.ShieldDesync;

public class AuraProcessor {
   private final HitCooldown hitCooldown = new HitCooldown();
   private final CriticalsHandler criticals;
   private boolean enabled;
   private final MaceCheck maceCheck;
   private final ShieldDesync shieldDesync = new ShieldDesync();

   public AuraProcessor(CriticalsHandler criticals) {
      this.maceCheck = new MaceCheck();
      this.criticals = criticals;
   }

   public boolean attack(LivingEntity target, AttackOptions options) {
      return this.process(target, options);
   }

   public void tick() {
      this.update();
   }

   public boolean process(LivingEntity entity2, AttackOptions iliiiillII2) {
      if (entity2 != null && !this.enabled) {
         ClientPlayerEntity player2 = MinecraftClient.getInstance().player;
         if (player2 == null) {
            return false;
         }

         if (!this.process2(entity2, iliiiillII2)) {
            return false;
         }

         this.shieldDesync.setMode(iliiiillII2.sprintResetMode());
         boolean bl = player2.isSprinting() && !player2.isUsingItem();
         if (iliiiillII2.sprintResetEnabled()) {
            this.shieldDesync.prepareForAttack();
            if (this.shieldDesync.delaysAttackUntilSprintStops() && bl) {
               this.enabled = true;
               return false;
            }
         }

         if (iliiiillII2.desyncShield()) {
            this.releaseShieldUse(player2);
         }

         int n2 = -1;
         if (iliiiillII2.breakShield() && entity2.isBlocking()) {
            int n = Inventories.findAxeSlot();
            int n3 = player2.getInventory().getSelectedSlot();
            if (n != -1 && n != n3) {
               n2 = n3;
               player2.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(n));
            }
         }

         int n = iliiiillII2.accuracyPercent() < 100.0 && Math.random() * 100.0 > iliiiillII2.accuracyPercent() ? 1 : 0;
         if (n != 0) {
            player2.swingHand(Hand.MAIN_HAND);
         } else {
            MinecraftClient.getInstance().interactionManager.attackEntity(player2, entity2);
            player2.swingHand(Hand.MAIN_HAND);
         }

         if (n2 != -1) {
            player2.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(n2));
         }

         if (iliiiillII2.sprintResetEnabled()) {
            this.shieldDesync.restoreSprint();
         }

         long l = iliiiillII2.legacyCombat() ? Math.max(50L, 1000L / Math.max(1, iliiiillII2.clicksPerSecond())) : 500L;
         this.hitCooldown.setLongType(l);
         return n == 0;
      } else {
         return false;
      }
   }

   public HitCooldown getHitCooldown() {
      return this.hitCooldown;
   }

   public void update() {
      this.enabled = false;
   }

   public MaceCheck getMaceCheck() {
      return this.maceCheck;
   }

   private void releaseShieldUse(ClientPlayerEntity player2) {
      if (player2.getOffHandStack().isOf(Items.SHIELD)) {
         if (player2.isUsingItem()) {
            player2.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Direction.DOWN));
         }
      }
   }

   public ShieldDesync getShieldDesync() {
      return this.shieldDesync;
   }

   private boolean process2(LivingEntity entity2, AttackOptions iliiiillII2) {
      if (iliiiillII2.raycastEnabled() && !this.process3(entity2, iliiiillII2.lookAngle(), iliiiillII2.range(), iliiiillII2.allowsThroughWalls())) {
         return false;
      } else {
         ClientPlayerEntity player2 = MinecraftClient.getInstance().player;
         if (player2 != null && this.maceCheck.process(player2)) {
            return this.maceCheck.process2(player2, this.hitCooldown, iliiiillII2.maceFallDistance(), iliiiillII2.legacyCombat());
         } else {
            return !this.hitCooldown.process(iliiiillII2.legacyCombat())
               ? false
               : this.criticals.process(iliiiillII2.criticalsOnly(), iliiiillII2.jumpOnly(), iliiiillII2.raycastMode());
         }
      }
   }

   private boolean process3(LivingEntity entity2, Angle angle, float f, boolean bl) {
      return angle == null ? false : ReachHelper.raycastEntity(entity2, angle, f, bl) == entity2;
   }
}
