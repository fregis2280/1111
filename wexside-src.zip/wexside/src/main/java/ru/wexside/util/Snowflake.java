package ru.wexside.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import ru.wexside.event.TotemPopEvent;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.SpriteAtlasRegion;
import ru.wexside.misc.TotemEffectRenderer;
import ru.wexside.misc.WexsideHitParticles;
import ru.wexside.render.ParticleBillboardRenderer;

public final class Snowflake implements TotemEffectRenderer {
   private static final double FIXED_STEP = 0.016666666666666666;
   private final List<Snowflake.TotemParticle> particles = new ArrayList<>();
   private final TotemEffectSettings settings;
   private long previousFrameNanos;
   private double pendingTicks;

   public Snowflake(TotemEffectSettings settings) {
      this.settings = settings;
   }

   private void renderParticles(float tickDelta) {
      for (Snowflake.TotemParticle particle : this.particles) {
         if (!(particle.alpha <= 0.02F)) {
            double x = MathHelper.lerp(tickDelta, particle.previousPosition.x, particle.position.x);
            double y = MathHelper.lerp(tickDelta, particle.previousPosition.y, particle.position.y);
            double z = MathHelper.lerp(tickDelta, particle.previousPosition.z, particle.position.z);
            SpriteAtlasRegion sprite = particle.style.texture().getSpriteAtlasRegion();
            int color = ColorUtils.withAlpha(particle.color, MathHelper.clamp((int)((particle.color >>> 24 & 0xFF) * particle.alpha), 0, 255));
            ParticleBillboardRenderer.draw(
               x,
               y,
               z,
               particle.size,
               particle.size,
               color,
               WexsideHitParticles.getParticleTexture(),
               false,
               particle.initialRotation + particle.rotationSpeed * particle.age,
               sprite.minU(),
               sprite.minV(),
               sprite.maxU(),
               sprite.maxV()
            );
         }
      }
   }

   private Snowflake.ParticleStyle selectedStyle() {
      return switch (this.settings.getString()) {
         case "Mini-star" -> new Snowflake.ParticleStyle(WexsideHitParticles.STAR, 0.7F);
         case "Snowflake" -> new Snowflake.ParticleStyle(WexsideHitParticles.SNOWFLAKE, 1.0F);
         case "Dollar" -> new Snowflake.ParticleStyle(WexsideHitParticles.DOLLAR, 1.0F);
         case "Cross" -> new Snowflake.ParticleStyle(WexsideHitParticles.CROSS, 1.0F);
         default -> new Snowflake.ParticleStyle(WexsideHitParticles.STAR, 1.0F);
      };
   }

   private Vec3d randomVelocity(ThreadLocalRandom random) {
      double speed = this.settings.getDoubleType();
      if (this.settings.isActive()) {
         return new Vec3d(random.nextDouble(-speed, speed), random.nextDouble(-speed, speed + 0.2), random.nextDouble(-speed, speed));
      }

      double azimuth = random.nextDouble() * Math.PI * 2.0;
      double polar = random.nextDouble() * Math.PI;
      return new Vec3d(speed * Math.cos(azimuth) * Math.sin(polar), speed * Math.cos(polar) + 0.05, speed * Math.sin(azimuth) * Math.sin(polar));
   }

   private double frameSeconds() {
      long now = System.nanoTime();
      if (this.previousFrameNanos == 0L) {
         this.previousFrameNanos = now;
         return 0.016666666666666666;
      } else {
         double seconds = (now - this.previousFrameNanos) / 1.0E9;
         this.previousFrameNanos = now;
         return Math.clamp(seconds, 0.0, 0.05);
      }
   }

   private void simulate(MinecraftClient client) {
      Iterator<Snowflake.TotemParticle> iterator = this.particles.iterator();

      while (iterator.hasNext()) {
         Snowflake.TotemParticle particle = iterator.next();
         BlockPos blockPos = BlockPos.ofFloored(particle.position);
         if (client.world.isPosLoaded(blockPos) && !(particle.position.y < 0.0) && !(particle.alpha <= 0.0F)) {
            particle.previousPosition = particle.position;
            particle.age++;
            Vec3d velocity = this.settings.isActive()
               ? particle.velocity.multiply(0.99).subtract(0.0, 0.03, 0.0)
               : particle.velocity.multiply(0.96).add(0.0, 0.003, 0.0);
            Vec3d end = particle.position.add(velocity);
            BlockHitResult collision = null;
            BlockHitResult hit;
            if (this.settings.isActive()
               && (hit = client.world.raycast(new RaycastContext(particle.position, end, ShapeType.COLLIDER, FluidHandling.NONE, client.player))).getType()
                  == Type.BLOCK) {
               Axis axis = hit.getSide().getAxis();
               velocity = new Vec3d(
                  axis == Axis.X ? -velocity.x : velocity.x, axis == Axis.Y ? -velocity.y : velocity.y, axis == Axis.Z ? -velocity.z : velocity.z
               );
               collision = hit;
            }

            particle.position = collision != null ? collision.getPos() : particle.position.add(velocity);
            particle.velocity = velocity;
            particle.size *= 0.97F;
            if (particle.age >= this.settings.getIntType2()) {
               particle.alpha = Math.max(0.0F, particle.alpha - 0.03F);
            }
         } else {
            iterator.remove();
         }
      }
   }

   @Override
   public void renderWorld(WorldRenderEvent event) {
      MinecraftClient client = MinecraftClient.getInstance();
      if (client.world == null || client.player == null) {
         this.update2();
      } else if (this.particles.isEmpty()) {
         this.previousFrameNanos = System.nanoTime();
      } else {
         this.pendingTicks = this.pendingTicks + this.frameSeconds() * 20.0;
         int updates = Math.min(10, (int)this.pendingTicks);
         if (updates > 0) {
            this.pendingTicks -= updates;

            for (int i = 0; i < updates; i++) {
               this.simulate(client);
            }
         }

         this.renderParticles(event.getFloatType());
      }
   }

   @Override
   public void setTotemPopEvent(TotemPopEvent event) {
      ThreadLocalRandom random = ThreadLocalRandom.current();
      Snowflake.ParticleStyle style = this.selectedStyle();
      int count = this.settings.getIntType() + random.nextInt(4);
      int color = this.settings.getIntType3();

      for (int i = 0; i < count; i++) {
         this.particles
            .add(
               new Snowflake.TotemParticle(
                  event.toVec3d(),
                  this.randomVelocity(random),
                  color,
                  (0.2F + random.nextFloat() * 0.15F) * style.scale(),
                  random.nextFloat() * 360.0F,
                  random.nextFloat() * 5.0F + 2.5F,
                  style
               )
            );
      }
   }

   @Override
   public void update2() {
      this.particles.clear();
      this.previousFrameNanos = 0L;
      this.pendingTicks = 0.0;
   }

   private record ParticleStyle(WexsideHitParticles texture, float scale) {
   }

   private static final class TotemParticle {
      private final Snowflake.ParticleStyle style;
      private final int color;
      private Vec3d position;
      private Vec3d previousPosition;
      private Vec3d velocity;
      private float size;
      private float alpha = 1.0F;
      private final float initialRotation;
      private final float rotationSpeed;
      private int age;

      private TotemParticle(Vec3d position, Vec3d velocity, int color, float size, float initialRotation, float rotationSpeed, Snowflake.ParticleStyle style) {
         this.position = position;
         this.previousPosition = position;
         this.velocity = velocity;
         this.color = color;
         this.size = size;
         this.initialRotation = initialRotation;
         this.rotationSpeed = rotationSpeed;
         this.style = style;
      }
   }
}
