package ru.wexside.util;

import java.util.Arrays;
import java.util.Optional;
import java.util.Random;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import ru.wexside.module.combat.HitBoxesModule;

public final class AimCalculator {
   private static final double HITBOX_MARGIN = 0.05;
   private static final double JITTER_DECAY = 0.85;
   private static final double JITTER_STRENGTH = 0.04;
   private static final double MAX_JITTER = 0.18;
   private static final double EPSILON = 1.0E-7;
   private static final int RANGE_SEARCH_STEPS = 8;
   private final Random random = new Random();
   private Vec3d jitter = Vec3d.ZERO;

   public Vec3d calculateAimPoint(LivingEntity target, Angle look, float attackRange, float searchRange, boolean throughWalls) {
      ClientPlayerEntity player = MinecraftClient.getInstance().player;
      if (player != null && target != null && look != null) {
         Vec3d eye = player.getEyePos();
         float expand = HitBoxesModule.getExpand(target);
         Box baseBox = target.getBoundingBox();
         Box hitbox = expand > 0.0F ? baseBox.expand(expand, expand * 0.5F, expand) : baseBox;
         Vec3d chest = new Vec3d((hitbox.minX + hitbox.maxX) * 0.5, hitbox.minY + (hitbox.maxY - hitbox.minY) * 0.65, (hitbox.minZ + hitbox.maxZ) * 0.5);
         double distToChest = eye.distanceTo(chest);
         if (distToChest <= searchRange) {
            if (distToChest > attackRange) {
               Vec3d closest = closestPoint(hitbox, eye);
               if (eye.distanceTo(closest) <= searchRange) {
                  return closest;
               }
            }

            if (!throughWalls && !isVisible(player, eye, chest)) {
               Vec3d closest = closestPoint(hitbox, eye);
               if (isVisible(player, eye, closest)) {
                  return closest;
               }
            }

            return chest;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private Vec3d applyJitter(Box hitbox, Vec3d eye, Vec3d aimPoint, float attackRange, float searchRange, boolean targetWithinAttackRange) {
      this.jitter = this.jitter.multiply(0.85).add(this.random.nextGaussian() * 0.04, this.random.nextGaussian() * 0.04, this.random.nextGaussian() * 0.04);
      this.jitter = limitLength(this.jitter, 0.18);
      Vec3d jittered = closestPoint(hitbox, aimPoint.add(this.jitter));
      if (!targetWithinAttackRange) {
         return jittered;
      }

      Optional<Vec3d> intersection = raycastHitbox(hitbox, eye, Angle.fromVectors(eye, jittered), searchRange);
      return intersection.isPresent() && eye.distanceTo(intersection.get()) <= attackRange ? jittered : aimPoint;
   }

   private static Vec3d findPointWithinAttackRange(Box hitbox, Vec3d eye, Angle currentLook, Vec3d closest, float attackRange, float searchRange) {
      Angle closestAngle = Angle.fromVectors(eye, closest);
      float lower = 0.0F;
      float upper = 1.0F;

      for (int step = 0; step < 8; step++) {
         float factor = (lower + upper) * 0.5F;
         Optional<Vec3d> intersection = raycastHitbox(hitbox, eye, interpolate(currentLook, closestAngle, factor), searchRange);
         if (intersection.isPresent() && eye.distanceTo(intersection.get()) <= attackRange) {
            upper = factor;
         } else {
            lower = factor;
         }
      }

      return raycastHitbox(hitbox, eye, interpolate(currentLook, closestAngle, upper), searchRange).orElse(closest);
   }

   private static Angle clampLookToHitbox(Vec3d eye, Box hitbox, Angle look) {
      float yaw = clampYawToHitbox(eye, hitbox, look.getYaw());
      float pitch = clampPitchToHitbox(eye, hitbox, yaw, look.getPitch());
      return new Angle(yaw, pitch);
   }

   private static float clampYawToHitbox(Vec3d eye, Box hitbox, float yaw) {
      if (eye.x >= hitbox.minX && eye.x <= hitbox.maxX && eye.z >= hitbox.minZ && eye.z <= hitbox.maxZ) {
         return yaw;
      }

      float[] corners = new float[]{
         yawTo(eye, hitbox.minX, hitbox.minZ), yawTo(eye, hitbox.minX, hitbox.maxZ), yawTo(eye, hitbox.maxX, hitbox.minZ), yawTo(eye, hitbox.maxX, hitbox.maxZ)
      };
      Arrays.sort(corners);
      int arcStartIndex = 0;
      float largestGap = corners[0] + 360.0F - corners[3];

      for (int index = 1; index < corners.length; index++) {
         float gap = corners[index] - corners[index - 1];
         if (gap > largestGap) {
            largestGap = gap;
            arcStartIndex = index;
         }
      }

      float arcStart = corners[arcStartIndex];
      float arcEnd = corners[(arcStartIndex + corners.length - 1) % corners.length];
      float arcLength = positiveDegrees(arcEnd - arcStart);
      float position = positiveDegrees(yaw - arcStart);
      if (position <= arcLength) {
         return yaw;
      } else {
         return position - arcLength <= 360.0F - position ? arcEnd : arcStart;
      }
   }

   private static float clampPitchToHitbox(Vec3d eye, Box hitbox, float yaw, float pitch) {
      Vec3d horizontalDirection = new Angle(yaw, 0.0F).toVec3d();
      double[] xRange = slabRange(eye.x, horizontalDirection.x, hitbox.minX, hitbox.maxX);
      double[] zRange = slabRange(eye.z, horizontalDirection.z, hitbox.minZ, hitbox.maxZ);
      if (xRange != null && zRange != null) {
         double entry = Math.max(0.0, Math.max(xRange[0], zRange[0]));
         double exit = Math.min(xRange[1], zRange[1]);
         if (exit < entry) {
            return pitch;
         }

         double minY = hitbox.minY - eye.y;
         double maxY = hitbox.maxY - eye.y;
         float minPitch = Float.MAX_VALUE;
         float maxPitch = -Float.MAX_VALUE;

         for (double distance : new double[]{entry, exit}) {
            for (double height : new double[]{minY, maxY}) {
               float candidate = (float)(-Math.toDegrees(Math.atan2(height, distance)));
               minPitch = Math.min(minPitch, candidate);
               maxPitch = Math.max(maxPitch, candidate);
            }
         }

         return MathHelper.clamp(pitch, minPitch, maxPitch);
      } else {
         return pitch;
      }
   }

   private static double[] slabRange(double origin, double direction, double min, double max) {
      if (!(Math.abs(direction) < 1.0E-7)) {
         double first = (min - origin) / direction;
         double second = (max - origin) / direction;
         return new double[]{Math.min(first, second), Math.max(first, second)};
      }

      double[] dArray;
      if (origin >= min && origin <= max) {
         double[] dArray2 = new double[]{0.0, 0.0};
         dArray = dArray2;
         dArray2[1] = Double.MAX_VALUE;
      } else {
         dArray = null;
      }

      return dArray;
   }

   private static Optional<Vec3d> raycastHitbox(Box hitbox, Vec3d eye, Angle angle, float distance) {
      return hitbox.raycast(eye, eye.add(angle.toVec3d().multiply(distance)));
   }

   private static Angle interpolate(Angle from, Angle to, float factor) {
      float yaw = from.getYaw() + MathHelper.wrapDegrees(to.getYaw() - from.getYaw()) * factor;
      float pitch = from.getPitch() + (to.getPitch() - from.getPitch()) * factor;
      return new Angle(MathHelper.wrapDegrees(yaw), pitch);
   }

   private static float yawTo(Vec3d eye, double x, double z) {
      return MathHelper.wrapDegrees((float)(Math.toDegrees(Math.atan2(z - eye.z, x - eye.x)) - 90.0));
   }

   private static float positiveDegrees(float angle) {
      float normalized = angle % 360.0F;
      return normalized < 0.0F ? normalized + 360.0F : normalized;
   }

   private static Vec3d limitLength(Vec3d vector, double maximum) {
      double length = vector.length();
      return length <= maximum ? vector : vector.multiply(maximum / length);
   }

   private static Vec3d closestPoint(Box box, Vec3d point) {
      return new Vec3d(
         MathHelper.clamp(point.x, box.minX, box.maxX), MathHelper.clamp(point.y, box.minY, box.maxY), MathHelper.clamp(point.z, box.minZ, box.maxZ)
      );
   }

   private static boolean isVisible(ClientPlayerEntity player, Vec3d start, Vec3d end) {
      ClientWorld world = MinecraftClient.getInstance().world;
      if (world == null) {
         return false;
      }

      RaycastContext context = new RaycastContext(start, end, ShapeType.COLLIDER, FluidHandling.NONE, player);
      return world.raycast(context).getType() == Type.MISS;
   }

   private static Box shrinkHitbox(Box box) {
      double x = Math.min(0.05, box.getLengthX() / 4.0);
      double y = Math.min(0.05, box.getLengthY() / 4.0);
      double z = Math.min(0.05, box.getLengthZ() / 4.0);
      return box.expand(-x, -y, -z);
   }
}
