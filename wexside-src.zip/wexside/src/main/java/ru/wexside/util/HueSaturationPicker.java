package ru.wexside.util;

import java.awt.Color;
import org.joml.Matrix4f;
import ru.wexside.WexSideClient;
import ru.wexside.misc.BoundsProvider;
import ru.wexside.misc.CharacterInputHandler;
import ru.wexside.misc.GuiRenderable;
import ru.wexside.misc.KeyPressHandler;
import ru.wexside.misc.LayoutUpdater;
import ru.wexside.misc.MouseButtonHandler;
import ru.wexside.misc.MouseScrollHandler;
import ru.wexside.misc.PreparedLayer;
import ru.wexside.misc.ThemeColors;
import ru.wexside.setting.ColorSetting;
import ru.wexside.ui.GuiBounds;

public final class HueSaturationPicker
   extends AbstractColorSlider
   implements CharacterInputHandler,
   MouseScrollHandler,
   LayoutUpdater,
   KeyPressHandler,
   GuiRenderable,
   MouseButtonHandler,
   BoundsProvider {
   private boolean initialized;
   private int cachedRgb = Integer.MIN_VALUE;
   private float saturation;
   private float brightness = 1.0F;
   private final float cornerRadius;

   public HueSaturationPicker(GuiBounds bounds2, ColorSetting colorSetting, SliderMarkerRenderer sliderMarkerRenderer, float cornerRadius) {
      super(bounds2, colorSetting, sliderMarkerRenderer);
      this.cornerRadius = cornerRadius;
   }

   @Override
   public void update() {
      super.update();
      if (!this.isActive2() && this.hasExternalColorChange()) {
         this.syncFromColorSetting();
      }
   }

   private void syncFromColorSetting() {
      float[] hsb = this.getHsbComponents();
      this.saturation = this.process8(hsb[1]);
      this.brightness = this.process8(hsb[2]);
      this.initialized = true;
      this.cachedRgb = this.getCurrentRgb();
   }

   private boolean hasExternalColorChange() {
      return !this.initialized ? true : this.getCurrentRgb() != this.cachedRgb;
   }

   private int getCurrentRgb() {
      return this.getColorSetting().getColor() & 16777215;
   }

   @Override
   protected void process(float relX, float relY) {
      float width = this.getBounds().getWidth();
      float height = this.getBounds().getHeight();
      this.saturation = width <= 0.0F ? 0.0F : this.process8(relX / width);
      this.brightness = height <= 0.0F ? 1.0F : this.process8(1.0F - relY / height);
      this.initialized = true;
      float[] hsb = this.getHsbComponents();
      this.process6(hsb[0], this.saturation, this.brightness, this.getIntType2());
      this.cachedRgb = this.getCurrentRgb();
   }

   @Override
   protected float getMarkerX() {
      if (!this.initialized) {
         this.syncFromColorSetting();
      }

      return this.getBounds().getX() + this.saturation * this.getBounds().getWidth();
   }

   @Override
   protected float getMarkerY() {
      if (!this.initialized) {
         this.syncFromColorSetting();
      }

      return this.getBounds().getY() + (1.0F - this.brightness) * this.getBounds().getHeight();
   }

   @Override
   protected void setMatrix4f(Matrix4f matrix4f) {
      if (!this.isActive2() && this.hasExternalColorChange()) {
         this.syncFromColorSetting();
      }

      GuiDrawApi drawApi = WexSideClient.getGuiRenderer();
      GuiBounds bounds2 = this.getBounds();
      float f = bounds2.getX();
      float f2 = bounds2.getY();
      float f3 = bounds2.getWidth();
      float f4 = bounds2.getHeight();
      float[] fArray = this.getHsbComponents();
      int n = Color.HSBtoRGB(fArray[0], 1.0F, 1.0F) | 0xFF000000;
      PreparedLayer preparedLayer = drawApi.prepareDedicatedLayer(matrix4f, f, f2, f3, f4, 0.0F);
      drawApi.beginLayerFrame(preparedLayer.getTexture());
      Matrix4f matrix4f2 = new Matrix4f(preparedLayer.getContentMatrix()).translate(preparedLayer.contentX(), preparedLayer.contentY(), 0.0F);
      drawApi.fillRectangle(matrix4f2, 0.0F, 0.0F, f3, f4, ThemeColors.backgroundControl());
      drawApi.drawColorGradient(
         matrix4f2,
         0.0F,
         0.0F,
         f3,
         f4,
         ColorUtils.withAlpha(ThemeColors.backgroundControl(), 0.0F),
         n,
         n,
         ColorUtils.withAlpha(ThemeColors.backgroundControl(), 0.0F)
      );
      drawApi.drawColorGradient(
         matrix4f2, 0.0F, 0.0F, f3, f4, ColorUtils.rgba(0, 0, 0, 255), ColorUtils.rgba(0, 0, 0, 255), ColorUtils.rgba(0, 0, 0, 0), ColorUtils.rgba(0, 0, 0, 0)
      );
      drawApi.endLayerFrame();
      drawApi.drawPreparedLayerRounded(matrix4f, preparedLayer, this.cornerRadius, -1);
   }
}
