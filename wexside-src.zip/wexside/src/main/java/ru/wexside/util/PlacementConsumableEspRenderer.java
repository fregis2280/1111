package ru.wexside.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import org.joml.Matrix4f;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.ConsumableEspEffect;
import ru.wexside.misc.ConsumablesEspSettings;
import ru.wexside.misc.PlacementPreview;
import ru.wexside.render.RenderCamera;
import ru.wexside.render.world.ConsumableAreaRenderer;
import ru.wexside.setting.ColorSetting;

public final class PlacementConsumableEspRenderer implements ConsumableEspEffect {
   private final Map<UUID, PlacementPreview> map2 = new HashMap<>();
   static final int slot = 5;
   private final ConsumablesEspSettings consumablesEspSettings;
   static final float value = 22.5F;
   static final int slot2 = 3;
   static final int slot3 = 3;
   static final int slot4 = 5;

   public PlacementConsumableEspRenderer(ConsumablesEspSettings consumablesEspSettings) {
      this.consumablesEspSettings = consumablesEspSettings;
   }

   @Override
   public void process(WorldRenderEvent floatTypeEvent2, PlayerEntity player, ColorSetting colorSetting) {
      this.process8(floatTypeEvent2, player, colorSetting);
   }

   @Override
   public void update() {
      this.map2.clear();
   }

   @Override
   public void setSet(Set<UUID> set) {
      this.map2.keySet().removeIf(uUID -> !set.contains(uUID));
   }

   @Override
   public void setUUID(UUID uUID) {
      this.map2.remove(uUID);
   }

   private void process2(WorldRenderEvent event, UUID uUID, PlayerEntity player, BlockPos pos, ColorSetting colorSetting, long l) {
      int n3 = 2;
      float f = player.getPitch();
      float f2 = this.process4(player.getYaw());
      boolean bl2 = this.process9(f2);
      int n;
      int n2;
      boolean bl;
      if (f < -45.0F) {
         bl = true;
         n2 = pos.getY() + 4;
         n = n2 - 1;
      } else if (f > 45.0F) {
         bl = true;
         n2 = pos.getY() - 1;
         n = n2 - 1;
      } else {
         bl = false;
         n2 = -1;
         n = 4;
      }

      if (bl) {
         Box box = this.process10(pos.getX() - n3, n2, pos.getZ() - n3, pos.getX() + n3 + 1, n, pos.getZ() + n3 + 1);
         this.process7(uUID, pos, box);
         Box box2 = this.map2.get(uUID).box();
         if (box2 != null) {
            this.process5(event, box2, colorSetting, l);
         }
      } else if (bl2) {
         this.process6(event, uUID, player, pos, f2, n2, n, n3, colorSetting, l);
      } else {
         Direction process17 = player.getHorizontalFacing();
         BlockPos pos2 = pos.offset(process17, 3);
         int n4 = pos2.getY() + n2;
         int n5 = pos2.getY() + n;
         Box box3 = process17.getAxis() == Axis.X
            ? this.process10(pos2.getX(), n4, pos2.getZ() - n3, pos2.getX() + 1, n5, pos2.getZ() + n3 + 1)
            : this.process10(pos2.getX() - n3, n4, pos2.getZ(), pos2.getX() + n3 + 1, n5, pos2.getZ() + 1);
         this.process7(uUID, pos2, box3);
         Box box4 = this.map2.get(uUID).box();
         if (box4 != null) {
            this.process5(event, box4, colorSetting, l);
         }
      }
   }

   @Override
   public boolean process3(Item iiIilIIilI2) {
      return iiIilIIilI2 == Items.NETHERITE_SCRAP || iiIilIIilI2 == Items.PHANTOM_MEMBRANE;
   }

   private float process4(float f) {
      float f2 = f % 360.0F;
      if (f2 < 0.0F) {
         f2 += 360.0F;
      }

      return f2;
   }

   private void process5(WorldRenderEvent event, Box box, ColorSetting colorSetting, long l) {
      Matrix4f matrix = event != null && event.getMatrices() != null ? new Matrix4f(event.getMatrices().peek().getPositionMatrix()) : null;
      Vec3d cameraPos = RenderCamera.position();
      ConsumableAreaRenderer.renderBox(
         matrix,
         cameraPos,
         box,
         ColorUtils.multiplyAlpha(ConsumablesEspSettings.process5(colorSetting, 0.0F), 0.2F),
         ColorUtils.multiplyAlpha(ConsumablesEspSettings.process5(colorSetting, 1.0F), 0.2F),
         ColorUtils.multiplyAlpha(ConsumablesEspSettings.process5(colorSetting, 0.0F), 0.65F),
         ColorUtils.multiplyAlpha(ConsumablesEspSettings.process5(colorSetting, 1.0F), 0.65F),
         l
      );
   }

   private void process6(
      WorldRenderEvent event, UUID uUID, PlayerEntity player, BlockPos pos, float f, int n, int n2, int n3, ColorSetting colorSetting, long l
   ) {
      BlockPos pos2 = pos.offset(player.getHorizontalFacing(), 0);
      int n4 = pos2.getY() + n;
      int n5 = pos2.getY() + n2;
      int n6 = 0;
      int n7 = 0;
      if (f < 67.5F) {
         n6 = 1;
         n7 = 1;
         pos2 = pos2.add(-2, 0, 2);
      } else if (f >= 112.5F && f < 157.5F) {
         n6 = -1;
         n7 = 1;
         pos2 = pos2.add(-2, 0, -2);
      } else if (f >= 202.5F && f < 247.5F) {
         n6 = -1;
         n7 = -1;
         pos2 = pos2.add(2, 0, -2);
      } else if (f >= 292.5F || f < 337.5F) {
         n6 = 1;
         n7 = -1;
         pos2 = pos2.add(2, 0, 2);
      }

      this.process7(uUID, pos2, null);
      Vec3d vec = this.map2.get(uUID).center();
      if (vec != null) {
         for (int i = -n3; i <= n3; i++) {
            double d = vec.x + i * n6;
            double d2 = vec.z + i * n7;
            Box box = this.process10(d, n4, d2, d + 1.0, n5, d2 + 1.0);
            this.process5(event, box, colorSetting, l);
         }
      }
   }

   private void process7(UUID uUID2, BlockPos pos, Box box) {
      this.map2.computeIfAbsent(uUID2, uUID -> new PlacementPreview(pos, box)).update(pos, box);
   }

   @Override
   public void process5(WorldRenderEvent floatTypeEvent2, PlayerEntity player, ColorSetting colorSetting) {
      this.process8(floatTypeEvent2, player, colorSetting);
   }

   private void process8(WorldRenderEvent event, PlayerEntity player, ColorSetting colorSetting) {
      Item iiIilIIilI2 = player.getMainHandStack().getItem();
      boolean bl2 = iiIilIIilI2 == Items.NETHERITE_SCRAP;
      boolean bl = iiIilIIilI2 == Items.PHANTOM_MEMBRANE;
      if (!bl2 && !bl) {
         this.setUUID(player.getUuid());
      } else {
         long l = System.currentTimeMillis();
         BlockPos pos = player.getBlockPos();
         if (bl) {
            this.process11(event, player.getUuid(), pos, colorSetting, l);
         } else {
            this.process2(event, player.getUuid(), player, pos, colorSetting, l);
         }
      }
   }

   private boolean process9(float f) {
      for (float f2 : new float[]{45.0F, 135.0F, 225.0F, 315.0F}) {
         if (Math.abs(f - f2) < 22.5F) {
            return true;
         }
      }

      return false;
   }

   private Box process10(double d, double d2, double d3, double d4, double d5, double d6) {
      return new Box(Math.min(d, d4), Math.min(d2, d5), Math.min(d3, d6), Math.max(d, d4), Math.max(d2, d5), Math.max(d3, d6));
   }

   private void process11(WorldRenderEvent event, UUID uUID, BlockPos pos, ColorSetting colorSetting, long l) {
      int n = 1;
      Box box = this.process10(pos.getX() - n, pos.getY() - n + 1, pos.getZ() - n, pos.getX() + n + 1, pos.getY() + n + 2, pos.getZ() + n + 1);
      this.process7(uUID, pos, box);
      Box box2 = this.map2.get(uUID).box();
      if (box2 != null) {
         this.process5(event, box2, colorSetting, l);
      }
   }
}
