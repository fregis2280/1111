package ru.wexside.util;

import org.joml.Matrix4f;
import ru.wexside.misc.FontRegistry;
import ru.wexside.misc.IconPlacement;
import ru.wexside.misc.ThemeColors;

public final class HudIconStyle {
   private final String string2 = "h";
   private final float value = 6.0F;
   private final float value2;
   private final float value3 = 5.0F;
   private final String string3;

   public HudIconStyle(String string) {
      this.value2 = 2.0F;
      this.string3 = string;
   }

   public String iconGlyph() {
      return this.string3;
   }

   public float getFloatType() {
      return Math.max(FontRegistry.font3.process4("h", 6.0F), FontRegistry.font4.process4(this.string3, 5.0F));
   }

   public void renderRightAligned(Matrix4f matrix4f, GuiDrawApi drawApi, float f, float f2, float f3) {
      this.render(matrix4f, drawApi, f, f2, f3, IconPlacement.ICON_RIGHT);
   }

   public float getFloatType2() {
      float f = FontRegistry.font3.process3("h", 6.0F);
      float f2 = FontRegistry.font4.process3(this.string3, 5.0F);
      return f + 2.0F + f2;
   }

   public float getFloatType3() {
      return 2.0F;
   }

   public String getString() {
      return "h";
   }

   public float getFloatType4() {
      return 5.0F;
   }

   public void render(Matrix4f matrix4f, GuiDrawApi drawApi, float f, float f2, float f3, IconPlacement iconPlacement) {
      int n = ColorUtils.lerp(ThemeColors.textMuted(), ThemeColors.textSecondary(), f3);
      float f6 = FontRegistry.font3.process3("h", 6.0F);
      float f7 = FontRegistry.font3.process4("h", 6.0F);
      float f8 = FontRegistry.font4.process3(this.string3, 5.0F);
      float f9 = FontRegistry.font4.process4(this.string3, 5.0F);
      float f4;
      float f5;
      if (iconPlacement == IconPlacement.ICON_LEFT) {
         f5 = f;
         f4 = f5 + f6 + 2.0F;
      } else {
         f4 = f - f8;
         f5 = f4 - 2.0F - f6;
      }

      float f10 = f2 + (f9 - f7) / 2.0F;
      FontRegistry.font3.process5(matrix4f, drawApi, "h", f5, f10, 6.0F, n);
      FontRegistry.font4.process2(matrix4f, drawApi, this.string3, f4, f2, 5.0F, n);
   }

   public float getFloatType5() {
      return 6.0F;
   }
}
