package ru.wexside.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import ru.wexside.misc.SpatialTransform;
import ru.wexside.render.RenderProjection;

public class InlineMeshRenderer {
   public InlineMeshRenderer(String name) {
   }

   public InlineMeshRenderer(String name, boolean cull) {
   }

   public InlineMeshRenderer(String name, Identifier vertexShader, Identifier fragmentShader, boolean cull) {
   }

   public InlineMeshRenderer(String name, Identifier vertexShader, Identifier fragmentShader) {
   }

   public void process3(
      MatrixStack matrices,
      Immediate consumers,
      Vec3d cameraPosition,
      List<InlineMesh> meshes,
      List<float[]> positionOverrides,
      List<Matrix4f> localTransforms,
      int color,
      List<SpatialTransform> transforms,
      ModelRenderOptions style
   ) {
      if (meshes != null && !meshes.isEmpty() && transforms != null && !transforms.isEmpty()) {
         Vec3d camera = cameraPosition == null ? Vec3d.ZERO : cameraPosition;
         ModelRenderOptions renderStyle = style == null ? ModelRenderOptions.getAlternateRenderOptions() : style;
         List<SpatialTransform> visibleTransforms = visibleTransforms(transforms);
         if (!visibleTransforms.isEmpty()) {
            RenderLayer fillLayer = RenderLayers.debugQuads();
            VertexConsumer fill = consumers.getBuffer(fillLayer);

            for (SpatialTransform transform : visibleTransforms) {
               matrices.push();
               matrices.translate(transform.centerX() - camera.x, transform.centerY() - camera.y, transform.centerZ() - camera.z);
               applyRotation(matrices, transform);
               matrices.scale(transform.scaleX(), transform.scaleY(), transform.scaleZ());
               emitFilledMeshes(fill, meshes, positionOverrides, localTransforms, matrices.peek().getPositionMatrix(), color);
               matrices.pop();
            }

            consumers.draw(fillLayer);
            emitTransformedOutlines(matrices, consumers, camera, meshes, positionOverrides, localTransforms, color, visibleTransforms, renderStyle);
         }
      }
   }

   public void process11(
      MatrixStack matrices,
      Immediate consumers,
      Vec3d cameraPosition,
      List<InlineMesh> meshes,
      List<float[]> positionOverrides,
      List<Matrix4f> localTransforms,
      int color,
      List<Matrix4f> worldTransforms,
      ModelRenderOptions style
   ) {
      if (meshes != null && !meshes.isEmpty() && worldTransforms != null && !worldTransforms.isEmpty()) {
         Vec3d camera = cameraPosition == null ? Vec3d.ZERO : cameraPosition;
         ModelRenderOptions renderStyle = style == null ? ModelRenderOptions.getAlternateRenderOptions() : style;
         Matrix4f base = new Matrix4f(matrices.peek().getPositionMatrix()).translate((float)(-camera.x), (float)(-camera.y), (float)(-camera.z));
         RenderLayer fillLayer = RenderLayers.debugQuads();
         VertexConsumer fill = consumers.getBuffer(fillLayer);

         for (Matrix4f worldTransform : worldTransforms) {
            if (worldTransform != null) {
               emitFilledMeshes(fill, meshes, positionOverrides, localTransforms, new Matrix4f(base).mul(worldTransform), color);
            }
         }

         consumers.draw(fillLayer);
         if (renderStyle.isActive3()) {
            int outlineColor = renderStyle.process8(color);
            RenderLayer outlineLayer = renderStyle.isActive2() ? RenderLayers.lines() : RenderLayers.linesTranslucent();
            VertexConsumer outline = consumers.getBuffer(outlineLayer);

            for (Matrix4f worldTransform : worldTransforms) {
               if (worldTransform != null) {
                  emitMeshOutlines(
                     outline, meshes, positionOverrides, localTransforms, new Matrix4f(base).mul(worldTransform), outlineColor, renderStyle.getFloatType()
                  );
               }
            }

            consumers.draw(outlineLayer);
         }
      }
   }

   private static void emitTransformedOutlines(
      MatrixStack matrices,
      Immediate consumers,
      Vec3d camera,
      List<InlineMesh> meshes,
      List<float[]> positionOverrides,
      List<Matrix4f> localTransforms,
      int color,
      List<SpatialTransform> transforms,
      ModelRenderOptions style
   ) {
      if (style.isActive3()) {
         RenderLayer layer = style.isActive2() ? RenderLayers.lines() : RenderLayers.linesTranslucent();
         VertexConsumer outline = consumers.getBuffer(layer);
         int outlineColor = style.process8(color);

         for (SpatialTransform transform : transforms) {
            matrices.push();
            matrices.translate(transform.centerX() - camera.x, transform.centerY() - camera.y, transform.centerZ() - camera.z);
            applyRotation(matrices, transform);
            matrices.scale(transform.scaleX(), transform.scaleY(), transform.scaleZ());
            emitMeshOutlines(outline, meshes, positionOverrides, localTransforms, matrices.peek().getPositionMatrix(), outlineColor, style.getFloatType());
            matrices.pop();
         }

         consumers.draw(layer);
      }
   }

   private static void applyRotation(MatrixStack matrices, SpatialTransform transform) {
      if (transform.yawDegrees() != 0.0F) {
         matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(transform.yawDegrees()));
      }

      if (transform.pitchDegrees() != 0.0F) {
         matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(transform.pitchDegrees()));
      }

      if (transform.rollDegrees() != 0.0F) {
         matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(transform.rollDegrees()));
      }
   }

   private static List<SpatialTransform> visibleTransforms(List<SpatialTransform> transforms) {
      Frustum frustum = RenderProjection.frustum();
      if (frustum == null) {
         return transforms.stream().filter(Objects::nonNull).toList();
      }

      ArrayList<SpatialTransform> visible = new ArrayList<>(transforms.size());

      for (SpatialTransform transform : transforms) {
         if (transform != null) {
            double radius = Math.max(Math.max(Math.abs(transform.scaleX()), Math.abs(transform.scaleY())), Math.abs(transform.scaleZ()));
            Box bounds = new Box(
               transform.centerX() - radius,
               transform.centerY() - radius,
               transform.centerZ() - radius,
               transform.centerX() + radius,
               transform.centerY() + radius,
               transform.centerZ() + radius
            );
            if (frustum.isVisible(bounds)) {
               visible.add(transform);
            }
         }
      }

      return visible;
   }

   private static void emitFilledMeshes(
      VertexConsumer vertices,
      List<InlineMesh> meshes,
      List<float[]> positionOverrides,
      List<Matrix4f> localTransforms,
      Matrix4fc baseMatrix,
      int fallbackColor
   ) {
      for (int meshIndex = 0; meshIndex < meshes.size(); meshIndex++) {
         InlineMesh mesh = meshes.get(meshIndex);
         if (mesh != null) {
            float[] positions = positions(mesh, positionOverrides, meshIndex);
            int[] indices = mesh.getIntType2();
            if (positions != null && indices != null) {
               Matrix4f matrix = localMatrix(baseMatrix, localTransforms, meshIndex);

               for (int index = 0; index + 2 < indices.length; index += 3) {
                  emitVertex(vertices, matrix, positions, mesh.getFloatType4(), indices[index], fallbackColor);
                  emitVertex(vertices, matrix, positions, mesh.getFloatType4(), indices[index + 1], fallbackColor);
                  emitVertex(vertices, matrix, positions, mesh.getFloatType4(), indices[index + 2], fallbackColor);
                  emitVertex(vertices, matrix, positions, mesh.getFloatType4(), indices[index + 2], fallbackColor);
               }
            }
         }
      }
   }

   private static void emitMeshOutlines(
      VertexConsumer vertices,
      List<InlineMesh> meshes,
      List<float[]> positionOverrides,
      List<Matrix4f> localTransforms,
      Matrix4fc baseMatrix,
      int color,
      float lineWidth
   ) {
      for (int meshIndex = 0; meshIndex < meshes.size(); meshIndex++) {
         InlineMesh mesh = meshes.get(meshIndex);
         if (mesh != null) {
            float[] positions = positions(mesh, positionOverrides, meshIndex);
            int[] edges = mesh.getIntType();
            if (positions != null) {
               if (edges == null || edges.length < 2) {
                  edges = triangleEdges(mesh.getIntType2());
               }

               Matrix4f matrix = localMatrix(baseMatrix, localTransforms, meshIndex);

               for (int index = 0; index + 1 < edges.length; index += 2) {
                  emitLine(vertices, matrix, positions, edges[index], edges[index + 1], color, lineWidth);
               }
            }
         }
      }
   }

   private static float[] positions(InlineMesh mesh, List<float[]> overrides, int index) {
      float[] override;
      return overrides != null && index < overrides.size() && (override = overrides.get(index)) != null && override.length >= 3
         ? override
         : mesh.getFloatType();
   }

   private static Matrix4f localMatrix(Matrix4fc base, List<Matrix4f> transforms, int index) {
      Matrix4f matrix = new Matrix4f(base);
      if (transforms != null && index < transforms.size() && transforms.get(index) != null) {
         matrix.mul((Matrix4fc)transforms.get(index));
      }

      return matrix;
   }

   private static void emitVertex(VertexConsumer vertices, Matrix4fc matrix, float[] positions, float[] colors, int vertexIndex, int fallbackColor) {
      int offset = vertexIndex * 3;
      if (offset >= 0 && offset + 2 < positions.length) {
         vertices.vertex(matrix, positions[offset], positions[offset + 1], positions[offset + 2]).color(vertexColor(colors, vertexIndex, fallbackColor));
      }
   }

   private static int vertexColor(float[] colors, int vertexIndex, int fallbackColor) {
      if (colors == null) {
         return fallbackColor;
      }

      int offset = vertexIndex * 4;
      if (offset + 3 >= colors.length) {
         return fallbackColor;
      }

      int red = Math.round(Math.clamp(colors[offset], 0.0F, 1.0F) * 255.0F);
      int green = Math.round(Math.clamp(colors[offset + 1], 0.0F, 1.0F) * 255.0F);
      int blue = Math.round(Math.clamp(colors[offset + 2], 0.0F, 1.0F) * 255.0F);
      int alpha = Math.round(Math.clamp(colors[offset + 3], 0.0F, 1.0F) * 255.0F);
      return alpha << 24 | red << 16 | green << 8 | blue;
   }

   private static void emitLine(VertexConsumer vertices, Matrix4fc matrix, float[] positions, int first, int second, int color, float width) {
      int a = first * 3;
      int b = second * 3;
      if (a >= 0 && b >= 0 && a + 2 < positions.length && b + 2 < positions.length) {
         float dx = positions[b] - positions[a];
         float dy = positions[b + 1] - positions[a + 1];
         float dz = positions[b + 2] - positions[a + 2];
         float length = (float)Math.sqrt(dx * dx + dy * dy + dz * dz);
         if (length > 0.0F) {
            dx /= length;
            dy /= length;
            dz /= length;
         }

         Vector3f normal = new Matrix4f(matrix).transformDirection(new Vector3f(dx, dy, dz)).normalize();
         vertices.vertex(matrix, positions[a], positions[a + 1], positions[a + 2]).color(color).normal(normal.x, normal.y, normal.z).lineWidth(width);
         vertices.vertex(matrix, positions[b], positions[b + 1], positions[b + 2]).color(color).normal(normal.x, normal.y, normal.z).lineWidth(width);
      }
   }

   private static int[] triangleEdges(int[] triangles) {
      if (triangles == null) {
         return new int[0];
      }

      int[] edges = new int[triangles.length / 3 * 6];
      int target = 0;

      for (int index = 0; index + 2 < triangles.length; index += 3) {
         int a = triangles[index];
         int b = triangles[index + 1];
         int c = triangles[index + 2];
         edges[target++] = a;
         edges[target++] = b;
         edges[target++] = b;
         edges[target++] = c;
         edges[target++] = c;
         edges[target++] = a;
      }

      return edges;
   }
}
