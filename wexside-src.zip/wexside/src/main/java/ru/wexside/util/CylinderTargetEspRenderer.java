package ru.wexside.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import ru.wexside.animation.TimedPulse;
import ru.wexside.event.EntityAttackEvent;
import ru.wexside.event.WorldRenderEvent;
import ru.wexside.misc.PreviousValueTransition;
import ru.wexside.misc.TargetChange;
import ru.wexside.misc.TargetEspEffect;
import ru.wexside.misc.TargetTransition;
import ru.wexside.misc.TransitionPhase;
import ru.wexside.module.render.TargetEspRenderer;

public final class CylinderTargetEspRenderer extends TargetEspRenderer implements TargetEspEffect {
   static final float value4 = 1.0F;
   static final float value5 = 0.8F;
   static final float value6 = 1.0F;
   static final int slot = 360;
   private double value7;
   static final int slot2 = 360;
   static final float value8 = 4.4F;
   static final float value9 = 0.86F;
   static final long member8917 = 260L;
   static final long member12527 = 300L;
   private final PreviousValueTransition<CylinderTargetEspRenderer.TargetBounds> previousBounds;
   static final double value10 = 1.0E-9;
   static final float value11 = 1.16F;
   static final float value12 = 1.0F;
   private CylinderTargetEspRenderer.TargetBounds lastBounds;
   static final long member5632 = 420L;
   static final double value13 = 0.45;
   static final double value14 = 0.05;
   private final TargetTransition<LivingEntity> targetTransition2 = new TargetTransition<>();
   private double value15;
   static final float value16 = 0.01F;
   private long longType;
   static final float value17 = 1.12F;
   static final double value18 = 0.016666666666666666;
   private final TimedPulse attackPulse = new TimedPulse();
   static final int slot3 = -42663;

   public CylinderTargetEspRenderer() {
      this.previousBounds = new PreviousValueTransition<>();
   }

   @Override
   public void setEntityAttackEvent(EntityAttackEvent iIiiiilIiIEvent) {
      if (iIiiiilIiIEvent.getEntity() instanceof LivingEntity) {
         this.attackPulse.trigger();
      }
   }

   @Override
   public void setWorldRenderEvent(WorldRenderEvent floatTypeEvent2) {
      MinecraftClient mc = this.client();
      if (this.canRender(mc)) {
         this.process5(this.target(mc, LivingEntity.class), floatTypeEvent2.getFloatType());
         if (!this.targetTransition2.isEmpty()) {
            float f = this.getTransitionOpacity();
            LivingEntity entity2 = this.targetTransition2.current();
            if (!(f <= 0.0F)) {
               CylinderTargetEspRenderer.TargetBounds bounds = entity2 != null ? this.captureBounds(entity2, floatTypeEvent2.getFloatType()) : null;
               if (bounds != null) {
                  this.lastBounds = bounds;
               } else {
                  bounds = this.lastBounds;
               }

               if (bounds == null) {
                  this.update2();
               } else {
                  this.update3();
                  this.renderRing(
                     floatTypeEvent2.getMatrices(),
                     mc.getBufferBuilders().getEntityVertexConsumers(),
                     this.interpolatePreviousBounds(bounds),
                     floatTypeEvent2.getFloatType(),
                     this.getRadiusScale(),
                     f
                  );
               }
            }
         }
      }
   }

   @Override
   public void update() {
      this.update2();
   }

   private void process5(LivingEntity entity2, float f) {
      TargetChange<LivingEntity> targetChange = this.targetTransition2.updateTarget(entity2);
      if (targetChange.changed()) {
         CylinderTargetEspRenderer.TargetBounds oldBounds = this.lastBounds;
         CylinderTargetEspRenderer.TargetBounds newBounds = this.captureBounds(this.targetTransition2.current(), f);
         if (oldBounds != null && newBounds != null) {
            this.previousBounds.remember(oldBounds);
         }
      }
   }

   private void update2() {
      this.targetTransition2.reset();
      this.attackPulse.reset();
      this.previousBounds.reset();
      this.lastBounds = null;
      this.value7 = 0.0;
      this.value15 = 0.0;
      this.longType = 0L;
   }

   private int process(int n, int n2, float f) {
      return ColorUtils.lerp(this.process8(n, n2, f), -1, 0.2F);
   }

   private double process2(double d) {
      return Math.abs(1.0 + Math.sin(d)) * 0.5;
   }

   private float getRadiusScale() {
      if (this.targetTransition2.phase() == TransitionPhase.IDLE) {
         return 1.0F;
      }

      float f = this.targetTransition2.progress(300L);
      return this.targetTransition2.phase() == TransitionPhase.APPEARING
         ? AnimationMath.lerp(0.86F, 1.0F, AnimationMath.easeOut(f, 1.16F))
         : AnimationMath.lerp(1.0F, 0.86F, AnimationMath.smoothStep(f));
   }

   private CylinderTargetEspRenderer.TargetBounds captureBounds(LivingEntity entity2, float f) {
      if (entity2 != null && entity2.isAlive()) {
         Box box = entity2.getBoundingBox();
         return new CylinderTargetEspRenderer.TargetBounds(this.interpolatedPosition(entity2, f), entity2.getHeight(), box.maxX - box.minX, box.maxZ - box.minZ);
      } else {
         return null;
      }
   }

   private void renderRing(MatrixStack matrices2, Immediate iIiIliiliI2, CylinderTargetEspRenderer.TargetBounds bounds, float f, float f2, float f3) {
      matrices2.push();
      Vec3d camera = this.cameraPosition();
      matrices2.translate(bounds.position().x - camera.x, bounds.position().y - camera.y, bounds.position().z - camera.z);
      Matrix4f matrix4f = matrices2.peek().getPositionMatrix();
      VertexConsumer iliIIiiliI2 = iIiIliiliI2.getBuffer(RenderLayers.debugQuads());
      long l = System.currentTimeMillis();
      float f8 = this.attackPulse.isActive(l, 260L) ? 1.0F - Math.abs(this.attackPulse.progress(l, 260L) * 2.0F - 1.0F) : 0.0F;
      double d = this.value15 + (this.value7 - this.value15) * f;
      double d2 = this.process2(d - 0.45);
      double d3 = this.process2(d);
      float f9 = (float)(Math.max(bounds.width(), 0.1) * 0.8F) * f2;
      float f10 = (float)(d2 * bounds.height());
      float f11 = (float)(d3 * bounds.height());
      int n = Math.max(0, Math.min(255, Math.round(f3 * 1.0F * 255.0F)));
      int n2 = Math.max(0, Math.min(255, Math.round(f3 * 0.01F * 255.0F)));
      int n3 = Math.max(0, Math.min(255, Math.round(f3 * 255.0F)));

      for (int i = 0; i < 360; i++) {
         float f12 = (float)((Math.PI * 2) * i / 360.0);
         float f13 = (float)((Math.PI * 2) * (i + 1) / 360.0);
         float f7 = (float)Math.cos(f12) * f9;
         float f6 = (float)Math.sin(f12) * f9;
         float f5 = (float)Math.cos(f13) * f9;
         float f4 = (float)Math.sin(f13) * f9;
         int n4 = this.process7(this.process8(i, 360, 4.4F), f8);
         int n5 = this.process7(this.process8(i + 1, 360, 4.4F), f8);
         iliIIiiliI2.vertex(matrix4f, f7, f11, f6).color(ColorUtils.withAlpha(n4, n));
         iliIIiiliI2.vertex(matrix4f, f7, f10, f6).color(ColorUtils.withAlpha(n4, n2));
         iliIIiiliI2.vertex(matrix4f, f5, f10, f4).color(ColorUtils.withAlpha(n5, n2));
         iliIIiiliI2.vertex(matrix4f, f5, f11, f4).color(ColorUtils.withAlpha(n5, n));
      }

      VertexConsumer iliIIiiliI3 = iIiIliiliI2.getBuffer(RenderLayers.lines());

      for (int i = 0; i < 360; i++) {
         float f7 = (float)((Math.PI * 2) * i / 360.0);
         float f6 = (float)((Math.PI * 2) * (i + 1) / 360.0);
         float f5 = (float)Math.cos(f7) * f9;
         float f4 = (float)Math.sin(f7) * f9;
         float f14 = (float)Math.cos(f6) * f9;
         float f15 = (float)Math.sin(f6) * f9;
         float dx = f14 - f5;
         float dz = f15 - f4;
         float len = (float)Math.hypot(dx, dz);
         if (len > 0.0F) {
            dx /= len;
            dz /= len;
         }

         Vector3f normal = matrix4f.transformDirection(new Vector3f(dx, 0.0F, dz)).normalize();
         int n6 = this.process7(this.process(i, 360, 4.4F), f8);
         int n7 = this.process7(this.process(i + 1, 360, 4.4F), f8);
         iliIIiiliI3.vertex(matrix4f, f5, f11, f4).color(ColorUtils.withAlpha(n6, n3)).normal(normal.x, normal.y, normal.z).lineWidth(1.0F);
         iliIIiiliI3.vertex(matrix4f, f14, f11, f15).color(ColorUtils.withAlpha(n7, n3)).normal(normal.x, normal.y, normal.z).lineWidth(1.0F);
      }

      iIiIliiliI2.draw();
      matrices2.pop();
   }

   private CylinderTargetEspRenderer.TargetBounds interpolatePreviousBounds(CylinderTargetEspRenderer.TargetBounds bounds) {
      if (!this.previousBounds.hasValue()) {
         return bounds;
      } else {
         float f = this.previousBounds.progress(420L);
         if (f >= 1.0F) {
            this.previousBounds.clear();
            return bounds;
         } else {
            float f2 = AnimationMath.easeOut(f, 1.12F);
            CylinderTargetEspRenderer.TargetBounds previous = this.previousBounds.get();
            Vec3d from = previous.position();
            Vec3d to = bounds.position();
            return new CylinderTargetEspRenderer.TargetBounds(
               new Vec3d(AnimationMath.lerp(from.x, to.x, f2), AnimationMath.lerp(from.y, to.y, f2), AnimationMath.lerp(from.z, to.z, f2)),
               AnimationMath.lerp((float)previous.height(), (float)bounds.height(), f2),
               AnimationMath.lerp((float)previous.width(), (float)bounds.width(), f2),
               AnimationMath.lerp((float)previous.depth(), (float)bounds.depth(), f2)
            );
         }
      }
   }

   private void update3() {
      long l = System.nanoTime();
      double d;
      if (this.longType == 0L) {
         d = 0.016666666666666666;
      } else {
         d = Math.min((l - this.longType) * 1.0E-9, 0.05);
         if (!Double.isFinite(d) || d < 0.0) {
            d = 0.016666666666666666;
         }
      }

      this.longType = l;
      this.value15 = this.value7;
      this.value7 += d * 4.4F;
   }

   private int process7(int n, float f) {
      return f <= 0.0F ? n : ColorUtils.lerp(n, -42663, f);
   }

   private float getTransitionOpacity() {
      if (this.targetTransition2.phase() == TransitionPhase.IDLE) {
         return 1.0F;
      }

      float f = this.targetTransition2.progress(300L);
      if (this.targetTransition2.phase() == TransitionPhase.APPEARING) {
         if (f >= 1.0F) {
            this.targetTransition2.finishAppearance();
         }

         return AnimationMath.easeInOutSine(f);
      } else if (f >= 1.0F) {
         this.update2();
         return 0.0F;
      } else {
         return 1.0F - AnimationMath.smoothStep(f);
      }
   }

   private int process8(int n, int n2, float f) {
      long l = System.currentTimeMillis();
      float f2 = (float)l / (1000.0F / f) % n2;
      int n3 = (int)((n + f2) % n2);
      float f3 = (float)n3 / n2;
      return f3 < 0.5F
         ? ColorUtils.lerp(this.primaryColor(), this.secondaryColor(), f3 * 2.0F)
         : ColorUtils.lerp(this.secondaryColor(), this.primaryColor(), (f3 - 0.5F) * 2.0F);
   }

   private record TargetBounds(Vec3d position, double height, double width, double depth) {
   }
}
