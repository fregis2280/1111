package ru.wexside.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import ru.wexside.misc.RaycastMode;

public final class CriticalsHandler {
   private int ticksSinceAttack = 99;
   private final VelocityTracker velocityTracker = new VelocityTracker();

   public void onAttack() {
      this.ticksSinceAttack = 0;
   }

   public void tick() {
      if (this.ticksSinceAttack < 100) {
         this.ticksSinceAttack++;
      }
   }

   public boolean process(boolean criticalsEnabled, RaycastMode raycastMode) {
      return this.process(criticalsEnabled, false, raycastMode);
   }

   public boolean process(boolean criticalsEnabled, boolean jumpOnly, RaycastMode raycastMode) {
      if (!criticalsEnabled) {
         return true;
      } else {
         ClientPlayerEntity player = MinecraftClient.getInstance().player;
         if (player == null) {
            return false;
         } else if (player.isClimbing()
            || player.hasVehicle()
            || player.hasStatusEffect(StatusEffects.BLINDNESS)
            || player.hasStatusEffect(StatusEffects.LEVITATION)
            || player.hasStatusEffect(StatusEffects.SLOW_FALLING)
            || player.getAbilities().flying) {
            return true;
         } else if (!player.isTouchingWater() && !player.isInLava()) {
            boolean jumping = MinecraftClient.getInstance().options.jumpKey.isPressed();
            return jumpOnly && !jumping && player.isOnGround() ? true : !player.isOnGround() && (player.fallDistance > 0.0 || player.getVelocity().y < -0.08);
         } else {
            return true;
         }
      }
   }

   public VelocityTracker getVelocityTracker() {
      return this.velocityTracker;
   }

   public int getIntType() {
      return this.ticksSinceAttack;
   }
}
