package ru.wexside.util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;
import ru.wexside.WexSideClient;
import ru.wexside.misc.BakedIconEntry;
import ru.wexside.misc.ItemBindBox;

public final class ItemStatusHudElement extends AbstractHudElement {
   private final float value;
   private final int slot;
   private final float value2;
   private final List<ItemStatusTile> itemTiles = new ArrayList<>();

   public ItemStatusHudElement(String string, BooleanSupplier booleanSupplier, List<ItemBindBox> list, BooleanSupplier booleanSupplier2) {
      super(string, booleanSupplier);
      this.value2 = 21.0F;
      this.value = 3.0F;
      this.slot = 6;

      for (ItemBindBox itemBindBox : list) {
         this.itemTiles.add(new ItemStatusTile(itemBindBox, booleanSupplier2));
      }
   }

   @Override
   protected float getWidth() {
      int n = this.getIntType();
      int n2 = Math.min(n, 6);
      return n2 == 0 ? 0.0F : n2 * 21.0F + (n2 - 1) * 3.0F;
   }

   private int getIntType() {
      int n = 0;

      for (ItemStatusTile itemTile : this.itemTiles) {
         if (itemTile.isActive()) {
            n++;
         }
      }

      return n;
   }

   @Override
   protected void updateLayout() {
      for (ItemStatusTile itemTile : this.itemTiles) {
         itemTile.update3();
         itemTile.update();
      }

      this.update2();
   }

   @Override
   protected void renderContent(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3, float f4, float f5) {
      float f6 = 24.0F * f5;
      int n = 0;

      for (ItemStatusTile itemTile : this.itemTiles) {
         if (itemTile.isActive()) {
            int n2 = n % 6;
            int n3 = n / 6;
            itemTile.process(drawApi, matrix4f, f + n2 * f6, f2 + n3 * f6, f5);
            n++;
         }
      }
   }

   private void update2() {
      float f = MinecraftClient.getInstance().getWindow().getScaleFactor();
      ArrayList<BakedIconEntry> arrayList = new ArrayList<>();

      for (ItemStatusTile itemTile : this.itemTiles) {
         BakedIconEntry bakedIconEntry = itemTile.process2(f);
         if (bakedIconEntry != null) {
            arrayList.add(bakedIconEntry);
         }
      }

      if (!arrayList.isEmpty()) {
         WexSideClient.getRenderPipeline2().setList(arrayList);
      }
   }

   @Override
   protected float getHeight() {
      int n = (this.getIntType() + 6 - 1) / 6;
      return n == 0 ? 0.0F : n * 21.0F + (n - 1) * 3.0F;
   }

   @Override
   protected boolean isContentVisible() {
      for (ItemStatusTile itemTile : this.itemTiles) {
         if (itemTile.isActive()) {
            return true;
         }
      }

      return false;
   }
}
