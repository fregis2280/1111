package ru.wexside.model.esp;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import ru.wexside.WexSideClient;
import ru.wexside.misc.FriendList;

public final class EspTargetClassifier {
   private EspTargetClassifier() {
   }

   public static EspTargetType targetType(Entity entity, ClientPlayerEntity localPlayer) {
      if (entity == localPlayer) {
         return EspTargetType.SELF;
      } else if (entity instanceof PlayerEntity) {
         return EspTargetType.PLAYERS;
      } else {
         return entity instanceof ItemEntity ? EspTargetType.ITEMS : EspTargetType.ENTITIES;
      }
   }

   public static EspRelation relation(Entity entity) {
      if (entity instanceof PlayerEntity player) {
         FriendList friends = WexSideClient.getFriends();
         if (friends != null && friends.contains(player.getName().getString())) {
            return EspRelation.FRIEND;
         }
      }

      return EspRelation.DEFAULT;
   }
}
