package ru.wexside.command;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.ClickEvent.RunCommand;
import net.minecraft.text.HoverEvent.ShowText;
import net.minecraft.util.Formatting;
import ru.wexside.misc.ClientChat;
import ru.wexside.misc.ConfigManager;

public final class ConfigCommand extends Command {
   private static final String string6 = ".wex";
   ConfigManager field24;
   private static final int slot = 32;

   public ConfigCommand(ConfigManager configManager2) {
      super("cfg", "Управляет конфигами клиента", "cfg", "config");
      this.field24 = configManager2;
   }

   private void setString(String string) {
      if (!this.field24.profileExists(string)) {
         String string2 = string;
         ClientChat.send("Конфиг не найден: " + string2);
      } else {
         this.field24.loadProfile(string);
         String string3 = string;
         ClientChat.send("Конфиг загружен: " + string3);

         try {
            this.update();
         } catch (IOException iOException) {
            ClientChat.send("Не удалось обновить список конфигов: " + iOException.getMessage());
         }
      }
   }

   private void update() throws IOException {
      List<String> list = this.field24.listProfiles();
      if (list.isEmpty()) {
         ClientChat.send("Конфиги не найдены");
      } else {
         ClientChat.send("Доступные конфиги:");
         String string = process2(this.field24.getCurrentProfileName());

         for (String string2 : list) {
            String string3 = process2(string2);
            boolean bl = string3.equals(string);
            ClientChat.send(this.process(string3, bl));
         }
      }
   }

   @Override
   public String getUsage() {
      return ".cfg <save/load/clear/list/dir> [name]";
   }

   @Override
   public void execute(String... stringArray) throws CommandUsageException {
      if (stringArray.length == 0) {
         throw new CommandUsageException(this);
      }

      String string = stringArray[0].toLowerCase(Locale.ROOT);

      try {
         switch (string) {
            case "clear":
               this.update3();
               return;
            case "list":
               this.update();
               return;
            case "dir":
               this.update2();
               return;
            default:
               String string2 = stringArray.length > 1 ? String.join(" ", Arrays.copyOfRange(stringArray, 1, stringArray.length)).trim() : "";
               if (string2.isBlank()) {
                  String string4 = this.field24.getCurrentProfileName();
                  string2 = string4 != null && !string4.isBlank() ? string4 : "default";
               }

               switch (string) {
                  case "save":
                     this.setString2(string2);
                     break;
                  case "load":
                     this.setString(string2);
                     break;
                  default:
                     throw new CommandUsageException(this);
               }
         }
      } catch (IOException iOException) {
         String string5 = iOException.getMessage();
         ClientChat.send("Ошибка конфига: " + string5);
      }
   }

   private void update2() throws IOException {
      this.field24.openConfigFolder();
      ClientChat.send("Папка конфигов открыта");
   }

   private MutableText process(String string, boolean bl) {
      String string2 = string;
      String string3 = string;
      Style actionStyle = Style.EMPTY
         .withClickEvent(new RunCommand(".cfg load " + string2))
         .withHoverEvent(new ShowText(Text.literal("Нажмите, чтобы загрузить " + string3)));
      MutableText configName = Text.literal(string).setStyle(actionStyle);
      MutableText status = bl ? Text.literal(" (Загружен)").formatted(Formatting.GREEN) : Text.literal(" (Загрузить)").formatted(Formatting.GRAY);
      return Text.literal("- ").append(configName).append(status);
   }

   @Override
   public List<String> complete(int n, String[] stringArray) {
      if (n == 0) {
         return List.of("save", "load", "clear", "list", "dir");
      }

      if (n == 1 && stringArray.length >= 1 && "load".equalsIgnoreCase(stringArray[0])) {
         try {
            ArrayList<String> arrayList = new ArrayList<>();

            for (String string : this.field24.listProfiles()) {
               arrayList.add(process2(string));
            }

            return arrayList;
         } catch (IOException iOException) {
            return List.of();
         }
      } else {
         return List.of();
      }
   }

   private void update3() throws IOException {
      this.field24.resetProfile();
      ClientChat.send("Конфиг сброшен");
   }

   private void setString2(String string) throws IOException {
      if (string.length() > 32) {
         ClientChat.send("Название конфига не должно превышать 32 символов");
      } else {
         this.field24.saveProfile(string);
         String string2 = string;
         ClientChat.send("Конфиг сохранён: " + string2);
      }
   }

   private static String process2(String string) {
      if (string == null) {
         return null;
      } else {
         return string.endsWith(".wex") ? string.substring(0, string.length() - ".wex".length()) : string;
      }
   }
}
