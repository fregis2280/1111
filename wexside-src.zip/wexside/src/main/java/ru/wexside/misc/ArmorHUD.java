package ru.wexside.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import org.joml.Matrix4f;
import ru.wexside.WexSideClient;
import ru.wexside.util.AbstractHudElement;
import ru.wexside.util.GuiDrawApi;

public final class ArmorHUD extends AbstractHudElement {
   private final float value;
   private final List<ArmorSlotRenderer> armorSlots = List.of(
      new ArmorSlotRenderer(EquipmentSlot.HEAD),
      new ArmorSlotRenderer(EquipmentSlot.CHEST),
      new ArmorSlotRenderer(EquipmentSlot.LEGS),
      new ArmorSlotRenderer(EquipmentSlot.FEET)
   );

   public ArmorHUD(BooleanSupplier booleanSupplier) {
      super("Armor HUD", booleanSupplier);
      this.value = 3.0F;
   }

   @Override
   protected float getWidth() {
      return this.armorSlots.size() * this.armorSlots.get(0).getFloatType2() + (this.armorSlots.size() - 1) * 3.0F;
   }

   @Override
   protected void updateLayout() {
      ClientPlayerEntity player2 = MinecraftClient.getInstance().player;

      for (ArmorSlotRenderer armorSlotRenderer : this.armorSlots) {
         armorSlotRenderer.updateEquipment(player2);
      }

      this.update2();
   }

   @Override
   protected void renderContent(GuiDrawApi drawApi, Matrix4f matrix4f, float f, float f2, float f3, float f4, float f5) {
      float f6 = (this.armorSlots.get(0).getFloatType2() + 3.0F) * f5;

      for (int i = 0; i < this.armorSlots.size(); i++) {
         this.armorSlots.get(i).process2(drawApi, matrix4f, f + i * f6, f2, f5);
      }
   }

   private void update2() {
      float f = MinecraftClient.getInstance().getWindow().getScaleFactor();
      ArrayList<BakedIconEntry> arrayList = new ArrayList<>();

      for (ArmorSlotRenderer armorSlotRenderer : this.armorSlots) {
         BakedIconEntry bakedIconEntry = armorSlotRenderer.process3(f);
         if (bakedIconEntry != null) {
            arrayList.add(bakedIconEntry);
         }
      }

      if (!arrayList.isEmpty()) {
         WexSideClient.getRenderPipeline2().setList(arrayList);
      }
   }

   @Override
   protected float getHeight() {
      return this.armorSlots.get(0).getFloatType();
   }

   @Override
   protected boolean isContentVisible() {
      ClientPlayerEntity player2 = MinecraftClient.getInstance().player;

      for (ArmorSlotRenderer armorSlotRenderer : this.armorSlots) {
         if (armorSlotRenderer.process4(player2)) {
            return true;
         }
      }

      return false;
   }
}
