package ru.wexside.misc;

import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.command.RenderDispatcher;

public final class ActiveFramebufferContext {
   private static Framebuffer framebuffer2;
   private static RenderDispatcher renderDispatcher;

   private ActiveFramebufferContext() {
   }

   public static Framebuffer getFramebuffer() {
      return framebuffer2;
   }

   public static RenderDispatcher getRenderDispatcher() {
      return renderDispatcher;
   }

   public static void update() {
      framebuffer2 = null;
      renderDispatcher = null;
   }

   public static void setFramebuffer(Framebuffer iIllIIiilI2) {
      framebuffer2 = iIllIIiilI2;
   }

   public static void setRenderDispatcher(RenderDispatcher dispatcher) {
      renderDispatcher = dispatcher;
   }
}
