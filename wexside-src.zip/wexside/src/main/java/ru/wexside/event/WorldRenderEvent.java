package ru.wexside.event;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

public final class WorldRenderEvent implements Event {
   private final float tickDelta;
   private final MatrixStack matrices;
   private final VertexConsumerProvider consumers;

   public WorldRenderEvent(MatrixStack matrices, VertexConsumerProvider consumers, float tickDelta) {
      this.matrices = matrices;
      this.consumers = consumers;
      this.tickDelta = tickDelta;
   }

   public MatrixStack getMatrices() {
      return this.matrices;
   }

   public VertexConsumerProvider getConsumers() {
      return this.consumers;
   }

   @Deprecated
   public float getFloatType() {
      return this.tickDelta;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }
}
