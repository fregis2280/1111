package ru.wexside.event;

import net.minecraft.item.ItemStack;

public class ItemHoverEvent extends CancellableEvent implements Event {
   private final ItemStack stack;

   public ItemHoverEvent(ItemStack stack) {
      this.stack = stack;
   }

   public ItemStack getStack() {
      return this.stack;
   }
}
