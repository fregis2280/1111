package ru.wexside.event;

public record WorldSessionEvent(WorldSessionEvent.Change change) implements Event {
   public enum Change {
      JOINED,
      DISCONNECTED;
   }
}
