package ru.wexside.event;

import net.minecraft.entity.Entity;

public class EntityAttackEvent extends CancellableEvent implements Event {
   private final Entity entity;

   public EntityAttackEvent(Entity entity) {
      this.entity = entity;
   }

   public Entity getEntity() {
      return this.entity;
   }
}
