package ru.wexside.event;

import net.minecraft.network.packet.Packet;

public class IncomingPacketEvent extends CancellableEvent implements Event {
   private final Packet<?> packet2;

   public IncomingPacketEvent(Packet<?> packet3) {
      this.packet2 = packet3;
   }

   public Packet<?> getPacket() {
      return this.packet2;
   }
}
