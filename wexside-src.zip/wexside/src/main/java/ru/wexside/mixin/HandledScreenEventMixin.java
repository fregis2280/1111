package ru.wexside.mixin;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.wexside.WexSideClient;
import ru.wexside.event.EventBus;
import ru.wexside.event.ItemHoverEvent;
import ru.wexside.event.TooltipRenderEvent;
import ru.wexside.module.hud.AnimateModule;

@Mixin(HandledScreen.class)
public abstract class HandledScreenEventMixin {
   @Shadow
   protected Slot focusedSlot;
   @Unique
   private boolean wexside$animationMatrixPushed;

   @Inject(method = "render", at = @At("HEAD"))
   private void wexside$beginScreenAnimation(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo callback) {
      if (AnimateModule.compute2((Screen)(Object)this)) {
         context.getMatrices().pushMatrix();
         AnimateModule.handle(context.getMatrices(), context.getScaledWindowWidth(), context.getScaledWindowHeight());
         this.wexside$animationMatrixPushed = true;
      }
   }

   @Inject(method = "render", at = @At("RETURN"))
   private void wexside$endScreenAnimation(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo callback) {
      if (this.wexside$animationMatrixPushed) {
         this.wexside$animationMatrixPushed = false;
         context.getMatrices().popMatrix();
      }
   }

   @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 0)
   private int wexside$transformRenderMouseX(int mouseX) {
      return AnimateModule.compute6(mouseX);
   }

   @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 1)
   private int wexside$transformRenderMouseY(int mouseY) {
      return AnimateModule.compute7(mouseY);
   }

   @ModifyVariable(method = {"mouseClicked", "mouseDragged", "mouseReleased"}, at = @At("HEAD"), argsOnly = true)
   private Click wexside$transformAnimatedClick(Click click) {
      int transformedX = AnimateModule.compute6((int)Math.round(click.x()));
      int transformedY = AnimateModule.compute7((int)Math.round(click.y()));
      return transformedX == (int)Math.round(click.x()) && transformedY == (int)Math.round(click.y())
         ? click
         : new Click(transformedX, transformedY, click.buttonInfo());
   }

   @Inject(method = "drawMouseoverTooltip", at = @At("HEAD"), cancellable = true)
   private void beforeItemTooltip(DrawContext context, int mouseX, int mouseY, CallbackInfo callback) {
      EventBus events = WexSideClient.getEventBus();
      if (events != null && this.focusedSlot != null) {
         ItemStack stack = this.focusedSlot.getStack();
         if (!stack.isEmpty()) {
            ItemHoverEvent event = new ItemHoverEvent(stack);
            events.post(event);
            if (event.isCancelled()) {
               callback.cancel();
            }
         }
      }
   }

   @Inject(method = "render", at = @At("TAIL"))
   private void afterScreenRender(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo callback) {
      EventBus events = WexSideClient.getEventBus();
      if (events != null) {
         events.post(new TooltipRenderEvent(context, mouseX, mouseY));
      }
   }
}
