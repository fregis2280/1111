package ru.wexside.mixin;

import net.minecraft.client.gui.render.EntityGuiElementRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.command.RenderDispatcher;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.wexside.misc.ActiveFramebufferContext;

@Mixin(EntityGuiElementRenderer.class)
public abstract class EntityGuiElementRendererMixin {
   @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/GameRenderer;getEntityRenderDispatcher()Lnet/minecraft/client/render/command/RenderDispatcher;"))
   private RenderDispatcher wexside$useOffscreenRenderDispatcher(GameRenderer gameRenderer) {
      RenderDispatcher offscreenDispatcher = ActiveFramebufferContext.getRenderDispatcher();
      return offscreenDispatcher != null ? offscreenDispatcher : gameRenderer.getEntityRenderDispatcher();
   }
}
