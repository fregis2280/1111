package ru.wexside.mixin;

import net.minecraft.client.input.Input;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.wexside.WexSideClient;
import ru.wexside.misc.CorrectionMode;
import ru.wexside.misc.SilentMovementState;
import ru.wexside.misc.SprintReset;
import ru.wexside.module.movement.AutoJumpModule;
import ru.wexside.module.movement.AutoSprintModule;
import ru.wexside.module.movement.FreeCameraModule;
import ru.wexside.util.Angle;
import ru.wexside.util.RotationController;
import ru.wexside.util.RotationIntent;

@Mixin(Input.class)
public abstract class KeyboardMovementMixin {
   @Shadow
   public PlayerInput playerInput;
   @Shadow
   public Vec2f movementVector;

   @Inject(method = "tick", at = @At("TAIL"))
   private void wexside$applyMovementModules(CallbackInfo callback) {
      if (FreeCameraModule.isEnabled()) {
         this.playerInput = PlayerInput.DEFAULT;
         this.movementVector = Vec2f.ZERO;
      } else {
         PlayerInput input = this.playerInput;
         boolean jump = input.jump() || AutoJumpModule.isEnabled();
         boolean sprint = (input.sprint() || AutoSprintModule.isEnabled()) && !SprintReset.isActive();
         boolean fwd = input.forward();
         boolean bwd = input.backward();
         boolean left = input.left();
         boolean right = input.right();
         float forward = fwd == bwd ? 0.0F : (fwd ? 1.0F : -1.0F);
         float sideways = left == right ? 0.0F : (left ? 1.0F : -1.0F);
         RotationController rotations = WexSideClient.getRotationController();
         if (rotations != null && rotations.hasRotation() && SilentMovementState.isSilentMovementActive()) {
            RotationIntent intent = rotations.getIntent();
            CorrectionMode mode = intent != null ? intent.correction() : CorrectionMode.FOCUSED;
            Angle silent = rotations.getAngle();
            if (mode == CorrectionMode.LOCK) {
               if (forward != 0.0F || sideways != 0.0F) {
                  forward = 1.0F;
                  sideways = 0.0F;
                  fwd = true;
                  bwd = false;
                  left = false;
                  right = false;
               }
            } else if (mode == CorrectionMode.FOCUSED && silent != null && (forward != 0.0F || sideways != 0.0F)) {
               float cameraYaw = SilentMovementState.getCameraYaw();
               float silentYaw = silent.getYaw();
               float deltaYaw = MathHelper.wrapDegrees(cameraYaw - silentYaw);
               double rad = Math.toRadians(deltaYaw);
               double cos = Math.cos(rad);
               double sin = Math.sin(rad);
               float newSideways = (float)(sideways * cos - forward * sin);
               float newForward = (float)(forward * cos + sideways * sin);
               sideways = newSideways;
               forward = newForward;
               fwd = forward > 0.001F;
               bwd = forward < -0.001F;
               left = sideways > 0.001F;
               right = sideways < -0.001F;
            }
         }

         if (input.sneak()) {
            forward *= 0.3F;
            sideways *= 0.3F;
         }

         this.movementVector = new Vec2f(sideways, forward);
         this.playerInput = new PlayerInput(fwd, bwd, left, right, jump, input.sneak(), sprint);
      }
   }

   @Inject(method = "hasForwardMovement", at = @At("HEAD"), cancellable = true)
   private void wexside$fixForwardMovementCheck(CallbackInfoReturnable<Boolean> callback) {
      if (SilentMovementState.isSilentMovementActive() && this.movementVector != null) {
         float x = this.movementVector.x;
         float y = this.movementVector.y;
         if (x * x + y * y >= 0.49F) {
            callback.setReturnValue(true);
         }
      }
   }
}
