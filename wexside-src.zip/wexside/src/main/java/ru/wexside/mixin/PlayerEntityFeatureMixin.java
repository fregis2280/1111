package ru.wexside.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.wexside.module.movement.AirStuckModule;
import ru.wexside.module.movement.AutoSprintModule;
import ru.wexside.module.movement.SpeedModule;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityFeatureMixin {
   private Vec3d wexside$velocityBeforeAttack;
   private boolean wexside$sprintingBeforeAttack;
   private boolean wexside$restoreSprintAfterAttack;

   @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
   private void wexside$freezeAirStuckMovement(Vec3d movement, CallbackInfo callback) {
      Object playerEntityFeatureMixin = this;
      ClientPlayerEntity player;
      if (playerEntityFeatureMixin instanceof ClientPlayerEntity && AirStuckModule.compute2(player = (ClientPlayerEntity)playerEntityFeatureMixin)) {
         player.setVelocity(Vec3d.ZERO);
         callback.cancel();
      }
   }

   @Inject(method = "getMovementSpeed", at = @At("HEAD"), cancellable = true)
   private void wexside$applyCollisionSpeed(CallbackInfoReturnable<Float> callback) {
      if ((Object)this == MinecraftClient.getInstance().player && SpeedModule.value > 0.0F) {
         callback.setReturnValue(SpeedModule.value);
      }
   }

   @Inject(method = "attack", at = @At("HEAD"))
   private void wexside$captureSprintState(Entity target, CallbackInfo callback) {
      PlayerEntity player = (PlayerEntity)(Object)this;
      boolean isLocal = player == MinecraftClient.getInstance().player;
      this.wexside$restoreSprintAfterAttack = isLocal
         && (player.isSprinting() || AutoSprintModule.isEnabled() || AutoSprintModule.isEnabled2())
         && !player.isSpectator();
      if (this.wexside$restoreSprintAfterAttack) {
         this.wexside$velocityBeforeAttack = player.getVelocity();
         this.wexside$sprintingBeforeAttack = player.isSprinting();
      }
   }

   @Inject(method = "attack", at = @At("TAIL"))
   private void wexside$restoreSprintState(Entity target, CallbackInfo callback) {
      if (this.wexside$restoreSprintAfterAttack) {
         PlayerEntity player = (PlayerEntity)(Object)this;
         if (AutoSprintModule.isEnabled2()) {
            player.setVelocity(this.wexside$velocityBeforeAttack);
         }

         player.setSprinting(true);
         this.wexside$restoreSprintAfterAttack = false;
      }
   }
}
