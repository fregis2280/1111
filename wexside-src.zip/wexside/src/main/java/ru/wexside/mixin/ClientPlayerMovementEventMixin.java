package ru.wexside.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.wexside.WexSideClient;
import ru.wexside.event.EventBus;
import ru.wexside.event.MovementSlowdownEvent;
import ru.wexside.misc.CorrectionMode;
import ru.wexside.misc.SilentMovementState;
import ru.wexside.util.Angle;
import ru.wexside.util.RotationController;
import ru.wexside.util.RotationIntent;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerMovementEventMixin {
   @Inject(method = "shouldSlowDown", at = @At("HEAD"), cancellable = true)
   private void allowSlowdownCancellation(CallbackInfoReturnable<Boolean> callback) {
      EventBus events = WexSideClient.getEventBus();
      if (events != null) {
         MovementSlowdownEvent event = new MovementSlowdownEvent();
         events.post(event);
         if (event.isCancelled()) {
            callback.setReturnValue(false);
         }
      }
   }

   @Inject(method = "tick", at = @At("HEAD"))
   private void wexside$beforeTick(CallbackInfo callback) {
      ClientPlayerEntity player = (ClientPlayerEntity)(Object)this;
      SilentMovementState.setCameraYaw(player.getYaw());
      SilentMovementState.setCameraPitch(player.getPitch());
      RotationController rotations = WexSideClient.getRotationController();
      if (rotations != null && rotations.hasRotation()) {
         RotationIntent intent = rotations.getIntent();
         CorrectionMode mode = intent != null ? intent.correction() : CorrectionMode.FOCUSED;
         Angle silent = rotations.getAngle();
         if (silent != null && mode != CorrectionMode.FREE) {
            player.setYaw(silent.getYaw());
            player.setPitch(silent.getPitch());
            SilentMovementState.setSilentMovementActive(true);
         }
      }
   }

   @Inject(method = "tick", at = @At("RETURN"))
   private void wexside$afterTick(CallbackInfo callback) {
      if (SilentMovementState.isSilentMovementActive()) {
         ClientPlayerEntity player = (ClientPlayerEntity)(Object)this;
         RotationController rotations = WexSideClient.getRotationController();
         if (rotations != null) {
            Angle silent = rotations.getAngle();
            if (silent != null) {
               rotations.onTick(silent.getPitch());
            }
         }

         player.setYaw(SilentMovementState.getCameraYaw());
         player.setPitch(SilentMovementState.getCameraPitch());
         SilentMovementState.setSilentMovementActive(false);
      }
   }

   @Inject(method = "sendMovementPackets", at = @At("HEAD"))
   private void wexside$beforeSendMovementPackets(CallbackInfo callback) {
      if (!SilentMovementState.isSilentMovementActive()) {
         RotationController rotations = WexSideClient.getRotationController();
         if (rotations != null && rotations.hasRotation()) {
            ClientPlayerEntity player = (ClientPlayerEntity)(Object)this;
            Angle silent = rotations.getAngle();
            if (silent != null) {
               player.setYaw(silent.getYaw());
               player.setPitch(silent.getPitch());
               SilentMovementState.setSilentPacketActive(true);
            }
         }
      }
   }

   @Inject(method = "sendMovementPackets", at = @At("RETURN"))
   private void wexside$afterSendMovementPackets(CallbackInfo callback) {
      if (SilentMovementState.isSilentPacketActive()) {
         ClientPlayerEntity player = (ClientPlayerEntity)(Object)this;
         RotationController rotations = WexSideClient.getRotationController();
         if (rotations != null) {
            Angle silent = rotations.getAngle();
            if (silent != null) {
               rotations.onTick(silent.getPitch());
            }
         }

         player.setYaw(SilentMovementState.getCameraYaw());
         player.setPitch(SilentMovementState.getCameraPitch());
         SilentMovementState.setSilentPacketActive(false);
      }
   }
}
