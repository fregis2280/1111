package ru.wexside.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.fog.FogData;
import net.minecraft.client.render.fog.WaterFogModifier;
import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.wexside.module.render.NoRenderModule;

@Mixin(WaterFogModifier.class)
public abstract class WaterFogModifierMixin {
   @Inject(method = "applyStartEndModifier", at = @At("TAIL"))
   private void wexside$removeWaterFog(FogData fog, Camera camera, ClientWorld world, float viewDistance, RenderTickCounter tickCounter, CallbackInfo callback) {
      if (NoRenderModule.isFluidZoomDisabled()) {
         clearFog(fog);
      }
   }

   private static void clearFog(FogData fog) {
      fog.environmentalStart = 1.0E7F;
      fog.renderDistanceStart = 1.0E7F;
      fog.environmentalEnd = 1.0E8F;
      fog.renderDistanceEnd = 1.0E8F;
      fog.skyEnd = 1.0E8F;
      fog.cloudEnd = 1.0E8F;
   }
}
