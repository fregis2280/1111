package ru.wexside.mixin;

import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.client.sound.SoundSystem.PlayResult;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.wexside.module.misc.CustomSoundsModule;
import ru.wexside.module.misc.SoundRemoverModule;

@Mixin(SoundManager.class)
public abstract class SoundManagerEventMixin {
   @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;", at = @At("HEAD"), cancellable = true)
   private void wexside$filterImmediateSound(SoundInstance sound, CallbackInfoReturnable<PlayResult> callback) {
      if (sound != null) {
         Identifier soundId = sound.getId();
         boolean muted = SoundRemoverModule.compute4(soundId);
         SoundRemoverModule.handle(soundId, muted);
         if (muted) {
            callback.setReturnValue(PlayResult.NOT_STARTED);
         } else {
            if (CustomSoundsModule.compute8(sound, 0L)) {
               callback.setReturnValue(PlayResult.NOT_STARTED);
            }
         }
      }
   }

   @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;I)V", at = @At("HEAD"), cancellable = true)
   private void wexside$filterDelayedSound(SoundInstance sound, int delay, CallbackInfo callback) {
      if (sound != null) {
         Identifier soundId = sound.getId();
         boolean muted = SoundRemoverModule.compute4(soundId);
         SoundRemoverModule.handle(soundId, muted);
         if (muted) {
            callback.cancel();
         } else {
            if (CustomSoundsModule.compute8(sound, delay * 50L)) {
               callback.cancel();
            }
         }
      }
   }
}
