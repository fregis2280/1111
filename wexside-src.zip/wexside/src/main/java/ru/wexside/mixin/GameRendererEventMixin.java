package ru.wexside.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.wexside.WexSideClient;
import ru.wexside.event.AspectRatioEvent;
import ru.wexside.event.EventBus;
import ru.wexside.event.OverlayRenderEvent;
import ru.wexside.event.OverlayType;
import ru.wexside.misc.ChamsRenderer;
import ru.wexside.misc.GlowEspRenderer;
import ru.wexside.module.render.NoRenderModule;
import ru.wexside.render.ClientEventBridge;
import ru.wexside.render.HologramImpostorRenderer;
import ru.wexside.ui.WexsideScreen;

@Mixin(GameRenderer.class)
public abstract class GameRendererEventMixin {
   @Shadow
   @Final
   private MinecraftClient client;
   @Shadow
   private float fovMultiplier;
   @Shadow
   private float lastFovMultiplier;

   @Shadow
   public abstract float getFarPlaneDistance();

   @Inject(
      method = "render",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V", shift = Shift.BEFORE)
   )
   private void renderWexsideHud(RenderTickCounter tickCounter, boolean tick, CallbackInfo callback) {
      ClientEventBridge.renderHudAfterVanillaGui();
   }

   @Inject(
      method = "render",
      at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/render/GuiRenderer;render(Lcom/mojang/blaze3d/buffers/GpuBufferSlice;)V", shift = Shift.AFTER)
   )
   private void renderWexsidePanel(RenderTickCounter tickCounter, boolean tick, CallbackInfo callback) {
      if (this.client.currentScreen instanceof WexsideScreen screen) {
         screen.renderPanel(tickCounter.getDynamicDeltaTicks());
      }
   }

   @Inject(method = "renderWorld", at = @At("TAIL"))
   private void wexside$finishDeferredWorldEffects(RenderTickCounter tickCounter, CallbackInfo callback) {
      HologramImpostorRenderer.flush();
      ChamsRenderer.presentPendingChams();
      GlowEspRenderer.renderPendingGlow();
   }

   @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
   private void allowHurtCameraCancellation(MatrixStack matrices, float tickDelta, CallbackInfo callback) {
      EventBus events = WexSideClient.getEventBus();
      if (events != null) {
         OverlayRenderEvent event = new OverlayRenderEvent(OverlayType.CAMERA_HURT);
         events.post(event);
         if (event.isCancelled()) {
            callback.cancel();
         }
      }
   }

   @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
   private void disableViewBobbing(MatrixStack matrices, float tickDelta, CallbackInfo callback) {
      if (NoRenderModule.isViewBobbingDisabled()) {
         callback.cancel();
      }
   }

   @Inject(method = "updateFovMultiplier", at = @At("HEAD"), cancellable = true)
   private void disableDynamicFov(CallbackInfo callback) {
      if (NoRenderModule.isEnabled()) {
         this.lastFovMultiplier = 1.0F;
         this.fovMultiplier = 1.0F;
         callback.cancel();
      }
   }

   @Inject(method = "getBasicProjectionMatrix", at = @At("HEAD"), cancellable = true)
   private void useConfiguredAspectRatio(float fov, CallbackInfoReturnable<Matrix4f> callback) {
      EventBus events = WexSideClient.getEventBus();
      if (events != null) {
         float vanillaRatio = (float)this.client.getWindow().getFramebufferWidth() / Math.max(1, this.client.getWindow().getFramebufferHeight());
         AspectRatioEvent event = new AspectRatioEvent(vanillaRatio);
         events.post(event);
         if (Float.compare(event.getAspectRatio(), vanillaRatio) != 0) {
            callback.setReturnValue(new Matrix4f().perspective(fov * (float) (Math.PI / 180.0), event.getAspectRatio(), 0.05F, this.getFarPlaneDistance()));
         }
      }
   }
}
