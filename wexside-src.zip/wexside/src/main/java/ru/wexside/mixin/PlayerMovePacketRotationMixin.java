package ru.wexside.mixin;

import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.wexside.WexSideClient;
import ru.wexside.util.Angle;
import ru.wexside.util.RotationController;

@Mixin(PlayerMoveC2SPacket.class)
public abstract class PlayerMovePacketRotationMixin {
   @Shadow
   @Final
   protected boolean changeLook;
   @Shadow
   @Final
   @Mutable
   protected float yaw;
   @Shadow
   @Final
   @Mutable
   protected float pitch;

   @Inject(method = "<init>", at = @At("RETURN"))
   private void wexside$applySilentRotation(
      double x,
      double y,
      double z,
      float yaw,
      float pitch,
      boolean onGround,
      boolean horizontalCollision,
      boolean changePosition,
      boolean changeLook,
      CallbackInfo callback
   ) {
      RotationController rotations = WexSideClient.getRotationController();
      if (rotations != null && rotations.hasRotation()) {
         Angle silent = rotations.getAngle();
         if (silent != null) {
            this.yaw = silent.getYaw();
            this.pitch = silent.getPitch();
         }
      }
   }
}
