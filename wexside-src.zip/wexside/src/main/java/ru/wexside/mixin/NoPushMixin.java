package ru.wexside.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.wexside.module.player.NoPushModule;

public final class NoPushMixin {
   private NoPushMixin() {
   }

   @Mixin(ClientPlayerEntity.class)
   public abstract static class ClientPlayerHook {
      @Inject(method = "pushOutOfBlocks", at = @At("HEAD"), cancellable = true)
      private void wexside$ignoreBlockPush(double x, double z, CallbackInfo callback) {
         if (NoPushModule.compute("Blocks")) {
            callback.cancel();
         }
      }
   }

   @Mixin(Entity.class)
   public abstract static class EntityHook {
      @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true)
      private void wexside$ignoreEntityPush(Entity other, CallbackInfo callback) {
         if ((Object)this == MinecraftClient.getInstance().player && NoPushModule.compute("Players")) {
            callback.cancel();
         }
      }
   }

   @Mixin(PlayerEntity.class)
   public abstract static class PlayerHook {
      @Inject(method = "isPushedByFluids", at = @At("HEAD"), cancellable = true)
      private void wexside$ignoreFluidPush(CallbackInfoReturnable<Boolean> callback) {
         if ((Object)this == MinecraftClient.getInstance().player && NoPushModule.compute("Water")) {
            callback.setReturnValue(false);
         }
      }
   }
}
