package ru.wexside.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.wexside.WexSideClient;
import ru.wexside.module.render.SeeInvisiblesModule;
import ru.wexside.util.Angle;
import ru.wexside.util.RotationController;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
   @Shadow
   public abstract Identifier getTexture(LivingEntityRenderState var1);

   @Inject(method = "getRenderLayer", at = @At("HEAD"), cancellable = true)
   private void wexside$useTranslucentLayer(
      LivingEntityRenderState state, boolean showBody, boolean translucent, boolean showOutline, CallbackInfoReturnable<RenderLayer> callback
   ) {
      if (SeeInvisiblesModule.isEnabled() && state.invisible) {
         callback.setReturnValue(RenderLayers.itemEntityTranslucentCull(this.getTexture(state)));
      }
   }

   @Inject(method = "getMixColor", at = @At("HEAD"), cancellable = true)
   private void wexside$applyInvisibleAlpha(LivingEntityRenderState state, CallbackInfoReturnable<Integer> callback) {
      if (SeeInvisiblesModule.isEnabled() && state.invisible) {
         callback.setReturnValue(SeeInvisiblesModule.getIntType());
      }
   }

   @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At("TAIL"))
   private void wexside$updateSilentRotationRenderState(LivingEntity entity, LivingEntityRenderState state, float tickDelta, CallbackInfo callback) {
      if (entity == MinecraftClient.getInstance().player) {
         RotationController rotations = WexSideClient.getRotationController();
         if (rotations != null && rotations.hasRotation()) {
            Angle silent = rotations.getAngle();
            if (silent != null) {
               state.pitch = silent.getPitch();
               state.relativeHeadYaw = MathHelper.wrapDegrees(silent.getYaw() - state.bodyYaw);
            }
         }
      }
   }
}
