package ru.wexside.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Invoker;
import ru.wexside.misc.AttackInvoker;
import ru.wexside.misc.ItemUseCooldownAccessor;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientAccessorMixin implements ItemUseCooldownAccessor, AttackInvoker {
   @Shadow
   private int itemUseCooldown;

   @Invoker("doAttack")
   @Override
   public abstract boolean invokeAttack();

   @Override
   public void setItemUseCooldown(int cooldown) {
      this.itemUseCooldown = cooldown;
   }
}
