package ru.wexside.item;

import java.util.Locale;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public record ItemBadge(Text label, ItemBadgeCategory category) {
   public static ItemBadge fromStack(ItemStack stack) {
      if (stack != null && !stack.isEmpty()) {
         Text label = stack.getName();
         String normalizedName = label.getString().toLowerCase(Locale.ROOT);
         ItemBadgeCategory category;
         if (containsAny(normalizedName, "талисман", "talisman", "амулет", "amulet")) {
            category = ItemBadgeCategory.TALISMAN;
         } else {
            if (!containsAny(normalizedName, "сфера", "sphere", "шар", "orb")) {
               return null;
            }

            category = ItemBadgeCategory.SPHERE;
         }

         return new ItemBadge(label.copy(), category);
      } else {
         return null;
      }
   }

   private static boolean containsAny(String value, String... markers) {
      for (String marker : markers) {
         if (value.contains(marker)) {
            return true;
         }
      }

      return false;
   }
}
